# CHIFFRE CONSEIL — application Android officielle

**LE CONSEIL QUI COMPTE**

Application mobile native, développée en **Flutter**, du cabinet CHIFFRE CONSEIL. Elle est construite à partir du contenu réel de https://chiffreconseil.net : expertises, simulateurs, publications, guides, références officielles et formulaires.

> Ce n'est pas une WebView : chaque écran est natif. L'application fonctionne hors connexion dès l'installation, puis elle s'actualise depuis le site.

---

## 1. Obtenir l'APK sans rien installer (recommandé)

La compilation se fait gratuitement sur **GitHub Actions**. Le fichier `.github/workflows/build-android.yml` est déjà fourni.

1. Créez un compte sur https://github.com, s'il n'existe pas.
2. Créez un dépôt **privé** nommé par exemple `chiffre-conseil-app`.
3. Envoyez le contenu de ce dossier dans le dépôt, de l'une de ces deux façons :
   - dans le navigateur : *Add file › Upload files*, puis glissez **tout** le contenu du dossier, y compris le dossier caché `.github` ;
   - en ligne de commande :
     ```bash
     git init && git add . && git commit -m "Application CHIFFRE CONSEIL"
     git branch -M main
     git remote add origin https://github.com/<compte>/chiffre-conseil-app.git
     git push -u origin main
     ```
4. Ouvrez l'onglet **Actions** du dépôt. La compilation *Android — APK debug, APK release et AAB* démarre seule, en 10 à 15 minutes environ. Pour la relancer, utilisez *Run workflow*.
5. Ouvrez l'exécution terminée. Dans **Artifacts**, téléchargez `CHIFFRE-CONSEIL-android.zip`. Il contient :

| Fichier | Usage |
|---|---|
| `CHIFFRE-CONSEIL-debug.apk` | APK DEBUG, à installer directement sur un téléphone |
| `CHIFFRE-CONSEIL.apk` | APK RELEASE, optimisé pour les tests réels |
| `CHIFFRE-CONSEIL.aab` | AAB destiné à Google Play |
| `projet-android-complet.zip` | Projet Android complet (Gradle) généré |
| `empreinte-signature-*.txt` | Empreinte SHA-256 à reporter dans `assetlinks.json` (liens profonds) |

### Installer l'APK sur le téléphone

1. Copiez `CHIFFRE-CONSEIL.apk` sur le téléphone, par WhatsApp à soi-même, Google Drive ou câble USB.
2. Ouvrez le fichier. Android demande d'autoriser l'installation depuis cette source : acceptez.
3. Lancez **CHIFFRE CONSEIL**.

Android 6.0 (API 23) minimum.

---

## 2. Compiler sur un ordinateur (développeur)

Prérequis : Flutter stable (3.27 ou plus), Android Studio (SDK Android) et Java 17.

```bash
flutter create --platforms=android --org net.chiffreconseil --project-name chiffre_conseil .
python3 tool/configure_android.py     # identifiant net.chiffreconseil.app, minSdk 23, signature
flutter pub get
flutter test                          # tests des moteurs de calcul
flutter run                           # sur un téléphone branché ou un émulateur

flutter build apk --debug             # build/app/outputs/flutter-apk/app-debug.apk
flutter build apk --release           # build/app/outputs/flutter-apk/app-release.apk
flutter build appbundle --release     # build/app/outputs/bundle/release/app-release.aab
```

Le script `tool/build_local.sh` enchaîne toutes ces étapes.

> `flutter create .` génère les fichiers Gradle du gabarit officiel, correspondant à votre version de Flutter. Il **ne remplace pas** les fichiers fournis : manifeste, icônes, écran de lancement, code `lib/`, tests.

---

## 3. Signature (obligatoire pour Google Play)

Sans clé, l'APK release et l'AAB sont signés avec la clé de **debug**. C'est suffisant pour les tests, mais Google Play les refuse.

1. Créez la clé une seule fois et conservez-la précieusement (sauvegarde hors ligne) :
   ```bash
   bash tool/create_keystore.sh        # crée upload-keystore.jks
   ```
2. **En local**, copiez `android/key.properties.example` vers `android/key.properties` et complétez-le.
3. **Sur GitHub**, allez dans *Settings › Secrets and variables › Actions* et ajoutez :
   - `ANDROID_KEYSTORE_BASE64` : contenu de `base64 -w0 upload-keystore.jks`
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_PASSWORD`
   - `ANDROID_KEY_ALIAS` (par défaut : `upload`)

Ne publiez jamais la clé ni `key.properties` : le `.gitignore` les exclut.

---

## 4. Configuration et variables

Aucune clé secrète n'est intégrée. Les valeurs ci-dessous sont modifiables à la compilation :

| Variable (`--dart-define`) | Défaut | Rôle |
|---|---|---|
| `CC_SITE` | `https://chiffreconseil.net` | Site source |
| `CC_API_BASE` | `https://chiffreconseil.net` | Base de l'API (formulaires, contenus) |
| `CC_WHATSAPP` | vide | Numéro WhatsApp au format international sans `+`. Le bouton reste masqué tant qu'il est vide |

Exemple : `flutter build apk --release --dart-define=CC_WHATSAPP=21699753706`, à utiliser seulement après confirmation que ce numéro est actif sur WhatsApp.

---

## 5. Connexion au site (API)

| Fonction | Point d'accès | État |
|---|---|---|
| Rendez-vous, devis, contact | `POST /api/contact.php` (JSON `{type, champs}`) | **Connecté** : même traitement que les formulaires du site (courriel au cabinet, accusé de réception, sauvegarde) |
| Articles de l'espace de gestion | `GET /api/articles.php` | **Connecté** : fusionné avec le contenu de l'application |
| Contenu complet (expertises, outils, 51 documents, références) | `GET /app/content.json` | À déposer sur le site : voir `site-integration/` |

Hors connexion, les demandes sont conservées (chiffrées) et **renvoyées automatiquement** au retour du réseau.

Pour mettre à jour le contenu après une publication sur le site :
```bash
python3 tool/extract_site_content.py <dossier_www_du_site> assets/data/content.json
cp assets/data/content.json site-integration/www/app/content.json   # puis envoyer sur l'hébergement
```

---

## 6. Firebase (notifications push et Analytics)

Tout est préparé. Le code passe par des interfaces (`PushService`, `AnalyticsService`) et reste sans dépendance Firebase tant que vous ne l'activez pas. L'activation se fait en 3 étapes, décrites dans **`firebase/README_FIREBASE.md`** ; les adaptateurs sont fournis.

---

## 7. Liens profonds

| Lien | Écran ouvert |
|---|---|
| `https://chiffreconseil.net/outils` | Outils |
| `https://chiffreconseil.net/outils/calculateur-tva` | Un outil précis |
| `https://chiffreconseil.net/rendez-vous` | Prendre rendez-vous |
| `https://chiffreconseil.net/devis` | Demande de devis |
| `https://chiffreconseil.net/blog/<article>` | Lecture d'un article |
| `https://chiffreconseil.net/contact`, `/expertises/<pôle>`, `/a-propos`, `/references-publiques` | Écrans correspondants |

- **Test immédiat :** `adb shell am start -a android.intent.action.VIEW -d "chiffreconseil://app/outils"`
- **Ouverture directe depuis le site, sans choix de navigateur :** déposez `site-integration/www/.well-known/assetlinks.json` après y avoir reporté l'empreinte SHA-256 de la clé de signature.

---

## 8. Architecture

Voir `docs/ARCHITECTURE.md`, `docs/DESIGN_SYSTEM.md` et `docs/DOCUMENTATION_TECHNIQUE.md`.

```
lib/
  main.dart, app.dart, app_router.dart   démarrage, thème, routes et liens profonds
  core/        config, thème (Brand Book), formats, validation, services (API, stockage chiffré, connexion, analytics, push)
  data/        modèles et dépôt de contenu (embarqué → cache → site)
  state/       état global (ChangeNotifier) : favoris, documents, profil, entreprises, demandes, notifications
  features/    tools/   (moteurs de calcul + écrans des 13 outils)
               company/ (Mon entreprise, Check-up, diagnostic)
  ui/          écrans (accueil, ressources, actualités, fiscalité, formulaires, profil) et composants
assets/        contenu du site (content.json), images, polices Montserrat
test/          tests des moteurs (valeurs identiques aux calculateurs du site), formats, routes
```

---

## 9. Évolution : CHIFFRE CONSEIL CLIENT

L'espace utilisateur est local et facultatif. Les prochaines briques sont isolées et prêtes à recevoir une API d'authentification :
- profil (`UserProfile`) ;
- entreprises (`Company`) ;
- historique des demandes (`RequestRecord`) ;
- notifications (`AppNotice`) ;
- entrée « Espace client » dans le profil.

Les étapes prévues sont : authentification, suivi des missions, documents, factures, rendez-vous et tableaux de bord.

---

CHIFFRE CONSEIL · Avenue Hedi Nouira, Ennasr 2, Ariana, Tunisie · +216 99 753 706 · chiffreconseil@gmail.com · chiffreconseil.net
