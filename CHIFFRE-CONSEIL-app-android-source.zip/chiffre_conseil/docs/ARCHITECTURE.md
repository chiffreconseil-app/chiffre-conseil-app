# Architecture de l'application CHIFFRE CONSEIL

## Choix techniques

**Flutter (Dart).** L'application a de vrais écrans natifs, un APK et un AAB compilés en AOT, et une seule base de code, réutilisable plus tard pour iOS.

Les dépendances sont volontairement réduites à des paquets officiels ou très répandus :

- `http`
- `url_launcher`
- `shared_preferences`
- `flutter_secure_storage`
- `path_provider`
- `flutter_localizations`

L'état est géré sans bibliothèque externe : un `ChangeNotifier` (`AppState`) exposé par un `InheritedNotifier` (`AppScope`).

## Couches

```
UI (ui/, features/*/ui)  ──►  AppState (state/)  ──►  Services (core/services)  ──►  chiffreconseil.net
          │                         │                         ├─ ApiClient           (HTTPS, délais, erreurs normalisées)
          │                         │                         ├─ StorageService      (préférences + Android Keystore)
          │                         │                         ├─ ConnectivityService (détection hors connexion)
          │                         │                         ├─ AnalyticsService    (backend interchangeable, consentement)
          │                         │                         └─ PushService         (topics FCM, backend interchangeable)
          │                         └──►  ContentRepository (data/) : embarqué → cache → site
          └──►  Moteurs de calcul purs (features/tools/engines) : testés unitairement
```

## Contenu

1. **Instantané embarqué :** `assets/data/content.json`, extrait du site par `tool/extract_site_content.py`. Il contient :
   - 6 expertises (prestations, livrables, tarifs indicatifs) ;
   - 8 simulateurs ;
   - 51 fiches et guides avec leur texte complet ;
   - 26 références officielles ;
   - le contenu de la page « Le cabinet ».
2. **Cache local :** `content_cache.json`, dans le dossier privé de l'application.
3. **Actualisation au démarrage et par « tirer pour actualiser » :** `GET /app/content.json` et `GET /api/articles.php` (articles publiés depuis l'espace de gestion).
4. **Nouveautés :** toute nouvelle publication détectée génère une notification dans le centre de notifications, selon les thèmes choisis.

## Navigation

- **Barre inférieure (5 onglets) :**
  - Accueil
  - Outils
  - Ressources
  - Actualités
  - Profil
- **Bouton `+` :** rendez-vous, devis, contact.
- **Routes nommées :** ce sont les chemins du site (`/outils/<slug>`, `/rendez-vous`, `/devis`, `/blog/<slug>`, `/expertises/<slug>`…). Les liens profonds Android ouvrent donc directement le bon écran (`AppRouter`).

## Outils (13)

- **8 simulateurs du site, portés à l'identique** depuis `assets/js/03-calculateurs.js`, barème LF 2026 :
  - paie
  - IRPP
  - retenue à la source
  - TVA
  - pension
  - vignette
  - crédit
  - matricule fiscal
- **5 outils de gestion,** basés sur des formules standard appliquées aux seules données saisies :
  - VAN / TRI / payback
  - BFR
  - seuil de rentabilité
  - trésorerie prévisionnelle
  - budget / réalisé / écart
- **Tests (`test/engines_test.dart`) :** ils comparent les résultats Dart aux valeurs calculées avec le JavaScript du site.

## Mon entreprise et Check-up

- **Check-up :** 21 questions réparties sur 7 domaines (trésorerie, rentabilité, fiscalité, organisation, RH, marketing, stratégie).
- **Calcul du score :** un score par domaine de 0 à 100 ; le score global est leur moyenne ; le potentiel d'amélioration vaut 100 − score.
- **Profils d'entreprise :** stockés chiffrés sur l'appareil.
- **Tableau de bord et diagnostic :** recommandations par domaine, reliées aux expertises du site.
- **Statut :** présenté partout comme un **outil d'orientation**, pas un diagnostic certifié.

## Hors connexion

Disponible sans réseau :

- informations du cabinet, expertises et contenus embarqués ;
- documents téléchargés ;
- derniers articles consultés ;
- les 13 outils ;
- l'historique des demandes.

Si l'appareil est hors connexion, une bannière l'indique. Les demandes envoyées hors connexion sont mises en file d'attente puis renvoyées automatiquement.

## Évolution vers « CHIFFRE CONSEIL CLIENT »

Les modèles `UserProfile`, `Company`, `RequestRecord` et `AppNotice` restent indépendants du stockage. Pour brancher un espace client, il faut :

1. ajouter un `AuthService` (jeton dans `StorageService.writeSecure`) ;
2. ajouter des dépôts distants (missions, documents, factures, rendez-vous) ;
3. remplacer l'entrée « Espace client » du profil par les écrans correspondants.
