# Design System — application CHIFFRE CONSEIL

Ce design system applique le Brand Book CHIFFRE CONSEIL « Le C décisif ».

> Le cahier des charges citait `#0B1F5B` et `#FF6A00`. Ce sont les anciennes valeurs. L'application utilise la charte en vigueur, ci-dessous.

## Couleurs (`lib/core/theme/cc_colors.dart`)

| Jeton | Valeur | Usage |
|---|---|---|
| `CC.navy` (Bleu Nuit) | `#0E1B4D` | Couleur dominante : en-têtes, panneaux de résultats, écran de lancement |
| `CC.orange` (Orange Décision) | `#FF5A1F` | Accent : boutons principaux, bouton `+`, point final, filets |
| `CC.orangeText` (Orange Texte) | `#C2410C` | Orange pour le texte sur fond clair (contraste AA) |
| `CC.blue` (Bleu Horizon) | `#2F6BFF` | Encadrés d'information |
| `CC.mist` | `#F5F7FA` | Fond de l'application (mode clair) |
| `CC.success` | `#12A150` | Indicateurs positifs (score ≥ 70) |
| `CC.warning` | `#E08A00` | Vigilance (score de 45 à 69) |
| `CC.danger` | `#D92D20` | Alertes (score < 45) |
| Mode sombre | `#070D24`, `#0F1838`, `#152048` | Fond, surface, cartes |

## Typographie

**Montserrat** est embarquée dans l'application, en graisses 400, 500, 600, 700 et 800.

| Élément | Graisse | Taille |
|---|---|---|
| Titres d'écran | 800 | 18 à 27 |
| Titres de section | 800 | 20 |
| Sur-titres | 700, capitales espacées | 11 |
| Corps de texte | 400 | 14 à 15,5, interligne 1,5 |

## Composants (`lib/ui/widgets`, `lib/features/tools/ui/tool_form.dart`)

- **Cartes :**
  - `CCCard` : rayon 16, filet `#DDE2EC`, ombre absente.
- **Boutons :**
  - `PrimaryButton` : fond orange, hauteur 54, rayon 14, capitales.
  - `SecondaryButton` : contour Bleu Nuit, ou blanc sur fond sombre.
- **Éléments graphiques :**
  - `IconBadge` : icône Material dans un carré arrondi.
  - `Pill` : étiquette de catégorie.
- **Mise en page :**
  - `SectionTitle` : sur-titre et titre, avec action « Tout voir ».
- **Résultats des outils :**
  - `ResultPanel`, `ResultLine` et `ResultBig` : dégradé Bleu Nuit, valeur clé en orange.
- **Scores :**
  - `ScoreRing` et `ScoreBar` : couleur verte, orange ou rouge selon le score.
- **Chargement et états :**
  - `Skeleton` et `ArticleSkeleton` : blocs de chargement pulsés.
  - `EmptyState` : état vide.
  - `OfflineBanner` : bannière « Vous êtes actuellement hors connexion. ».
  - `Disclaimer` : mention d'information.
- **Contenus :**
  - `AccentBox` : encadré à filet orange (réponse courte, encadrés d'article).

## Principes

- Une couleur dominante (Bleu Nuit), un seul accent (orange). Le vert et le rouge servent uniquement aux indicateurs.
- Coins légèrement arrondis (12 à 20). Pas d'ombres lourdes. Beaucoup d'espace blanc.
- Animations brèves et utiles : transition d'écran par fondu et glissement, anneau de score animé, écran de lancement d'environ 1,7 s.
- Icônes Material professionnelles. Aucun émoji dans l'interface.
- Lisibilité : contraste AA, mise en page responsive (grilles de 2 ou 3 colonnes selon la largeur), rotation d'écran prise en charge.

## Identité

- Logos officiels (PNG issus du Brand Book) : signature horizontale, version inverse et symbole. Ils ne sont jamais déformés.
- Icône de lanceur : symbole « C » inverse sur fond Bleu Nuit, en icône adaptative (Android 8+) et monochrome (Android 13+).
- Écran de lancement Android 12+ : fond Bleu Nuit et symbole.
