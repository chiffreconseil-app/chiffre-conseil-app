# Documentation technique

## Écrans

| Écran | Fichier | Contenu |
|---|---|---|
| Lancement, présentation | `ui/screens/root_gate.dart` | Animation de 1,7 s ; 3 écrans de présentation au premier lancement ; consentement à la mesure d'audience (facultatif) |
| Accueil | `ui/screens/home_screen.dart` | Logo et slogan, phrase d'accroche, boutons PRENDRE RENDEZ-VOUS et DEMANDER UN DEVIS, 6 expertises, Mon entreprise, Check-up, outils, fiscalité, derniers articles, cabinet |
| Expertise | `ui/screens/expertise_screen.dart` | Situations fréquentes, prestations, livrables, outils liés, tarifs indicatifs 2026 (repris du site) |
| Outils | `ui/screens/tools_screen.dart`, `features/tools/` | 13 outils, recherche, favoris, résultats en direct |
| Bibliothèque | `ui/screens/library_screen.dart` | 51 documents (« +50 »), recherche, filtres par format et catégorie, CONSULTER / TÉLÉCHARGER (lecture hors connexion) |
| Actualités et conseils | `ui/screens/news_screen.dart` | Image, titre, extrait, date, catégorie, « Lire » ; recherche ; filtres ; tirer pour actualiser |
| Lecture | `ui/screens/article_screen.dart` | Rendu natif : titres, listes, définitions, tableaux, formules, encadrés |
| Fiscalité tunisienne | `ui/screens/fiscalite_screen.dart` | Accès rapides (loi de finances, agenda, notes communes, TVA, impôts, obligations) et ressources officielles |
| Rendez-vous | `ui/screens/forms/rdv_screen.dart` | Nom, prénom, téléphone, e-mail, entreprise, objet, type de consultation, format, date, heure, message |
| Devis | `ui/screens/forms/devis_screen.dart` | Nom, entreprise, téléphone, e-mail, secteur, service, prestation, budget, échéance, description |
| Contact | `ui/screens/forms/contact_screen.dart` | Appeler, e-mail, WhatsApp (si configuré), itinéraire, site, LinkedIn, message |
| Mon entreprise | `features/company/company_screen.dart` | Profils, score de pilotage, diagnostic par domaine |
| Check-up | `features/company/checkup_screen.dart` | 21 questions, score global de 0 à 100, diagnostic personnalisé |
| Profil | `ui/screens/profile/*` | Profil, entreprises, favoris, documents, historique, notifications, réglages (thème, notifications, confidentialité, suppression des données) |

## Formulaires → site

- **Point d'accès :** `POST https://chiffreconseil.net/api/contact.php`.
- **Corps de la requête :**
  ```json
  {
    "type": "Demande de rendez-vous",
    "champs": {
      "nom": "…", "prenom": "…", "email": "…", "telephone": "…", "societe": "…",
      "dateSouhaitee": "…", "creneau": "…", "format": "…", "duree": "…", "objet": "…", "message": "…",
      "source": "application-android", "_hp": "", "_t": "12000"
    }
  }
  ```
- **Types de demande :** `Demande de rendez-vous`, `Demande de devis` ou `Demande de contact`.
- **Champs anti-robot :** `_hp` et `_t` sont les mêmes que sur le site. `_t` vaut toujours au moins 3 000 ms.
- **Réponse :** `{ "ok": true, "id": "dem_…" }`. L'identifiant est affiché comme référence et conservé dans l'historique.
- **Erreurs :**
  - 400 : la liste `erreurs` est affichée.
  - 429 : limitation de débit.
  - Erreur réseau : la demande est mise en file d'attente, chiffrée, puis renvoyée automatiquement.

## Sécurité

- **Réseau :**
  - HTTPS uniquement. `network_security_config.xml` refuse le trafic en clair, et `ApiClient` refuse toute URL non HTTPS.
  - Aucune clé d'API ni aucun secret dans le code. Firebase est configuré par fichier, hors dépôt.
- **Données :**
  - Données personnelles chiffrées : `flutter_secure_storage` (Android Keystore, EncryptedSharedPreferences).
  - Sauvegarde Android et transfert d'appareil désactivés : `allowBackup=false`, `data_extraction_rules.xml`.
  - Validation alignée sur le serveur : longueurs bornées, e-mail, téléphone. Les caractères de contrôle sont supprimés.
  - Bouton « Supprimer toutes mes données ».
- **Erreurs :** les erreurs non gérées sont interceptées (`FlutterError.onError`, `platformDispatcher.onError`). En release, aucune trace technique n'est affichée à l'utilisateur.
- **Signature :** clé release hors dépôt, via `key.properties` ou les secrets GitHub.

## Analytics (préparé)

- **Consentement :** la mesure est désactivée par défaut ; le consentement est demandé à la présentation et modifiable dans les réglages.
- **Événements :**
  - `tool_used`
  - `article_read`
  - `document_download`
  - `quote_request`
  - `appointment_request`
  - `checkup_completed`
  - écrans des onglets
- **Branchement Firebase Analytics :** voir `firebase/README_FIREBASE.md`.

## Notifications (préparées)

- **Topics FCM :**
  - `articles`
  - `ressources`
  - `fiscalite`
  - `outils`
  - `rendez_vous`
  - `infos`
- **Préférences :** un interrupteur par thème dans les réglages.
- **Centre de notifications intégré :** il fonctionne déjà, avant même Firebase. Il signale les nouveautés détectées à l'actualisation, la bienvenue et les demandes envoyées après un passage hors connexion.

## Tests

- `test/engines_test.dart` : les résultats des moteurs sont identiques à ceux des calculateurs du site. Cas couverts :
  - IRPP
  - paie (brut → net et net → brut)
  - crédit
  - pension
  - TVA
  - vignette
  - retenue à la source
  - matricule
  - VAN / TRI
  - seuil de rentabilité
  - BFR
  - check-up
  - formats
- `test/widget_test.dart` : calculateur TVA, composants en mode sombre, normalisation des liens profonds.
- **Exécution :** `flutter test`, lancé aussi automatiquement à chaque compilation GitHub Actions.

### Recette manuelle avant diffusion

- **Écrans et affichage :**
  - Téléphones de petite (360 dp) et grande taille, tablette.
  - Rotation de l'écran.
  - Mode sombre.
- **Fonctions :**
  - Navigation entre les 5 onglets et le bouton `+`.
  - Envoi réel d'un rendez-vous et d'un devis : réception du courriel au cabinet.
  - Liens externes : téléphone, e-mail, Maps, LinkedIn, sites officiels.
  - Téléchargement d'un document puis lecture en mode avion.
- **Réseau :**
  - Mode avion : bannière hors connexion, outils fonctionnels, demande mise en file puis renvoyée au retour du réseau.
  - Lien profond : `adb shell am start -a android.intent.action.VIEW -d "chiffreconseil://app/devis"`.

## Mise à jour des barèmes (loi de finances)

Les barèmes sont centralisés dans `lib/features/tools/engines/fiscal_engines.dart`, comme dans `03-calculateurs.js` sur le site.

Après chaque loi de finances :

1. mettre à jour les deux fichiers ;
2. mettre à jour les valeurs attendues dans `test/engines_test.dart` ;
3. recompiler.
