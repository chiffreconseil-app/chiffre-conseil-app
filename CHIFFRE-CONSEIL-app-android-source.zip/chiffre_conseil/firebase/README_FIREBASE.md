# Activer Firebase (Cloud Messaging + Analytics)

L'application est livrée **sans** dépendance Firebase, pour que l'APK se compile sans compte Firebase.
Elle passe par deux interfaces prévues pour cela : `PushBackend` et `AnalyticsBackend`.
Une fois Firebase activé, aucun écran n'est à modifier.

## Étape 1 — Projet Firebase

1. Allez sur https://console.firebase.google.com et créez le projet **CHIFFRE CONSEIL** (Analytics : activé).
2. Ajoutez une application Android avec le nom de paquet **`net.chiffreconseil.app`**.
3. Téléchargez **`google-services.json`** et placez-le dans **`android/app/`**.

Ce fichier ne contient pas de secret serveur, mais ne le publiez pas inutilement.
Pour GitHub Actions, enregistrez-le en base64 dans le secret `GOOGLE_SERVICES_JSON_BASE64`, puis ajoutez avant le build :
```yaml
- run: echo "${{ secrets.GOOGLE_SERVICES_JSON_BASE64 }}" | base64 -d > android/app/google-services.json
```

## Étape 2 — Dépendances et plugin Gradle

```bash
flutter pub add firebase_core firebase_messaging firebase_analytics
dart pub global activate flutterfire_cli
flutterfire configure --project=<id-du-projet> --platforms=android   # génère lib/firebase_options.dart et configure Gradle
```

## Étape 3 — Brancher les adaptateurs

1. Copiez les deux adaptateurs fournis dans `lib/core/services/` :
   - `firebase_push_backend.dart.txt` → `firebase_push_backend.dart`
   - `firebase_analytics_backend.dart.txt` → `firebase_analytics_backend.dart`
2. Dans `lib/main.dart`, avant `AppState(...)` :
   ```dart
   import 'package:firebase_core/firebase_core.dart';
   import 'firebase_options.dart';
   import 'core/services/firebase_push_backend.dart';
   import 'core/services/firebase_analytics_backend.dart';

   await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
   ```
3. Remplacez :
   - `AnalyticsService()` par `AnalyticsService(backend: FirebaseAnalyticsBackend())`
   - `PushService()` par `PushService(backend: FirebasePushBackend())`

## Envoyer une notification

Dans la console Firebase, ouvrez *Messaging*, choisissez *Nouvelle campagne* puis *Notification*, et ciblez un **topic** :

| Topic | Exemple |
|---|---|
| `articles` | « Nouvelle analyse disponible : comment améliorer votre trésorerie. » |
| `ressources` | Nouveau guide pratique |
| `fiscalite` | Note commune, échéance de l'agenda fiscal |
| `outils` | Nouveau simulateur |
| `rendez_vous` | Rappel de rendez-vous |
| `infos` | Information importante du cabinet |

Ajoutez la donnée `route` (par exemple `/blog/gestion-tresorerie-cash-management`) pour ouvrir directement l'écran voulu.
Les préférences de l'utilisateur (Réglages › Notifications) abonnent ou désabonnent l'appareil de chaque topic.

## Confidentialité

La mesure d'audience reste soumise au consentement de l'utilisateur : elle est désactivée par défaut et modifiable dans les réglages.
Mentionnez Firebase dans la politique de confidentialité exigée par Google Play.
