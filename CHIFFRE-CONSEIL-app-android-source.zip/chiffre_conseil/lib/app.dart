import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app_router.dart';
import 'core/theme/cc_theme.dart';
import 'state/app_state.dart';

class ChiffreConseilApp extends StatelessWidget {
  const ChiffreConseilApp({super.key, required this.state});

  final AppState state;

  static final ThemeData _light = CCTheme.light();
  static final ThemeData _dark = CCTheme.dark();

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: _ThemeModeBuilder(
        state: state,
        builder: (mode) => MaterialApp(
          title: 'CHIFFRE CONSEIL',
          debugShowCheckedModeBanner: false,
          theme: _light,
          darkTheme: _dark,
          themeMode: mode,
          locale: const Locale('fr'),
          supportedLocales: const [Locale('fr'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          navigatorKey: AppRouter.navigatorKey,
          onGenerateInitialRoutes: AppRouter.initialRoutes,
          onGenerateRoute: AppRouter.generate,
        ),
      ),
    );
  }
}

/// Ne reconstruit MaterialApp que lorsque le thème change.
class _ThemeModeBuilder extends StatefulWidget {
  const _ThemeModeBuilder({required this.state, required this.builder});
  final AppState state;
  final Widget Function(ThemeMode mode) builder;

  @override
  State<_ThemeModeBuilder> createState() => _ThemeModeBuilderState();
}

class _ThemeModeBuilderState extends State<_ThemeModeBuilder> {
  late ThemeMode _mode = widget.state.themeMode;

  @override
  void initState() {
    super.initState();
    widget.state.addListener(_onChange);
  }

  void _onChange() {
    if (widget.state.themeMode != _mode) setState(() => _mode = widget.state.themeMode);
  }

  @override
  void dispose() {
    widget.state.removeListener(_onChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(_mode);
}
