import 'package:flutter/material.dart';

import 'features/company/checkup_screen.dart';
import 'features/company/company_screen.dart';
import 'features/tools/tool_screen.dart';
import 'ui/screens/about_screen.dart';
import 'ui/screens/article_screen.dart';
import 'ui/screens/expertise_screen.dart';
import 'ui/screens/fiscalite_screen.dart';
import 'ui/screens/forms/contact_screen.dart';
import 'ui/screens/forms/devis_screen.dart';
import 'ui/screens/forms/rdv_screen.dart';
import 'ui/screens/library_screen.dart';
import 'ui/screens/news_screen.dart';
import 'ui/screens/profile/notifications_screen.dart';
import 'ui/screens/profile/requests_screen.dart';
import 'ui/screens/root_gate.dart';
import 'ui/screens/tools_screen.dart';

/// Routes nommées = chemins du site. Les liens profonds
/// (https://chiffreconseil.net/outils, /rendez-vous, /devis, /blog/…) ouvrent
/// directement l'écran correspondant.
class AppRouter {
  AppRouter._();

  static final navigatorKey = GlobalKey<NavigatorState>();

  static String normalize(String? name) {
    if (name == null || name.isEmpty) return '/';
    var path = name;
    final uri = Uri.tryParse(name);
    if (uri != null && uri.path.isNotEmpty) path = uri.path;
    if (path.length > 1 && path.endsWith('/')) path = path.substring(0, path.length - 1);
    return path.isEmpty ? '/' : path;
  }

  static List<Route<dynamic>> initialRoutes(String initialRoute) {
    final routes = <Route<dynamic>>[_page(const RootGate(), '/')];
    final path = normalize(initialRoute);
    if (path != '/') {
      final deep = _build(path, null);
      if (deep != null) routes.add(_page(deep, path));
    }
    return routes;
  }

  static Route<dynamic>? generate(RouteSettings s) {
    final path = normalize(s.name);
    if (path == '/') return _page(const RootGate(), '/');
    final w = _build(path, s.arguments);
    return _page(w ?? const RootGate(), path, args: s.arguments);
  }

  static MaterialPageRoute<dynamic> _page(Widget w, String name, {Object? args}) =>
      MaterialPageRoute<dynamic>(builder: (_) => w, settings: RouteSettings(name: name, arguments: args));

  static Widget? _build(String path, Object? args) {
    final seg = path.split('/').where((s) => s.isNotEmpty).toList();
    if (seg.isEmpty) return null;
    final a = args is Map ? args : const {};
    String? arg(String k) => a[k]?.toString();
    switch (seg[0]) {
      case 'outils':
        return seg.length > 1 ? ToolScreen(slug: seg[1]) : const ToolsScreen(standalone: true);
      case 'rendez-vous':
        return RdvScreen(initialSubject: arg('objet'), note: arg('note'));
      case 'devis':
        return DevisScreen(initialPole: arg('pole'), initialService: arg('prestation'));
      case 'contact':
        return const ContactScreen();
      case 'blog':
      case 'actualites':
        if (seg.length > 1 && seg[1] != 'theme' && seg[1] != 'categorie' && seg[1] != 'auteur') {
          return ArticleScreen(slug: seg[1]);
        }
        return const NewsScreen(standalone: true);
      case 'publications':
      case 'ressources':
        return const LibraryScreen(standalone: true);
      case 'expertises':
        return seg.length > 1 ? ExpertiseScreen(slug: seg[1]) : const AboutScreen();
      case 'a-propos':
      case 'auteur':
        return const AboutScreen();
      case 'fiscalite':
      case 'references-publiques':
        return const FiscaliteScreen();
      case 'check-up':
        return CheckupScreen(companyId: arg('companyId'));
      case 'mon-entreprise':
        return const CompanyHomeScreen();
      case 'notifications':
        return const NotificationsScreen();
      case 'profil':
        if (seg.length > 1 && seg[1] == 'demandes') return const RequestsScreen();
        return null;
      case 'tarifs':
        return const DevisScreen();
      default:
        return null;
    }
  }
}

/// Raccourci de navigation.
Future<dynamic> go(BuildContext context, String path, {Map<String, String>? args}) =>
    Navigator.of(context).pushNamed(path, arguments: args);
