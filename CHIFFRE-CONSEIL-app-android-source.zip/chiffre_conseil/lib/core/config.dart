/// Configuration centrale. Aucune clé secrète : les formulaires utilisent le
/// point d'entrée public du site (même traitement que les formulaires web).
///
/// Les valeurs peuvent être surchargées à la compilation :
///   flutter build apk --dart-define=CC_API_BASE=https://chiffreconseil.net
class AppConfig {
  AppConfig._();

  static const appName = 'CHIFFRE CONSEIL';
  static const slogan = 'LE CONSEIL QUI COMPTE';
  static const tagline = 'L’expertise au service de votre croissance.';
  static const version = '1.0.0';

  static const siteUrl = String.fromEnvironment('CC_SITE', defaultValue: 'https://chiffreconseil.net');
  static const apiBase = String.fromEnvironment('CC_API_BASE', defaultValue: 'https://chiffreconseil.net');

  /// Formulaires (devis, rendez-vous, contact) — POST JSON, cf. api/contact.php.
  static String get formsEndpoint => '$apiBase/api/contact.php';

  /// Articles publiés depuis l'espace de gestion du site (JSON public).
  static String get cmsArticlesEndpoint => '$apiBase/api/articles.php';

  /// Contenu complet pour l'application (généré par tool/extract_site_content.py
  /// et déposé sur le site dans /app/content.json).
  static String get contentEndpoint => '$apiBase/app/content.json';

  /// Numéro WhatsApp : laisser vide tant qu'il n'est pas confirmé.
  /// Exemple : --dart-define=CC_WHATSAPP=21699753706
  static const whatsapp = String.fromEnvironment('CC_WHATSAPP', defaultValue: '');

  /// Source transmise avec chaque demande (visible dans le courriel reçu).
  static const formSource = 'application-android';

  static const requestTimeout = Duration(seconds: 15);
}
