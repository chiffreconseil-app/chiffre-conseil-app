import 'package:flutter/foundation.dart';

/// Backend de mesure d'audience. Par défaut : aucun envoi.
/// Pour Firebase Analytics, voir firebase/README_FIREBASE.md (adaptateur prêt).
abstract class AnalyticsBackend {
  Future<void> logEvent(String name, Map<String, Object> params);
  Future<void> logScreen(String screen);
  Future<void> setEnabled(bool enabled);
}

class NoopAnalyticsBackend implements AnalyticsBackend {
  @override
  Future<void> logEvent(String name, Map<String, Object> params) async {
    if (kDebugMode) debugPrint('[analytics] $name $params');
  }

  @override
  Future<void> logScreen(String screen) async {
    if (kDebugMode) debugPrint('[analytics] screen=$screen');
  }

  @override
  Future<void> setEnabled(bool enabled) async {}
}

/// Événements mesurés (noms stables, conformes aux conventions Firebase).
class AnalyticsService {
  AnalyticsService({AnalyticsBackend? backend}) : _backend = backend ?? NoopAnalyticsBackend();

  AnalyticsBackend _backend;
  bool _consent = false;

  bool get consent => _consent;

  void useBackend(AnalyticsBackend backend) => _backend = backend;

  Future<void> setConsent(bool v) async {
    _consent = v;
    await _backend.setEnabled(v);
  }

  Future<void> screen(String name) async {
    if (_consent) await _backend.logScreen(name);
  }

  Future<void> event(String name, [Map<String, Object> params = const {}]) async {
    if (_consent) await _backend.logEvent(name, params);
  }

  // Raccourcis
  Future<void> toolUsed(String slug) => event('tool_used', {'tool': slug});
  Future<void> articleRead(String slug) => event('article_read', {'article': slug});
  Future<void> documentSaved(String slug) => event('document_download', {'document': slug});
  Future<void> quoteRequested(String service) => event('quote_request', {'service': service});
  Future<void> appointmentRequested(String subject) => event('appointment_request', {'subject': subject});
  Future<void> checkupCompleted(int score) => event('checkup_completed', {'score': score});
}
