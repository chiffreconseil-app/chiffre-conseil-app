import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../config.dart';

class ApiResult {
  final bool ok;
  final String reference;
  final List<String> errors;

  /// true si la requête n'a pas pu joindre le serveur (hors connexion, délai…)
  final bool networkError;
  final int status;

  const ApiResult({required this.ok, this.reference = '', this.errors = const [], this.networkError = false, this.status = 0});
}

/// Client HTTP : HTTPS uniquement, délais maîtrisés, erreurs normalisées.
class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const _headers = {
    'Accept': 'application/json',
    'User-Agent': 'ChiffreConseil-Android/${AppConfig.version}',
  };

  Uri _secure(String url) {
    final u = Uri.parse(url);
    if (u.scheme != 'https') {
      throw ArgumentError('Seules les connexions HTTPS sont autorisées.');
    }
    return u;
  }

  /// GET JSON. Retourne null en cas d'échec (le contenu en cache prend le relais).
  Future<dynamic> getJson(String url) async {
    try {
      final r = await _client.get(_secure(url), headers: _headers).timeout(AppConfig.requestTimeout);
      if (r.statusCode != 200) return null;
      return jsonDecode(utf8.decode(r.bodyBytes));
    } catch (_) {
      return null;
    }
  }

  /// Envoi d'un formulaire vers api/contact.php (même format que le site web).
  Future<ApiResult> submitForm({
    required String type,
    required Map<String, String> fields,
    required int elapsedMs,
  }) async {
    final body = jsonEncode({
      'type': type,
      'champs': {
        ...fields,
        'source': AppConfig.formSource,
        '_hp': '',
        '_t': elapsedMs.toString(),
      },
    });
    try {
      final r = await _client
          .post(
            _secure(AppConfig.formsEndpoint),
            headers: {..._headers, 'Content-Type': 'application/json; charset=utf-8'},
            body: body,
          )
          .timeout(AppConfig.requestTimeout);
      Map<String, dynamic> data = {};
      try {
        final d = jsonDecode(utf8.decode(r.bodyBytes));
        if (d is Map) data = Map<String, dynamic>.from(d);
      } catch (_) {}
      final ok = r.statusCode == 200 && data['ok'] == true;
      final errs = (data['erreurs'] as List? ?? []).map((e) => e.toString()).toList();
      if (!ok && errs.isEmpty) {
        errs.add(r.statusCode == 429
            ? 'Trop de demandes envoyées. Réessayez dans quelques minutes.'
            : 'Le service est momentanément indisponible. Réessayez plus tard ou contactez-nous par téléphone.');
      }
      return ApiResult(ok: ok, reference: (data['id'] ?? '').toString(), errors: errs, status: r.statusCode);
    } on SocketException {
      return const ApiResult(ok: false, networkError: true, errors: ['Vous êtes actuellement hors connexion.']);
    } on TimeoutException {
      return const ApiResult(ok: false, networkError: true, errors: ['Le serveur ne répond pas. Vérifiez votre connexion.']);
    } on http.ClientException {
      return const ApiResult(ok: false, networkError: true, errors: ['Connexion impossible. Vérifiez votre réseau.']);
    } catch (_) {
      return const ApiResult(ok: false, networkError: true, errors: ['Une erreur inattendue est survenue.']);
    }
  }
}
