import 'dart:async';
import 'dart:io';

import 'package:flutter/widgets.dart';

/// Détection légère de la connexion (résolution DNS du site), sans dépendance.
class ConnectivityService extends ChangeNotifier with WidgetsBindingObserver {
  bool _online = true;
  Timer? _timer;
  bool _checking = false;

  bool get online => _online;

  void start() {
    WidgetsBinding.instance.addObserver(this);
    check();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => check());
  }

  Future<bool> check() async {
    if (_checking) return _online;
    _checking = true;
    var ok = false;
    try {
      final r = await InternetAddress.lookup('chiffreconseil.net').timeout(const Duration(seconds: 5));
      ok = r.isNotEmpty && r.first.rawAddress.isNotEmpty;
    } catch (_) {
      ok = false;
    }
    _checking = false;
    _set(ok);
    return ok;
  }

  void reportFailure() => _set(false);
  void reportSuccess() => _set(true);

  void _set(bool v) {
    if (v != _online) {
      _online = v;
      notifyListeners();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) check();
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}
