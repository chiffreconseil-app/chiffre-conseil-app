/// Notifications push. Les thèmes correspondent aux « topics » Firebase Cloud
/// Messaging : il suffit d'envoyer un message au topic depuis la console
/// Firebase pour toucher les abonnés.
///
/// Par défaut : backend inactif (aucune dépendance Firebase dans l'APK).
/// Activation : firebase/README_FIREBASE.md (3 étapes, adaptateur fourni).
abstract class PushBackend {
  Future<void> init();
  Future<void> subscribe(String topic);
  Future<void> unsubscribe(String topic);
}

class NoopPushBackend implements PushBackend {
  @override
  Future<void> init() async {}
  @override
  Future<void> subscribe(String topic) async {}
  @override
  Future<void> unsubscribe(String topic) async {}
}

class PushTopic {
  final String id;
  final String label;
  final String description;
  const PushTopic(this.id, this.label, this.description);
}

class PushService {
  PushService({PushBackend? backend}) : _backend = backend ?? NoopPushBackend();

  PushBackend _backend;
  void useBackend(PushBackend b) => _backend = b;

  static const topics = [
    PushTopic('articles', 'Nouveaux articles', 'Analyses et fiches publiées par le cabinet'),
    PushTopic('ressources', 'Nouvelles ressources', 'Guides pratiques et documents'),
    PushTopic('fiscalite', 'Actualités fiscales', 'Loi de finances, notes communes, échéances'),
    PushTopic('outils', 'Nouveaux outils', 'Simulateurs et calculateurs'),
    PushTopic('rendez_vous', 'Rappels de rendez-vous', 'Rappels liés à vos demandes'),
    PushTopic('infos', 'Informations importantes', 'Annonces du cabinet'),
  ];

  Future<void> init() => _backend.init();

  Future<void> apply(Map<String, bool> prefs) async {
    for (final t in topics) {
      try {
        if (prefs[t.id] ?? true) {
          await _backend.subscribe(t.id);
        } else {
          await _backend.unsubscribe(t.id);
        }
      } catch (_) {}
    }
  }
}
