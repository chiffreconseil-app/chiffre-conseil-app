import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Deux niveaux de stockage :
/// - préférences (non sensibles) : thème, favoris, réglages ;
/// - stockage chiffré (Android Keystore) : profil, entreprises, demandes.
class StorageService {
  StorageService._(this._prefs);

  final SharedPreferences _prefs;
  final FlutterSecureStorage _secure = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static Future<StorageService> create() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService._(prefs);
  }

  // ------------------------------- préférences -----------------------------
  String? getString(String key) => _prefs.getString(key);
  Future<void> setString(String key, String value) => _prefs.setString(key, value);
  bool getBool(String key, {bool fallback = false}) => _prefs.getBool(key) ?? fallback;
  Future<void> setBool(String key, bool value) => _prefs.setBool(key, value);
  List<String> getList(String key) => _prefs.getStringList(key) ?? const [];
  Future<void> setList(String key, List<String> value) => _prefs.setStringList(key, value);
  Future<void> remove(String key) => _prefs.remove(key);

  // --------------------------------- chiffré --------------------------------
  Future<Map<String, dynamic>?> readSecureJson(String key) async {
    try {
      final raw = await _secure.read(key: key);
      if (raw == null || raw.isEmpty) return null;
      final v = jsonDecode(raw);
      return v is Map ? Map<String, dynamic>.from(v) : null;
    } catch (_) {
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> readSecureList(String key) async {
    try {
      final raw = await _secure.read(key: key);
      if (raw == null || raw.isEmpty) return [];
      final v = jsonDecode(raw);
      if (v is! List) return [];
      return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> writeSecure(String key, Object value) async {
    try {
      await _secure.write(key: key, value: jsonEncode(value));
    } catch (_) {
      // Le stockage chiffré peut être indisponible sur certains émulateurs :
      // l'application reste utilisable, la donnée n'est simplement pas conservée.
    }
  }

  Future<void> deleteSecure(String key) async {
    try {
      await _secure.delete(key: key);
    } catch (_) {}
  }

  /// Effacement complet (bouton « Supprimer mes données »).
  Future<void> wipeAll() async {
    await _prefs.clear();
    try {
      await _secure.deleteAll();
    } catch (_) {}
  }
}
