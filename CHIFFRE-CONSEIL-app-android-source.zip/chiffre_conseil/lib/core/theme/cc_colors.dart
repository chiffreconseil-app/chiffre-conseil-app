import 'package:flutter/material.dart';

/// Palette officielle — Brand Book CHIFFRE CONSEIL « Le C décisif ».
/// (Le cahier des charges citait #0B1F5B / #FF6A00 : ce sont les anciennes
/// valeurs ; l'application applique la charte en vigueur.)
class CC {
  CC._();
  static const navy = Color(0xFF0E1B4D); // Bleu Nuit
  static const navyDeep = Color(0xFF0A1439);
  static const navySoft = Color(0xFF16265F);
  static const orange = Color(0xFFFF5A1F); // Orange Décision
  static const orangeText = Color(0xFFC2410C); // Orange Texte (contraste AA)
  static const blue = Color(0xFF2F6BFF); // Bleu Horizon
  static const white = Color(0xFFFFFFFF);
  static const mist = Color(0xFFF5F7FA); // Gris très clair
  static const line = Color(0xFFDDE2EC);
  static const ink = Color(0xFF1F2A44);
  static const steel = Color(0xFF5B6478);
  static const muted = Color(0xFF8A90A2);
  static const success = Color(0xFF12A150); // indicateurs positifs
  static const danger = Color(0xFFD92D20); // alertes
  static const warning = Color(0xFFE08A00);

  // Mode sombre
  static const darkBg = Color(0xFF070D24);
  static const darkSurface = Color(0xFF0F1838);
  static const darkCard = Color(0xFF152048);
  static const darkLine = Color(0xFF26325E);
  static const darkText = Color(0xFFE8ECF7);
  static const darkMuted = Color(0xFFA3ACC7);
  static const orangeLight = Color(0xFFFF8A5C);

  /// Couleur d'un score 0..100 : vert / orange / rouge.
  static Color score(double v) {
    if (v >= 70) return success;
    if (v >= 45) return warning;
    return danger;
  }
}
