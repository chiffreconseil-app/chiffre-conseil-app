import 'package:flutter/material.dart';

import 'cc_colors.dart';

/// Thèmes clair et sombre. Les composants sont stylés localement (voir
/// ui/widgets) afin de rester compatibles avec toutes les versions récentes
/// de Flutter.
class CCTheme {
  CCTheme._();

  static const font = 'Montserrat';

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: CC.navy,
      brightness: Brightness.light,
      primary: CC.navy,
      onPrimary: CC.white,
      secondary: CC.orange,
      onSecondary: CC.white,
      tertiary: CC.blue,
      surface: CC.white,
      onSurface: CC.ink,
      error: CC.danger,
    );
    return _base(scheme, CC.mist);
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: CC.navy,
      brightness: Brightness.dark,
      primary: CC.orangeLight,
      onPrimary: CC.navyDeep,
      secondary: CC.orange,
      onSecondary: CC.white,
      tertiary: CC.blue,
      surface: CC.darkSurface,
      onSurface: CC.darkText,
      error: const Color(0xFFFF6B5E),
    );
    return _base(scheme, CC.darkBg);
  }

  static ThemeData _base(ColorScheme scheme, Color bg) {
    final isDark = scheme.brightness == Brightness.dark;
    final text = (isDark ? Typography.material2021().white : Typography.material2021().black)
        .apply(fontFamily: font, bodyColor: scheme.onSurface, displayColor: scheme.onSurface);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      fontFamily: font,
      scaffoldBackgroundColor: bg,
      textTheme: text.copyWith(
        headlineMedium: text.headlineMedium?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.4),
        headlineSmall: text.headlineSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.3),
        titleLarge: text.titleLarge?.copyWith(fontWeight: FontWeight.w800),
        titleMedium: text.titleMedium?.copyWith(fontWeight: FontWeight.w700),
        titleSmall: text.titleSmall?.copyWith(fontWeight: FontWeight.w700),
        bodyLarge: text.bodyLarge?.copyWith(height: 1.55),
        bodyMedium: text.bodyMedium?.copyWith(height: 1.5),
        labelLarge: text.labelLarge?.copyWith(fontWeight: FontWeight.w700, letterSpacing: 0.3),
      ),
      dividerColor: isDark ? CC.darkLine : CC.line,
      splashFactory: InkRipple.splashFactory,
      visualDensity: VisualDensity.standard,
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeForwardsPageTransitionsBuilderCompat(),
      }),
    );
  }
}

/// Transition sobre (fondu + léger glissement), identique sur toutes les
/// versions de Flutter.
class FadeForwardsPageTransitionsBuilderCompat extends PageTransitionsBuilder {
  const FadeForwardsPageTransitionsBuilderCompat();

  @override
  Widget buildTransitions<T>(PageRoute<T> route, BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero).animate(curved),
        child: child,
      ),
    );
  }
}

/// Raccourcis de couleurs dépendant du thème.
extension CCContext on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  Color get cardColor => isDark ? CC.darkCard : CC.white;
  Color get lineColor => isDark ? CC.darkLine : CC.line;
  Color get mutedText => isDark ? CC.darkMuted : CC.steel;
  Color get strongText => isDark ? CC.darkText : CC.navy;
  Color get accentText => isDark ? CC.orangeLight : CC.orangeText;
  Color get softFill => isDark ? CC.darkSurface : CC.mist;
  TextTheme get tt => Theme.of(this).textTheme;
}
