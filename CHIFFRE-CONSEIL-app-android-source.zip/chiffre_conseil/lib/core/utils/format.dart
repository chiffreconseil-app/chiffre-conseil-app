/// Formats français (séparateur de milliers : espace insécable fine, décimales : virgule).
class Fmt {
  Fmt._();

  static const _nbsp = ' ';

  /// 1234567.891 -> "1 234 567,891"
  static String num(double x, {int d = 3}) {
    if (x.isNaN || x.isInfinite) x = 0;
    final neg = x < 0;
    final fixed = x.abs().toStringAsFixed(d);
    final parts = fixed.split('.');
    final intPart = parts[0];
    final buf = StringBuffer();
    for (var i = 0; i < intPart.length; i++) {
      final fromEnd = intPart.length - i;
      buf.write(intPart[i]);
      if (fromEnd > 1 && fromEnd % 3 == 1) buf.write(_nbsp);
    }
    var s = buf.toString();
    if (d > 0) s = '$s,${parts[1]}';
    final isZero = (double.tryParse(fixed) ?? 0) == 0;
    return neg && !isZero ? '-$s' : s;
  }

  static String dt(double x) => '${num(x)} TND';

  static String pct(double ratio, {int d = 2}) => '${num(ratio * 100, d: d)} %';

  /// Taux "0.015" -> "1,5 %" (sans zéros inutiles)
  static String rate(double ratio) {
    var s = (ratio * 100).toStringAsFixed(3);
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return '${s.replaceAll('.', ',')} %';
  }

  static const _months = [
    'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'
  ];
  static const _days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];

  static String date(DateTime d) => '${d.day} ${_months[d.month - 1]} ${d.year}';

  static String dateLong(DateTime d) => '${_days[d.weekday - 1]} ${date(d)}';

  static String monthYear(DateTime d) => '${_months[d.month - 1]} ${d.year}';

  /// "2026-09-21" -> "21 septembre 2026"
  static String isoDate(String iso) {
    final d = DateTime.tryParse(iso);
    return d == null ? iso : date(d);
  }

  static String shortDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  /// Lecture d'un nombre saisi ("1 234,5" ou "1234.5").
  static double parse(String s) {
    final c = s.replaceAll(RegExp(r'[\s  ]'), '').replaceAll(',', '.');
    return double.tryParse(c) ?? 0;
  }
}
