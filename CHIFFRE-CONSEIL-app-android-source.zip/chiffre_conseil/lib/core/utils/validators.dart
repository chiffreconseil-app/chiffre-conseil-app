/// Règles alignées sur la validation du serveur (api/contact.php).
class Validators {
  Validators._();

  static final _email = RegExp(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$");
  static final _phone = RegExp(r'^[+()\d][\d\s().-]{6,}$');

  static String? required(String? v, [String label = 'Ce champ']) {
    if (v == null || v.trim().isEmpty) return '$label est obligatoire.';
    if (v.trim().length > 200) return 'Texte trop long.';
    return null;
  }

  static String? email(String? v, {bool required = true}) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return required ? 'L’adresse e-mail est obligatoire.' : null;
    if (!_email.hasMatch(s) || s.length > 120) return 'L’adresse e-mail n’est pas valide.';
    return null;
  }

  static String? phone(String? v, {bool required = true}) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return required ? 'Le téléphone est obligatoire.' : null;
    if (!_phone.hasMatch(s) || s.length > 30) return 'Le numéro de téléphone n’est pas valide.';
    return null;
  }

  static String? message(String? v, {int min = 0, int max = 4000}) {
    final s = (v ?? '').trim();
    if (s.length < min) return min == 1 ? 'Le message est obligatoire.' : 'Merci de préciser votre besoin ($min caractères minimum).';
    if (s.length > max) return 'Message trop long ($max caractères maximum).';
    return null;
  }

  /// Nettoyage : suppression des caractères de contrôle.
  static String clean(String s) => s.replaceAll(RegExp(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]'), '').trim();
}
