// Modèles du contenu publié sur chiffreconseil.net.

List<String> _strList(dynamic v) => v is List ? v.map((e) => e.toString()).toList() : <String>[];

class ArticleBlock {
  /// h2, h3, h4, p, ul, ol, dl, table, callout, formula, quote
  final String type;
  final String text;
  final List<String> items;
  final List<List<String>> rows; // table rows or dl pairs

  const ArticleBlock({required this.type, this.text = '', this.items = const [], this.rows = const []});

  Map<String, dynamic> toJson() {
    if (type == 'dl') return {'t': type, 'i': rows};
    if (type == 'table') return {'t': type, 'r': rows};
    return {'t': type, 'x': text, if (items.isNotEmpty) 'i': items};
  }

  factory ArticleBlock.fromJson(Map<String, dynamic> j) {
    final t = (j['t'] ?? 'p').toString();
    if (t == 'dl') {
      final pairs = (j['i'] as List? ?? []).map((e) => _strList(e)).toList();
      return ArticleBlock(type: t, rows: pairs);
    }
    if (t == 'table') {
      final rows = (j['r'] as List? ?? []).map((e) => _strList(e)).toList();
      return ArticleBlock(type: t, rows: rows);
    }
    return ArticleBlock(type: t, text: (j['x'] ?? '').toString(), items: _strList(j['i']));
  }
}

class Article {
  final String slug;
  final String title;
  final String subtitle;
  final String tag;
  final String section;
  final String date; // ISO yyyy-mm-dd
  final String author;
  final String description;
  final String image; // URL distante
  final String thumb; // image embarquée (assets) si disponible
  final String url;
  final String kind; // publication | guide | news
  final String shortAnswer;
  final List<ArticleBlock> blocks;

  const Article({
    required this.slug,
    required this.title,
    this.subtitle = '',
    this.tag = '',
    this.section = '',
    this.date = '',
    this.author = '',
    this.description = '',
    this.image = '',
    this.thumb = '',
    required this.url,
    this.kind = 'publication',
    this.shortAnswer = '',
    this.blocks = const [],
  });

  bool get hasBody => blocks.isNotEmpty || shortAnswer.isNotEmpty;

  String get kindLabel => switch (kind) {
        'guide' => 'Guide pratique',
        'news' => 'Actualité',
        _ => 'Fiche',
      };

  /// Catégorie simplifiée pour les filtres de la bibliothèque.
  String get category {
    final s = section.toLowerCase();
    if (s.contains('fiscal') || s.contains('loi de finances')) return 'Fiscalité';
    if (s.contains('grh') || s.contains('paie')) return 'GRH & Paie';
    if (s.contains('risk')) return 'Risk Management';
    if (s.contains('investissement')) return 'Investissement';
    if (s.contains('gestion')) return 'Gestion';
    if (s.contains('banque') || s.contains('financement')) return 'Banque & Financement';
    if (s.contains('comptab')) return 'Comptabilité';
    if (s.isEmpty) return 'Actualités';
    return 'Finance';
  }

  String get searchText => '$title $subtitle $tag $section $description'.toLowerCase();

  Map<String, dynamic> toJson() => {
        'slug': slug,
        'title': title,
        'subtitle': subtitle,
        'tag': tag,
        'section': section,
        'date': date,
        'author': author,
        'description': description,
        'image': image,
        'thumb': thumb,
        'url': url,
        'kind': kind,
        'short': shortAnswer,
        'blocks': blocks.map((b) => b.toJson()).toList(),
      };

  factory Article.fromJson(Map<String, dynamic> j) => Article(
        slug: (j['slug'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        subtitle: (j['subtitle'] ?? '').toString(),
        tag: (j['tag'] ?? '').toString(),
        section: (j['section'] ?? '').toString(),
        date: (j['date'] ?? '').toString(),
        author: (j['author'] ?? '').toString(),
        description: (j['description'] ?? '').toString(),
        image: (j['image'] ?? '').toString(),
        thumb: (j['thumb'] ?? '').toString(),
        url: (j['url'] ?? '').toString(),
        kind: (j['kind'] ?? 'publication').toString(),
        shortAnswer: (j['short'] ?? '').toString(),
        blocks: (j['blocks'] as List? ?? [])
            .whereType<Map>()
            .map((e) => ArticleBlock.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );

  /// Article publié depuis l'espace de gestion (api/articles.php) : pas de corps.
  factory Article.fromCms(Map<String, dynamic> j, String siteUrl) {
    final url = (j['url'] ?? '').toString();
    final abs = url.startsWith('http') ? url : '$siteUrl$url';
    final segments = url.split('/').where((s) => s.isNotEmpty).toList();
    final slug = segments.isEmpty ? url : segments.last;
    final img = (j['image'] ?? '').toString();
    return Article(
      slug: slug,
      title: (j['titre'] ?? '').toString(),
      section: (j['categorie'] ?? '').toString(),
      tag: (j['categorie'] ?? '').toString(),
      date: (j['date'] ?? '').toString(),
      author: (j['auteur'] ?? '').toString(),
      description: (j['extrait'] ?? '').toString(),
      image: img.isEmpty ? '' : (img.startsWith('http') ? img : '$siteUrl$img'),
      url: abs,
      kind: 'news',
    );
  }
}

class Expertise {
  final String slug;
  final String icon;
  final String name;
  final String punch;
  final String intro;
  final List<String> pains;
  final List<String> services;
  final List<String> deliverables;
  final List<String> tools;
  final List<List<String>> prices; // [code, nom, description, unité, prix]

  const Expertise({
    required this.slug,
    required this.icon,
    required this.name,
    required this.punch,
    required this.intro,
    this.pains = const [],
    this.services = const [],
    this.deliverables = const [],
    this.tools = const [],
    this.prices = const [],
  });

  factory Expertise.fromJson(Map<String, dynamic> j) => Expertise(
        slug: (j['slug'] ?? '').toString(),
        icon: (j['ico'] ?? '').toString(),
        name: (j['nom'] ?? '').toString(),
        punch: (j['punch'] ?? '').toString(),
        intro: (j['intro'] ?? '').toString(),
        pains: _strList(j['douleurs']),
        services: _strList(j['presta']),
        deliverables: _strList(j['livrables']),
        tools: _strList(j['outils']),
        prices: (j['tarifs'] as List? ?? []).map((e) => _strList(e)).toList(),
      );
}

class SiteTool {
  final String slug;
  final String icon;
  final String name;
  final String short;
  final String title;
  final String description;
  final String intro;

  const SiteTool({
    required this.slug,
    required this.icon,
    required this.name,
    required this.short,
    required this.title,
    required this.description,
    required this.intro,
  });

  factory SiteTool.fromJson(Map<String, dynamic> j) => SiteTool(
        slug: (j['slug'] ?? '').toString(),
        icon: (j['ico'] ?? '').toString(),
        name: (j['nom'] ?? '').toString(),
        short: (j['court'] ?? '').toString(),
        title: (j['h1'] ?? '').toString(),
        description: (j['desc'] ?? '').toString(),
        intro: (j['intro'] ?? '').toString(),
      );
}

class ReferenceLink {
  final String institution;
  final String title;
  final String url;

  const ReferenceLink({required this.institution, required this.title, required this.url});

  factory ReferenceLink.fromJson(Map<String, dynamic> j) => ReferenceLink(
        institution: (j['institution'] ?? '').toString(),
        title: (j['titre'] ?? '').toString(),
        url: (j['url'] ?? '').toString(),
      );
}

class AboutInfo {
  final String mission;
  final String founded;
  final List<List<String>> vision;
  final List<List<String>> values;
  final List<List<String>> journey;

  const AboutInfo({
    this.mission = '',
    this.founded = '',
    this.vision = const [],
    this.values = const [],
    this.journey = const [],
  });

  factory AboutInfo.fromJson(Map<String, dynamic> j) {
    List<List<String>> pairs(dynamic v) => (v as List? ?? []).map((e) => _strList(e)).toList();
    return AboutInfo(
      mission: (j['mission'] ?? '').toString(),
      founded: (j['founded'] ?? '').toString(),
      vision: pairs(j['vision']),
      values: pairs(j['values']),
      journey: pairs(j['journey']),
    );
  }
}

class ContactInfo {
  final String name;
  final List<String> address;
  final String phone;
  final String email;
  final String site;
  final String linkedinCabinet;
  final String linkedinDirector;
  final String director;
  final String maps;

  const ContactInfo({
    this.name = 'CHIFFRE CONSEIL',
    this.address = const ['Avenue Hedi Nouira', 'Ennasr 2, Ariana', 'Tunisie'],
    this.phone = '+216 99 753 706',
    this.email = 'chiffreconseil@gmail.com',
    this.site = 'https://chiffreconseil.net',
    this.linkedinCabinet = 'https://www.linkedin.com/company/chiffreconseil/',
    this.linkedinDirector = 'https://www.linkedin.com/in/khammassi-houssem/',
    this.director = 'M. Houssem Khammassi, Directeur Général',
    this.maps = 'https://www.google.com/maps/search/?api=1&query=Avenue+Hedi+Nouira+Ennasr+2+Ariana+Tunisie',
  });

  factory ContactInfo.fromJson(Map<String, dynamic> j) {
    const d = ContactInfo();
    String s(String k, String def) => (j[k] ?? def).toString();
    return ContactInfo(
      name: s('name', d.name),
      address: j['address'] is List ? _strList(j['address']) : d.address,
      phone: s('phone', d.phone),
      email: s('email', d.email),
      site: s('site', d.site),
      linkedinCabinet: s('linkedinCabinet', d.linkedinCabinet),
      linkedinDirector: s('linkedinDirector', d.linkedinDirector),
      director: s('director', d.director),
      maps: s('maps', d.maps),
    );
  }
}

class ContentBundle {
  final String version;
  final ContactInfo contact;
  final AboutInfo about;
  final List<Expertise> expertises;
  final List<SiteTool> tools;
  final List<ReferenceLink> references;
  final List<Article> articles;

  const ContentBundle({
    required this.version,
    required this.contact,
    required this.about,
    required this.expertises,
    required this.tools,
    required this.references,
    required this.articles,
  });

  factory ContentBundle.fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> maps(dynamic v) =>
        (v as List? ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    return ContentBundle(
      version: (j['version'] ?? '').toString(),
      contact: j['contact'] is Map ? ContactInfo.fromJson(Map<String, dynamic>.from(j['contact'] as Map)) : const ContactInfo(),
      about: j['about'] is Map ? AboutInfo.fromJson(Map<String, dynamic>.from(j['about'] as Map)) : const AboutInfo(),
      expertises: maps(j['expertises']).map(Expertise.fromJson).toList(),
      tools: maps(j['tools']).map(SiteTool.fromJson).toList(),
      references: maps(j['references']).map(ReferenceLink.fromJson).toList(),
      articles: maps(j['articles']).map(Article.fromJson).toList(),
    );
  }

  ContentBundle withExtraArticles(List<Article> extra) {
    if (extra.isEmpty) return this;
    final known = articles.map((a) => a.slug).toSet();
    final merged = [...extra.where((a) => !known.contains(a.slug)), ...articles];
    merged.sort((a, b) => b.date.compareTo(a.date));
    return ContentBundle(
      version: version,
      contact: contact,
      about: about,
      expertises: expertises,
      tools: tools,
      references: references,
      articles: merged,
    );
  }

  Expertise? expertise(String slug) {
    for (final e in expertises) {
      if (e.slug == slug) return e;
    }
    return null;
  }

  Article? article(String slug) {
    for (final a in articles) {
      if (a.slug == slug) return a;
    }
    return null;
  }

  SiteTool? tool(String slug) {
    for (final t in tools) {
      if (t.slug == slug) return t;
    }
    return null;
  }
}
