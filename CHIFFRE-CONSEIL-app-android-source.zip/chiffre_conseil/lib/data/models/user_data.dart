// Données de l'utilisateur, stockées chiffrées sur l'appareil (aucun serveur).

class UserProfile {
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final String company;

  const UserProfile({this.firstName = '', this.lastName = '', this.email = '', this.phone = '', this.company = ''});

  bool get isEmpty => firstName.isEmpty && lastName.isEmpty && email.isEmpty && phone.isEmpty;
  String get fullName => '$firstName $lastName'.trim();

  UserProfile copyWith({String? firstName, String? lastName, String? email, String? phone, String? company}) => UserProfile(
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        email: email ?? this.email,
        phone: phone ?? this.phone,
        company: company ?? this.company,
      );

  Map<String, dynamic> toJson() => {'fn': firstName, 'ln': lastName, 'em': email, 'ph': phone, 'co': company};

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
        firstName: (j['fn'] ?? '').toString(),
        lastName: (j['ln'] ?? '').toString(),
        email: (j['em'] ?? '').toString(),
        phone: (j['ph'] ?? '').toString(),
        company: (j['co'] ?? '').toString(),
      );
}

/// Résultat du Check-up : score par domaine (0..100) et score global.
class CheckupResult {
  final DateTime date;
  final Map<String, double> domains;
  final double global;

  const CheckupResult({required this.date, required this.domains, required this.global});

  Map<String, dynamic> toJson() => {'d': date.toIso8601String(), 's': domains, 'g': global};

  factory CheckupResult.fromJson(Map<String, dynamic> j) {
    final raw = j['s'] is Map ? Map<String, dynamic>.from(j['s'] as Map) : <String, dynamic>{};
    return CheckupResult(
      date: DateTime.tryParse((j['d'] ?? '').toString()) ?? DateTime.now(),
      domains: raw.map((k, v) => MapEntry(k, (v as num).toDouble())),
      global: ((j['g'] ?? 0) as num).toDouble(),
    );
  }
}

class Company {
  final String id;
  final String name;
  final String sector;
  final String city;
  final String size;
  final String revenue;
  final String employees;
  final String situation;
  final List<String> goals;
  final CheckupResult? checkup;

  const Company({
    required this.id,
    required this.name,
    this.sector = '',
    this.city = '',
    this.size = '',
    this.revenue = '',
    this.employees = '',
    this.situation = '',
    this.goals = const [],
    this.checkup,
  });

  Company copyWith({
    String? name,
    String? sector,
    String? city,
    String? size,
    String? revenue,
    String? employees,
    String? situation,
    List<String>? goals,
    CheckupResult? checkup,
  }) =>
      Company(
        id: id,
        name: name ?? this.name,
        sector: sector ?? this.sector,
        city: city ?? this.city,
        size: size ?? this.size,
        revenue: revenue ?? this.revenue,
        employees: employees ?? this.employees,
        situation: situation ?? this.situation,
        goals: goals ?? this.goals,
        checkup: checkup ?? this.checkup,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'n': name,
        'se': sector,
        'ci': city,
        'sz': size,
        'ca': revenue,
        'em': employees,
        'si': situation,
        'go': goals,
        if (checkup != null) 'ck': checkup!.toJson(),
      };

  factory Company.fromJson(Map<String, dynamic> j) => Company(
        id: (j['id'] ?? '').toString(),
        name: (j['n'] ?? '').toString(),
        sector: (j['se'] ?? '').toString(),
        city: (j['ci'] ?? '').toString(),
        size: (j['sz'] ?? '').toString(),
        revenue: (j['ca'] ?? '').toString(),
        employees: (j['em'] ?? '').toString(),
        situation: (j['si'] ?? '').toString(),
        goals: (j['go'] as List? ?? []).map((e) => e.toString()).toList(),
        checkup: j['ck'] is Map ? CheckupResult.fromJson(Map<String, dynamic>.from(j['ck'] as Map)) : null,
      );
}

enum RequestKind { rendezVous, devis, contact }

enum RequestStatus { sent, pending }

/// Historique local des demandes envoyées depuis l'application.
class RequestRecord {
  final String id;
  final RequestKind kind;
  final DateTime createdAt;
  final String title;
  final String summary;
  final RequestStatus status;
  final String serverRef;
  final Map<String, String> fields;
  final DateTime? appointment; // date souhaitée (rendez-vous)

  const RequestRecord({
    required this.id,
    required this.kind,
    required this.createdAt,
    required this.title,
    required this.summary,
    required this.status,
    this.serverRef = '',
    this.fields = const {},
    this.appointment,
  });

  String get typeLabel => switch (kind) {
        RequestKind.rendezVous => 'Demande de rendez-vous',
        RequestKind.devis => 'Demande de devis',
        RequestKind.contact => 'Message de contact',
      };

  RequestRecord copyWith({RequestStatus? status, String? serverRef}) => RequestRecord(
        id: id,
        kind: kind,
        createdAt: createdAt,
        title: title,
        summary: summary,
        status: status ?? this.status,
        serverRef: serverRef ?? this.serverRef,
        fields: fields,
        appointment: appointment,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'k': kind.name,
        'c': createdAt.toIso8601String(),
        't': title,
        's': summary,
        'st': status.name,
        'r': serverRef,
        'f': fields,
        if (appointment != null) 'a': appointment!.toIso8601String(),
      };

  factory RequestRecord.fromJson(Map<String, dynamic> j) => RequestRecord(
        id: (j['id'] ?? '').toString(),
        kind: RequestKind.values.firstWhere((k) => k.name == j['k'], orElse: () => RequestKind.contact),
        createdAt: DateTime.tryParse((j['c'] ?? '').toString()) ?? DateTime.now(),
        title: (j['t'] ?? '').toString(),
        summary: (j['s'] ?? '').toString(),
        status: RequestStatus.values.firstWhere((k) => k.name == j['st'], orElse: () => RequestStatus.sent),
        serverRef: (j['r'] ?? '').toString(),
        fields: j['f'] is Map ? Map<String, dynamic>.from(j['f'] as Map).map((k, v) => MapEntry(k, v.toString())) : const {},
        appointment: j['a'] == null ? null : DateTime.tryParse(j['a'].toString()),
      );
}

/// Notification affichée dans le centre de notifications de l'application.
class AppNotice {
  final String id;
  final String topic;
  final String title;
  final String body;
  final DateTime date;
  final String route;
  final bool read;

  const AppNotice({
    required this.id,
    required this.topic,
    required this.title,
    required this.body,
    required this.date,
    this.route = '',
    this.read = false,
  });

  AppNotice markRead() => AppNotice(id: id, topic: topic, title: title, body: body, date: date, route: route, read: true);

  Map<String, dynamic> toJson() =>
      {'id': id, 'tp': topic, 't': title, 'b': body, 'd': date.toIso8601String(), 'r': route, 'rd': read};

  factory AppNotice.fromJson(Map<String, dynamic> j) => AppNotice(
        id: (j['id'] ?? '').toString(),
        topic: (j['tp'] ?? '').toString(),
        title: (j['t'] ?? '').toString(),
        body: (j['b'] ?? '').toString(),
        date: DateTime.tryParse((j['d'] ?? '').toString()) ?? DateTime.now(),
        route: (j['r'] ?? '').toString(),
        read: j['rd'] == true,
      );
}
