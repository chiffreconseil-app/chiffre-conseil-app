import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';

import '../../core/config.dart';
import '../../core/services/api_client.dart';
import '../models/content.dart';

/// Contenu : instantané embarqué (hors ligne dès l'installation), cache local,
/// puis actualisation depuis chiffreconseil.net.
class ContentRepository {
  ContentRepository(this._api);

  final ApiClient _api;
  static const _cacheFile = 'content_cache.json';

  Future<File?> _file() async {
    try {
      final dir = await getApplicationSupportDirectory();
      return File('${dir.path}/$_cacheFile');
    } catch (_) {
      return null;
    }
  }

  /// Chargement initial : cache (s'il est plus récent) sinon instantané embarqué.
  Future<ContentBundle> loadLocal() async {
    final bundledRaw = await rootBundle.loadString('assets/data/content.json');
    final bundled = ContentBundle.fromJson(Map<String, dynamic>.from(jsonDecode(bundledRaw) as Map));
    try {
      final f = await _file();
      if (f != null && await f.exists()) {
        final cached = ContentBundle.fromJson(Map<String, dynamic>.from(jsonDecode(await f.readAsString()) as Map));
        if (cached.articles.isNotEmpty && cached.version.compareTo(bundled.version) >= 0) return cached;
      }
    } catch (_) {
      // cache illisible : on garde l'instantané embarqué
    }
    return bundled;
  }

  /// Actualisation réseau. Retourne null si rien n'a pu être récupéré.
  Future<ContentBundle?> refresh(ContentBundle current) async {
    ContentBundle? next;
    final remote = await _api.getJson(AppConfig.contentEndpoint);
    if (remote is Map) {
      try {
        final b = ContentBundle.fromJson(Map<String, dynamic>.from(remote));
        if (b.articles.isNotEmpty && b.version.compareTo(current.version) >= 0) {
          next = b;
          final f = await _file();
          await f?.writeAsString(jsonEncode(remote));
        }
      } catch (_) {}
    }
    // Articles publiés depuis l'espace de gestion du site
    final cms = await _api.getJson(AppConfig.cmsArticlesEndpoint);
    if (cms is Map && cms['articles'] is List) {
      final extra = (cms['articles'] as List)
          .whereType<Map>()
          .map((e) => Article.fromCms(Map<String, dynamic>.from(e), AppConfig.siteUrl))
          .where((a) => a.title.isNotEmpty)
          .toList();
      next = (next ?? current).withExtraArticles(extra);
    }
    if (remote == null && cms == null) return null;
    return next ?? current;
  }
}
