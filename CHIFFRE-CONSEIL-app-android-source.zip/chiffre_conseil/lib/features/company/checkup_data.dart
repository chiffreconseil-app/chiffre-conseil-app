// CHECK-UP CHIFFRE CONSEIL : questionnaire d'orientation (non certifié).

class CheckupQuestion {
  final String domain;
  final String text;
  final List<String> options; // score = index (0..3)
  const CheckupQuestion(this.domain, this.text, this.options);
}

class CheckupDomain {
  final String id;
  final String label;
  final String expertise; // slug de l'expertise du site
  final String low; // recommandation si score < 45
  final String mid; // si 45..69
  final String high; // si >= 70
  const CheckupDomain(this.id, this.label, this.expertise, this.low, this.mid, this.high);

  String advice(double score) => score < 45 ? low : (score < 70 ? mid : high);
}

const _scale = ['Non', 'Partiellement ou de façon informelle', 'Oui, en grande partie', 'Oui, formalisé et suivi régulièrement'];

const checkupDomains = [
  CheckupDomain('tresorerie', 'Trésorerie', 'finance',
      'Priorité : mettre en place un plan de trésorerie prévisionnel et un suivi des encaissements clients.',
      'Formaliser le plan de trésorerie sur 6 à 12 mois et renforcer les relances clients.',
      'Pilotage de la trésorerie satisfaisant : optimiser le BFR et anticiper les besoins de financement.'),
  CheckupDomain('rentabilite', 'Rentabilité', 'finance',
      'Priorité : calculer la marge par activité et le seuil de rentabilité pour savoir où l’entreprise gagne ou perd de l’argent.',
      'Affiner l’analyse des coûts et suivre la marge par activité dans un tableau de bord.',
      'Bonne visibilité sur la rentabilité : piloter par les écarts budget / réalisé.'),
  CheckupDomain('fiscalite', 'Fiscalité', 'fiscalite',
      'Priorité : sécuriser les déclarations et les retenues à la source (TEJ) pour limiter le risque de pénalités.',
      'Mettre en place un calendrier fiscal et une revue périodique des taux appliqués.',
      'Conformité bien suivie : envisager un diagnostic fiscal pour optimiser dans le cadre réglementaire.'),
  CheckupDomain('organisation', 'Organisation', 'management',
      'Priorité : clarifier les rôles (organigramme, fiches de responsabilités) et formaliser les processus clés.',
      'Compléter les procédures écrites et installer un tableau de bord opérationnel.',
      'Organisation structurée : consolider le management par objectifs et l’amélioration continue.'),
  CheckupDomain('rh', 'Ressources humaines', 'grh',
      'Priorité : fiabiliser la paie, les déclarations CNSS et la conformité des contrats.',
      'Formaliser les fiches de poste, les évaluations et les indicateurs RH.',
      'Gestion RH solide : développer les compétences et la politique de rémunération.'),
  CheckupDomain('marketing', 'Marketing', 'marketing',
      'Priorité : définir le positionnement et une présence en ligne qui génère des demandes.',
      'Structurer le plan marketing et mesurer le coût d’acquisition client.',
      'Démarche commerciale efficace : travailler la fidélisation et la croissance du chiffre d’affaires.'),
  CheckupDomain('strategie', 'Stratégie', 'finance',
      'Priorité : fixer des objectifs chiffrés et construire un prévisionnel pour appuyer les décisions.',
      'Mettre à jour le business plan et relier la stratégie au budget annuel.',
      'Vision claire : suivre l’exécution du plan et ajuster avec des indicateurs fiables.'),
];

const checkupQuestions = [
  // Trésorerie
  CheckupQuestion('tresorerie', 'Suivez-vous votre trésorerie avec un plan de trésorerie prévisionnel ?', [
    'Non, aucun suivi particulier',
    'Je consulte surtout le solde bancaire',
    'Suivi mensuel des encaissements et décaissements',
    'Plan prévisionnel sur 6 à 12 mois, mis à jour chaque mois',
  ]),
  CheckupQuestion('tresorerie', 'Vos clients vous paient-ils dans les délais convenus ?', [
    'Retards fréquents et importants',
    'Retards réguliers',
    'Retards occasionnels',
    'Paiements dans les délais, relances organisées',
  ]),
  CheckupQuestion('tresorerie', 'Avez-vous connu des tensions de trésorerie au cours des 12 derniers mois ?', [
    'Oui, de manière quasi permanente',
    'Oui, à plusieurs reprises',
    'Rarement',
    'Jamais',
  ]),
  // Rentabilité
  CheckupQuestion('rentabilite', 'Connaissez-vous la marge réalisée par produit, service ou activité ?', [
    'Non',
    'Une estimation globale seulement',
    'Pour les principales activités',
    'Oui, calculée et suivie régulièrement',
  ]),
  CheckupQuestion('rentabilite', 'Connaissez-vous votre seuil de rentabilité ?', [
    'Non',
    'Approximativement',
    'Oui, calculé une fois',
    'Oui, actualisé chaque année ou plus souvent',
  ]),
  CheckupQuestion('rentabilite', 'Comment évolue votre résultat sur les deux derniers exercices ?', [
    'En baisse et déficitaire',
    'En baisse',
    'Stable',
    'En progression',
  ]),
  // Fiscalité
  CheckupQuestion('fiscalite', 'Vos déclarations fiscales mensuelles sont-elles déposées dans les délais ?', [
    'Souvent en retard',
    'Parfois en retard',
    'Presque toujours',
    'Toujours, avec un calendrier fiscal',
  ]),
  CheckupQuestion('fiscalite', 'Maîtrisez-vous les taux de retenue à la source et l’obligation TEJ ?', _scale),
  CheckupQuestion('fiscalite', 'Quand votre situation fiscale a-t-elle été revue pour la dernière fois ?', [
    'Jamais',
    'Il y a plus de 3 ans',
    'Il y a 1 à 3 ans',
    'Au cours de la dernière année',
  ]),
  // Organisation
  CheckupQuestion('organisation', 'Les rôles et responsabilités sont-ils clairement définis (organigramme, fiches de poste) ?', _scale),
  CheckupQuestion('organisation', 'Vos processus clés sont-ils décrits dans des procédures écrites ?', _scale),
  CheckupQuestion('organisation', 'Disposez-vous d’un tableau de bord avec des indicateurs suivis régulièrement ?', [
    'Non',
    'Quelques chiffres ponctuels',
    'Un tableau de bord trimestriel',
    'Un tableau de bord mensuel partagé',
  ]),
  // RH
  CheckupQuestion('rh', 'La paie et les déclarations CNSS sont-elles gérées sans erreurs ni retards ?', [
    'Erreurs ou retards fréquents',
    'Quelques difficultés',
    'Globalement maîtrisé',
    'Entièrement maîtrisé et contrôlé',
  ]),
  CheckupQuestion('rh', 'Les contrats de travail sont-ils à jour et conformes à la législation ?', _scale),
  CheckupQuestion('rh', 'Réalisez-vous des entretiens d’évaluation et un plan de formation ?', _scale),
  // Marketing
  CheckupQuestion('marketing', 'Votre positionnement face à la concurrence est-il clairement défini ?', _scale),
  CheckupQuestion('marketing', 'Votre présence en ligne (site, réseaux sociaux, Google) génère-t-elle des demandes ?', [
    'Pas de présence en ligne',
    'Présence limitée, peu de demandes',
    'Quelques demandes régulières',
    'Source importante de nouveaux clients',
  ]),
  CheckupQuestion('marketing', 'Mesurez-vous le coût d’acquisition et la fidélité de vos clients ?', _scale),
  // Stratégie
  CheckupQuestion('strategie', 'Disposez-vous d’objectifs écrits à 1 an et à 3 ans ?', _scale),
  CheckupQuestion('strategie', 'Avez-vous un prévisionnel ou un business plan à jour ?', [
    'Non',
    'Ancien ou incomplet',
    'Oui, de moins de 2 ans',
    'Oui, actualisé chaque année',
  ]),
  CheckupQuestion('strategie', 'Les décisions importantes reposent-elles sur des chiffres fiables ?', [
    'Rarement',
    'Parfois',
    'Souvent',
    'Systématiquement',
  ]),
];

CheckupDomain domainById(String id) => checkupDomains.firstWhere((d) => d.id == id, orElse: () => checkupDomains.first);

/// Scores (0..100) par domaine et score global, à partir des réponses (index 0..3).
(Map<String, double>, double) computeCheckup(List<int> answers) {
  final sums = <String, int>{};
  final counts = <String, int>{};
  for (var i = 0; i < checkupQuestions.length && i < answers.length; i++) {
    final q = checkupQuestions[i];
    sums[q.domain] = (sums[q.domain] ?? 0) + answers[i];
    counts[q.domain] = (counts[q.domain] ?? 0) + 1;
  }
  final scores = <String, double>{};
  for (final d in checkupDomains) {
    final c = counts[d.id] ?? 0;
    scores[d.id] = c == 0 ? 0.0 : (sums[d.id]! / (c * 3)) * 100;
  }
  final global = scores.values.isEmpty ? 0.0 : scores.values.reduce((a, b) => a + b) / scores.length;
  return (scores, global);
}

String globalVerdict(double g) {
  if (g >= 75) return 'Entreprise bien pilotée : les fondamentaux sont en place. Le potentiel se situe dans l’optimisation.';
  if (g >= 55) return 'Pilotage correct mais perfectible : plusieurs leviers peuvent sécuriser et accélérer la croissance.';
  if (g >= 35) return 'Pilotage fragile : des priorités sont à traiter pour sécuriser la trésorerie et les décisions.';
  return 'Pilotage à structurer en priorité : un accompagnement permettrait de reprendre la main rapidement.';
}
