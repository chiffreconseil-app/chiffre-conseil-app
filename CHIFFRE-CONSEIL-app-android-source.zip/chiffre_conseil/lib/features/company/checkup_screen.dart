import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../data/models/user_data.dart';
import '../../state/app_state.dart';
import '../../ui/widgets/cc_widgets.dart';
import 'checkup_data.dart';
import 'company_screen.dart';

/// CHECK-UP CHIFFRE CONSEIL — 21 questions, 7 domaines, score global 0–100.
class CheckupScreen extends StatefulWidget {
  const CheckupScreen({super.key, this.companyId});
  final String? companyId;

  @override
  State<CheckupScreen> createState() => _CheckupScreenState();
}

class _CheckupScreenState extends State<CheckupScreen> {
  final List<int?> _answers = List<int?>.filled(checkupQuestions.length, null);
  int _i = -1; // -1 = écran d'introduction

  void _answer(int v) {
    setState(() => _answers[_i] = v);
    Future<void>.delayed(const Duration(milliseconds: 220), () {
      if (!mounted) return;
      if (_i < checkupQuestions.length - 1) {
        setState(() => _i++);
      } else {
        _finish();
      }
    });
  }

  void _finish() {
    final (scores, global) = computeCheckup(_answers.map((a) => a ?? 0).toList());
    final result = CheckupResult(date: DateTime.now(), domains: scores, global: global);
    AppScope.read(context).analytics.checkupCompleted(global.round());
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
      builder: (_) => CheckupResultScreen(result: result, companyId: widget.companyId),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_i < 0) return _intro(context);
    final q = checkupQuestions[_i];
    final d = domainById(q.domain);
    final progress = (_i + 1) / checkupQuestions.length;
    return Scaffold(
      appBar: ccAppBar(context, 'Check-up CHIFFRE CONSEIL'),
      body: SafeArea(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
            child: Row(children: [
              Text('Question ${_i + 1} / ${checkupQuestions.length}', style: TextStyle(fontWeight: FontWeight.w700, color: context.mutedText)),
              const Spacer(),
              Pill(d.label),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 7,
                backgroundColor: context.isDark ? CC.darkLine : const Color(0xFFE7EBF3),
                valueColor: const AlwaysStoppedAnimation<Color>(CC.orange),
              ),
            ),
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: ListView(
                key: ValueKey(_i),
                padding: const EdgeInsets.fromLTRB(20, 26, 20, 20),
                children: [
                  Text(q.text, style: context.tt.headlineSmall?.copyWith(color: context.strongText, fontSize: 21, height: 1.3)),
                  const SizedBox(height: 22),
                  for (var k = 0; k < q.options.length; k++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: CCCard(
                        onTap: () => _answer(k),
                        color: _answers[_i] == k ? (context.isDark ? CC.navySoft : const Color(0xFFFFEFE8)) : null,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                        child: Row(children: [
                          Icon(_answers[_i] == k ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                              color: _answers[_i] == k ? CC.orange : context.mutedText),
                          const SizedBox(width: 12),
                          Expanded(child: Text(q.options[k], style: TextStyle(fontWeight: FontWeight.w600, color: context.strongText, height: 1.35))),
                        ]),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: Row(children: [
              TextButton.icon(
                onPressed: () => setState(() => _i = _i - 1),
                icon: const Icon(Icons.arrow_back),
                label: const Text('Précédent'),
              ),
              const Spacer(),
              if (_answers[_i] != null)
                TextButton.icon(
                  onPressed: () {
                    if (_i < checkupQuestions.length - 1) {
                      setState(() => _i++);
                    } else {
                      _finish();
                    }
                  },
                  icon: const Icon(Icons.arrow_forward),
                  label: Text(_i < checkupQuestions.length - 1 ? 'Suivant' : 'Voir mon score'),
                ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _intro(BuildContext context) {
    return Scaffold(
      appBar: ccAppBar(context, 'Check-up CHIFFRE CONSEIL'),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Eyebrow('Check-up CHIFFRE CONSEIL', color: CC.orangeLight),
            const SizedBox(height: 10),
            const Text('Votre entreprise est-elle bien pilotée ?',
                style: TextStyle(color: CC.white, fontSize: 24, fontWeight: FontWeight.w800, height: 1.2)),
            const SizedBox(height: 10),
            Text('21 questions sur 7 domaines : trésorerie, rentabilité, fiscalité, organisation, ressources humaines, marketing et stratégie. Environ 4 minutes.',
                style: TextStyle(color: CC.white.withValues(alpha: 0.78), height: 1.5)),
          ]),
        ),
        const SizedBox(height: 18),
        for (final d in checkupDomains)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              const Icon(Icons.check_circle, size: 18, color: CC.success),
              const SizedBox(width: 10),
              Text(d.label, style: TextStyle(fontWeight: FontWeight.w600, color: context.strongText)),
            ]),
          ),
        const SizedBox(height: 16),
        const Disclaimer('Outil d’orientation : le score donne une première lecture et ne constitue pas un diagnostic financier certifié. Vos réponses restent sur votre appareil.'),
        const SizedBox(height: 22),
        PrimaryButton('COMMENCER LE CHECK-UP', icon: Icons.play_arrow_rounded, onPressed: () => setState(() => _i = 0)),
      ]),
    );
  }
}

class CheckupResultScreen extends StatelessWidget {
  const CheckupResultScreen({super.key, required this.result, this.companyId});
  final CheckupResult result;
  final String? companyId;

  Future<void> _save(BuildContext context) async {
    final s = AppScope.read(context);
    final target = companyId != null ? s.company(companyId!) : null;
    if (target != null) {
      await s.upsertCompany(target.copyWith(checkup: result));
      if (context.mounted) showSnack(context, 'Score enregistré dans « ${target.name} »');
      return;
    }
    if (s.companies.isEmpty) {
      if (context.mounted) {
        Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CompanyFormScreen(pendingCheckup: result)));
      }
      return;
    }
    final picked = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(title: Text('Enregistrer dans…', style: TextStyle(fontWeight: FontWeight.w800))),
          for (final c in s.companies) ListTile(leading: const Icon(Icons.apartment), title: Text(c.name), onTap: () => Navigator.pop(ctx, c.id)),
          ListTile(leading: const Icon(Icons.add), title: const Text('Nouvelle entreprise'), onTap: () => Navigator.pop(ctx, '__new')),
        ]),
      ),
    );
    if (picked == null || !context.mounted) return;
    if (picked == '__new') {
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CompanyFormScreen(pendingCheckup: result)));
      return;
    }
    final c = s.company(picked);
    if (c != null) {
      await s.upsertCompany(c.copyWith(checkup: result));
      if (context.mounted) showSnack(context, 'Score enregistré dans « ${c.name} »');
    }
  }

  @override
  Widget build(BuildContext context) {
    final g = result.global;
    return Scaffold(
      appBar: ccAppBar(context, 'Score global'),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
        Center(child: ScoreRing(value: g, size: 170)),
        const SizedBox(height: 18),
        Text('Votre entreprise est-elle bien pilotée ?',
            textAlign: TextAlign.center, style: context.tt.titleLarge?.copyWith(color: context.strongText)),
        const SizedBox(height: 8),
        Text(globalVerdict(g), textAlign: TextAlign.center, style: TextStyle(color: context.mutedText, height: 1.5)),
        const SizedBox(height: 8),
        Center(child: Pill('Potentiel d’amélioration : ${(100 - g).round()} %', icon: Icons.trending_up)),
        const SizedBox(height: 20),
        CCCard(
          child: Column(children: [
            for (final d in checkupDomains) ScoreBar(label: d.label, value: result.domains[d.id] ?? 0),
          ]),
        ),
        const SizedBox(height: 16),
        const Disclaimer('Outil d’orientation, non un diagnostic financier certifié. Pour une analyse fondée sur vos états financiers, demandez un diagnostic personnalisé.'),
        const SizedBox(height: 20),
        PrimaryButton('OBTENIR UN DIAGNOSTIC PERSONNALISÉ',
            icon: Icons.event_available,
            onPressed: () => go(context, '/rendez-vous', args: {
                  'objet': 'Diagnostic personnalisé (check-up)',
                  'note': 'Score check-up CHIFFRE CONSEIL : ${g.round()}/100.',
                })),
        const SizedBox(height: 10),
        SecondaryButton(companyId != null ? 'ENREGISTRER LE SCORE' : 'ENREGISTRER DANS MON ENTREPRISE', icon: Icons.save_alt, onPressed: () => _save(context)),
      ]),
    );
  }
}
