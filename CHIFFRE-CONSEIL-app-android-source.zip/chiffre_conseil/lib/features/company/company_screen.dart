import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../core/utils/format.dart';
import '../../core/utils/validators.dart';
import '../../data/models/user_data.dart';
import '../../state/app_state.dart';
import '../../ui/cc_icons.dart';
import '../../ui/screens/forms/form_kit.dart';
import '../../ui/widgets/cc_widgets.dart';
import '../tools/ui/tool_form.dart';
import 'checkup_data.dart';
import 'checkup_screen.dart';

const _orientation =
    'Outil d’orientation : le score de pilotage est calculé à partir de vos réponses au check-up. Il ne constitue pas un diagnostic financier certifié.';

/// MON ENTREPRISE — profils d'entreprise et tableau de bord simplifié.
class CompanyHomeScreen extends StatelessWidget {
  const CompanyHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final list = s.companies;
    return Scaffold(
      appBar: ccAppBar(context, 'Mon entreprise'),
      floatingActionButton: list.isEmpty
          ? null
          : FloatingActionButton.extended(
              backgroundColor: CC.orange,
              foregroundColor: CC.white,
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const CompanyFormScreen())),
              icon: const Icon(Icons.add),
              label: const Text('Entreprise', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
      body: list.isEmpty
          ? ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Eyebrow('Mon entreprise', color: CC.orangeLight),
                  const SizedBox(height: 10),
                  const Text('Créez gratuitement le profil de votre entreprise.',
                      style: TextStyle(color: CC.white, fontSize: 22, fontWeight: FontWeight.w800, height: 1.25)),
                  const SizedBox(height: 10),
                  Text('Nom, secteur, taille, chiffre d’affaires, objectifs… puis un tableau de bord simplifié avec votre score de pilotage par domaine.',
                      style: TextStyle(color: CC.white.withValues(alpha: 0.78), height: 1.5)),
                ]),
              ),
              const SizedBox(height: 18),
              const Disclaimer(_orientation),
              const SizedBox(height: 10),
              const Disclaimer('Vos informations restent sur votre appareil, chiffrées. Elles ne sont jamais envoyées sans votre action.', icon: Icons.lock_outline),
              const SizedBox(height: 22),
              PrimaryButton('CRÉER MON ENTREPRISE',
                  icon: Icons.add_business, onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const CompanyFormScreen()))),
            ])
          : ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 100), children: [
              for (final c in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: CCCard(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CompanyDashboardScreen(companyId: c.id))),
                    child: Row(children: [
                      const IconBadge(Icons.apartment, size: 48),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(c.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
                          const SizedBox(height: 2),
                          Text([c.sector, c.city].where((x) => x.isNotEmpty).join(' · '), style: TextStyle(fontSize: 12.5, color: context.mutedText)),
                          const SizedBox(height: 4),
                          Text(c.checkup == null ? 'Check-up à réaliser' : 'Score de pilotage : ${c.checkup!.global.round()} / 100',
                              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: c.checkup == null ? context.accentText : CC.score(c.checkup!.global))),
                        ]),
                      ),
                      Icon(Icons.chevron_right, color: context.mutedText),
                    ]),
                  ),
                ),
            ]),
    );
  }
}

// ================================ formulaire =================================
class CompanyFormScreen extends StatefulWidget {
  const CompanyFormScreen({super.key, this.company, this.pendingCheckup});
  final Company? company;
  final CheckupResult? pendingCheckup;

  @override
  State<CompanyFormScreen> createState() => _CompanyFormScreenState();
}

class _CompanyFormScreenState extends State<CompanyFormScreen> {
  static const tailles = ['Projet en création', 'Très petite entreprise (TPE)', 'Petite et moyenne entreprise (PME)', 'Grande entreprise'];
  static const effectifs = ['1 à 5', '6 à 20', '21 à 50', '51 à 200', 'Plus de 200'];
  static const cas = ['Moins de 200 000 TND', '200 000 à 1 M TND', '1 à 5 M TND', '5 à 20 M TND', 'Plus de 20 M TND', 'Je préfère ne pas répondre'];
  static const situations = ['Saine', 'Stable', 'Tendue', 'Difficile', 'Je ne sais pas'];
  static const objectifs = [
    'Améliorer la rentabilité',
    'Sécuriser la trésorerie',
    'Obtenir un financement',
    'Être en conformité fiscale',
    'Structurer l’organisation',
    'Gérer la paie et les RH',
    'Développer les ventes',
    'Digitaliser l’entreprise',
  ];

  final _form = GlobalKey<FormState>();
  late final TextEditingController _name = TextEditingController(text: widget.company?.name ?? '');
  late final TextEditingController _sector = TextEditingController(text: widget.company?.sector ?? '');
  late final TextEditingController _city = TextEditingController(text: widget.company?.city ?? '');
  late String _taille = _pick(widget.company?.size, tailles, 1);
  late String _effectif = _pick(widget.company?.employees, effectifs, 0);
  late String _ca = _pick(widget.company?.revenue, cas, 5);
  late String _situation = _pick(widget.company?.situation, situations, 4);
  late final Set<String> _goals = {...?widget.company?.goals};

  static String _pick(String? v, List<String> list, int fallback) => (v != null && list.contains(v)) ? v : list[fallback];

  @override
  void dispose() {
    _name.dispose();
    _sector.dispose();
    _city.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_form.currentState?.validate() ?? false)) return;
    final s = AppScope.read(context);
    final base = widget.company ?? Company(id: s.newId('co'), name: '');
    final c = Company(
      id: base.id,
      name: Validators.clean(_name.text),
      sector: Validators.clean(_sector.text),
      city: Validators.clean(_city.text),
      size: _taille,
      employees: _effectif,
      revenue: _ca,
      situation: _situation,
      goals: _goals.toList(),
      checkup: widget.pendingCheckup ?? base.checkup,
    );
    await s.upsertCompany(c);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => CompanyDashboardScreen(companyId: c.id)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ccAppBar(context, widget.company == null ? 'Nouvelle entreprise' : 'Modifier l’entreprise'),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
          FormCard(children: [
            const FormSectionLabel('Identité'),
            CCField(controller: _name, label: 'Nom de l’entreprise *', capitalization: TextCapitalization.words, validator: (v) => Validators.required(v, 'Le nom')),
            CCField(controller: _sector, label: 'Secteur d’activité', hint: 'Industrie, services, commerce…'),
            CCField(controller: _city, label: 'Ville', capitalization: TextCapitalization.words),
            ChoiceInput<String>(label: 'Taille', value: _taille, items: [for (final x in tailles) (x, x)], onChanged: (v) => setState(() => _taille = v)),
            ChoiceInput<String>(label: 'Nombre d’employés', value: _effectif, items: [for (final x in effectifs) (x, x)], onChanged: (v) => setState(() => _effectif = v)),
            ChoiceInput<String>(label: 'Chiffre d’affaires annuel', value: _ca, items: [for (final x in cas) (x, x)], onChanged: (v) => setState(() => _ca = v)),
            ChoiceInput<String>(label: 'Situation financière (ressenti)', value: _situation, items: [for (final x in situations) (x, x)], onChanged: (v) => setState(() => _situation = v)),
          ]),
          const SizedBox(height: 14),
          FormCard(children: [
            const FormSectionLabel('Objectifs'),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final g in objectifs)
                FilterChip(
                  label: Text(g),
                  selected: _goals.contains(g),
                  onSelected: (v) => setState(() => v ? _goals.add(g) : _goals.remove(g)),
                ),
            ]),
            const SizedBox(height: 16),
          ]),
          const SizedBox(height: 18),
          PrimaryButton('ENREGISTRER', icon: Icons.check, onPressed: _save),
        ]),
      ),
    );
  }
}

// ============================ tableau de bord ================================
class CompanyDashboardScreen extends StatelessWidget {
  const CompanyDashboardScreen({super.key, required this.companyId});
  final String companyId;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final c = s.company(companyId);
    if (c == null) {
      return Scaffold(appBar: ccAppBar(context, 'Mon entreprise'), body: const EmptyState(icon: Icons.apartment, title: 'Entreprise supprimée'));
    }
    final ck = c.checkup;
    return Scaffold(
      appBar: ccAppBar(context, c.name, actions: [
        IconButton(
          tooltip: 'Modifier',
          icon: const Icon(Icons.edit_outlined),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CompanyFormScreen(company: c))),
        ),
        IconButton(
          tooltip: 'Supprimer',
          icon: const Icon(Icons.delete_outline),
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Supprimer cette entreprise ?'),
                content: Text('« ${c.name} » et son score seront effacés de cet appareil.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer', style: TextStyle(color: CC.danger))),
                ],
              ),
            );
            if (ok == true) {
              await s.deleteCompany(c.id);
              if (context.mounted) Navigator.of(context).pop();
            }
          },
        ),
      ]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
        CCCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text([c.sector, c.city, c.size].where((x) => x.isNotEmpty).join(' · '), style: TextStyle(color: context.mutedText)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (c.employees.isNotEmpty) Pill('${c.employees} employés', icon: Icons.groups),
              if (c.revenue.isNotEmpty) Pill('CA : ${c.revenue}', icon: Icons.payments),
              if (c.situation.isNotEmpty) Pill('Situation : ${c.situation}', icon: Icons.monitor_heart),
            ]),
            if (c.goals.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text('Objectifs', style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
              const SizedBox(height: 4),
              for (final g in c.goals)
                Padding(
                  padding: const EdgeInsets.only(top: 3),
                  child: Row(children: [
                    const Icon(Icons.flag_outlined, size: 16, color: CC.orangeText),
                    const SizedBox(width: 8),
                    Expanded(child: Text(g, style: TextStyle(color: context.strongText))),
                  ]),
                ),
            ],
          ]),
        ),
        const SizedBox(height: 14),
        if (ck == null)
          CCCard(
            child: Column(children: [
              const IconBadge(Icons.health_and_safety, size: 56),
              const SizedBox(height: 12),
              Text('Calculez votre score de pilotage', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
              const SizedBox(height: 6),
              Text('Répondez au check-up (21 questions) pour obtenir votre tableau de bord par domaine.',
                  textAlign: TextAlign.center, style: TextStyle(color: context.mutedText)),
              const SizedBox(height: 14),
              PrimaryButton('FAIRE LE CHECK-UP', icon: Icons.play_arrow_rounded, onPressed: () => go(context, '/check-up', args: {'companyId': c.id})),
            ]),
          )
        else ...[
          CCCard(
            child: Column(children: [
              Text('Score de pilotage', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
              const SizedBox(height: 14),
              ScoreRing(value: ck.global, size: 150),
              const SizedBox(height: 14),
              Text('Votre entreprise possède un potentiel d’amélioration de ${(100 - ck.global).round()} %.',
                  textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText, height: 1.4)),
              const SizedBox(height: 4),
              Text('Check-up du ${Fmt.date(ck.date)}', style: TextStyle(fontSize: 12, color: context.mutedText)),
              const SizedBox(height: 10),
              for (final d in checkupDomains) ScoreBar(label: d.label, value: ck.domains[d.id] ?? 0),
            ]),
          ),
          const SizedBox(height: 14),
          PrimaryButton('VOIR MON DIAGNOSTIC',
              icon: Icons.insights, onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => DiagnosticScreen(companyId: c.id)))),
          const SizedBox(height: 10),
          SecondaryButton('REFAIRE LE CHECK-UP', icon: Icons.refresh, onPressed: () => go(context, '/check-up', args: {'companyId': c.id})),
        ],
        const SizedBox(height: 16),
        const Disclaimer(_orientation),
      ]),
    );
  }
}

// =============================== diagnostic ==================================
class DiagnosticScreen extends StatelessWidget {
  const DiagnosticScreen({super.key, required this.companyId});
  final String companyId;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final c = s.company(companyId);
    final ck = c?.checkup;
    if (c == null || ck == null) {
      return Scaffold(appBar: ccAppBar(context, 'Diagnostic'), body: const EmptyState(icon: Icons.insights, title: 'Aucun check-up enregistré'));
    }
    final sorted = [...checkupDomains]..sort((a, b) => (ck.domains[a.id] ?? 0).compareTo(ck.domains[b.id] ?? 0));
    return Scaffold(
      appBar: ccAppBar(context, 'Mon diagnostic'),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
        Text(globalVerdict(ck.global), style: TextStyle(color: context.mutedText, height: 1.5)),
        const SizedBox(height: 6),
        Text('Domaines classés du plus prioritaire au plus solide.', style: TextStyle(fontSize: 12, color: context.mutedText)),
        const SizedBox(height: 14),
        for (final d in sorted) _DomainCard(domain: d, score: ck.domains[d.id] ?? 0),
        const SizedBox(height: 8),
        const Disclaimer(_orientation),
        const SizedBox(height: 18),
        PrimaryButton('OBTENIR UN DIAGNOSTIC PERSONNALISÉ',
            icon: Icons.event_available,
            onPressed: () => go(context, '/rendez-vous', args: {
                  'objet': 'Diagnostic personnalisé (check-up)',
                  'note': 'Entreprise : ${c.name}. Score check-up : ${ck.global.round()}/100.',
                })),
        const SizedBox(height: 10),
        SecondaryButton('DEMANDER UN DEVIS', icon: Icons.request_quote, onPressed: () => go(context, '/devis', args: {'pole': sorted.first.expertise})),
      ]),
    );
  }
}

class _DomainCard extends StatelessWidget {
  const _DomainCard({required this.domain, required this.score});
  final CheckupDomain domain;
  final double score;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final e = s.ready ? s.content.expertise(domain.expertise) : null;
    final level = score < 45 ? 'Prioritaire' : (score < 70 ? 'À renforcer' : 'Solide');
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: CCCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(domain.label, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText))),
            Pill(level, color: CC.score(score).withValues(alpha: 0.14), textColor: CC.score(score)),
          ]),
          ScoreBar(label: 'Score', value: score),
          const SizedBox(height: 4),
          Text(domain.advice(score), style: TextStyle(color: context.strongText, height: 1.45)),
          if (e != null) ...[
            const SizedBox(height: 10),
            InkWell(
              onTap: () => go(context, '/expertises/${e.slug}'),
              child: Row(children: [
                Icon(CCIcons.expertise(e.slug), size: 18, color: context.accentText),
                const SizedBox(width: 8),
                Expanded(child: Text('Expertise : ${e.name}', style: TextStyle(fontWeight: FontWeight.w700, color: context.accentText))),
                Icon(Icons.arrow_forward, size: 16, color: context.accentText),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}

/// Raccourci : démarrer un check-up depuis un autre écran.
void startCheckup(BuildContext context, {String? companyId}) =>
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CheckupScreen(companyId: companyId)));
