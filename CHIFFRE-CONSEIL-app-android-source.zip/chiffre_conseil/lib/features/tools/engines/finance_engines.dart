// Outils de gestion de l'application : formules financières standard,
// appliquées uniquement aux données saisies par l'utilisateur.
import 'dart:math' as math;

// ------------------------------- Investissement --------------------------------
class InvestResult {
  final double van;
  final double? tri; // null si non calculable
  final double? paybackAnnees; // null si non récupéré sur la durée
  final double? paybackActualise;
  final double indiceProfitabilite;
  final List<double> cumul;
  const InvestResult(this.van, this.tri, this.paybackAnnees, this.paybackActualise, this.indiceProfitabilite, this.cumul);
}

/// VAN = −I + Σ CFt / (1+k)^t
double van(double investissement, List<double> flux, double taux) {
  var v = -investissement;
  for (var t = 0; t < flux.length; t++) {
    v += flux[t] / math.pow(1 + taux, t + 1);
  }
  return v;
}

/// TRI par dichotomie sur [-0,99 ; 10] : taux qui annule la VAN.
double? tri(double investissement, List<double> flux) {
  if (investissement <= 0 || flux.isEmpty) return null;
  double f(double r) => van(investissement, flux, r);
  var lo = -0.99, hi = 10.0;
  var flo = f(lo), fhi = f(hi);
  if (flo.isNaN || fhi.isNaN || flo * fhi > 0) return null;
  for (var i = 0; i < 200; i++) {
    final mid = (lo + hi) / 2;
    final fm = f(mid);
    if (fm.abs() < 1e-9) return mid;
    if (flo * fm < 0) {
      hi = mid;
      fhi = fm;
    } else {
      lo = mid;
      flo = fm;
    }
  }
  return (lo + hi) / 2;
}

double? _payback(double investissement, List<double> flux) {
  var cumul = -investissement;
  for (var t = 0; t < flux.length; t++) {
    final avant = cumul;
    cumul += flux[t];
    if (cumul >= 0 && flux[t] > 0) {
      return t + (-avant / flux[t]);
    }
  }
  return null;
}

InvestResult analyseInvestissement(double investissement, List<double> flux, double taux) {
  final v = van(investissement, flux, taux);
  final actualises = <double>[];
  for (var t = 0; t < flux.length; t++) {
    actualises.add(flux[t] / math.pow(1 + taux, t + 1));
  }
  final cumul = <double>[];
  var c = -investissement;
  for (final f in flux) {
    c += f;
    cumul.add(c);
  }
  final ip = investissement > 0 ? (v + investissement) / investissement : 0.0;
  return InvestResult(v, tri(investissement, flux), _payback(investissement, flux), _payback(investissement, actualises), ip, cumul);
}

// ------------------------------------- BFR -------------------------------------
class BfrResult {
  final double bfr, joursCa, tresorerieNette;
  final double? fondsDeRoulement;
  const BfrResult(this.bfr, this.joursCa, this.fondsDeRoulement, this.tresorerieNette);
}

/// BFR = stocks + créances clients − dettes fournisseurs (définition du site).
BfrResult calculBfr({
  required double stocks,
  required double creances,
  required double dettesFournisseurs,
  double autresCreances = 0,
  double autresDettes = 0,
  required double chiffreAffairesAnnuel,
  double? fondsDeRoulement,
}) {
  final bfr = stocks + creances + autresCreances - dettesFournisseurs - autresDettes;
  final jours = chiffreAffairesAnnuel > 0 ? bfr / chiffreAffairesAnnuel * 360 : 0.0;
  final tn = fondsDeRoulement == null ? 0.0 : fondsDeRoulement - bfr;
  return BfrResult(bfr, jours, fondsDeRoulement, tn);
}

// ---------------------------- Seuil de rentabilité -----------------------------
class SeuilResult {
  final double mcv, tauxMcv, seuil, resultat, margeSecurite, pointMortJours;
  const SeuilResult(this.mcv, this.tauxMcv, this.seuil, this.resultat, this.margeSecurite, this.pointMortJours);
  bool get atteint => resultat >= 0;
}

/// Marge sur coût variable, seuil de rentabilité et point mort.
SeuilResult seuilRentabilite({required double ca, required double chargesVariables, required double chargesFixes}) {
  final mcv = ca - chargesVariables;
  final taux = ca > 0 ? mcv / ca : 0.0;
  final seuil = taux > 0 ? chargesFixes / taux : double.infinity;
  final resultat = mcv - chargesFixes;
  final marge = seuil.isFinite ? ca - seuil : 0.0;
  final pm = (seuil.isFinite && ca > 0) ? seuil / ca * 360 : double.infinity;
  return SeuilResult(mcv, taux, seuil, resultat, marge, pm);
}

// --------------------------- Budget / Réalisé / Écart ---------------------------
class BudgetLine {
  final String libelle;
  final double budget;
  final double realise;
  final bool charge; // true : une dépense (écart favorable si réalisé < budget)
  const BudgetLine(this.libelle, this.budget, this.realise, {this.charge = false});
  double get ecart => realise - budget;
  double? get ecartPct => budget == 0 ? null : ecart / budget.abs();
  bool get favorable => charge ? ecart <= 0 : ecart >= 0;
}

// --------------------------- Trésorerie prévisionnelle --------------------------
class TresoMois {
  final int mois;
  final double encaissements, decaissements, soldeDebut, soldeFin;
  const TresoMois(this.mois, this.encaissements, this.decaissements, this.soldeDebut, this.soldeFin);
  double get flux => encaissements - decaissements;
}

List<TresoMois> planTresorerie({required double soldeInitial, required List<double> encaissements, required List<double> decaissements}) {
  final out = <TresoMois>[];
  var solde = soldeInitial;
  final n = math.min(encaissements.length, decaissements.length);
  for (var i = 0; i < n; i++) {
    final debut = solde;
    solde = solde + encaissements[i] - decaissements[i];
    out.add(TresoMois(i + 1, encaissements[i], decaissements[i], debut, solde));
  }
  return out;
}
