// Moteurs de calcul repris À L'IDENTIQUE de chiffreconseil.net
// (assets/js/03-calculateurs.js). Une loi de finances = un seul fichier à modifier.
import 'dart:math' as math;

const majBareme = 'Barème loi de finances 2026 — mis à jour le 19/09/2026';

/// [plafond de tranche, taux]
const List<List<double>> baremeIrpp2026 = [
  [5000, 0.00],
  [10000, 0.15],
  [20000, 0.25],
  [30000, 0.30],
  [40000, 0.33],
  [50000, 0.36],
  [70000, 0.38],
  [double.infinity, 0.40],
];

class Taux {
  Taux._();
  static const cnss = 0.0968;
  static const cnrps = 0.1295;
  static const cnamRetraite = 0.04;
  static const capitalDeces = 0.005;
  static const patronalBase = 0.1657;
  static const cssMinAssiette = 5000.0;
  static const fraisProActif = 0.10;
  static const fraisProPlafond = 2000.0;
  static const fraisProRetraite = 0.25;
  static const chefFamille = 300.0;
  static const enfant = 100.0;
  static const etudiant = 1000.0;
  static const handicape = 2000.0;
  static const parentTaux = 0.05;
  static const parentPlafond = 450.0;
  static const smig = 528.0;
}

class TrancheLine {
  final double bas, haut, taux, base, impot;
  const TrancheLine(this.bas, this.haut, this.taux, this.base, this.impot);
}

class IrppResult {
  final double total;
  final List<TrancheLine> lignes;
  const IrppResult(this.total, this.lignes);
}

IrppResult irppTranches(double assiette) {
  var reste = math.max(0.0, assiette);
  var bas = 0.0;
  var total = 0.0;
  final lignes = <TrancheLine>[];
  for (final t in baremeIrpp2026) {
    final haut = t[0], taux = t[1];
    if (reste <= 0) break;
    final largeur = haut - bas;
    final base = math.min(reste, largeur);
    final impot = base * taux;
    if (base > 0) lignes.add(TrancheLine(bas, haut, taux, base, impot));
    total += impot;
    reste -= base;
    bas = haut;
  }
  return IrppResult(total, lignes);
}

class Deductions {
  final double fp, chef, enf, etu, hnd, par;
  const Deductions(this.fp, this.chef, this.enf, this.etu, this.hnd, this.par);
  double get total => fp + chef + enf + etu + hnd + par;
}

Deductions deductions({
  required double revenu,
  bool retraite = false,
  bool chef = false,
  int enfants = 0,
  int etudiants = 0,
  int handicapes = 0,
  int parents = 0,
}) {
  final fp = retraite ? revenu * Taux.fraisProRetraite : math.min(revenu * Taux.fraisProActif, Taux.fraisProPlafond);
  final enfCap = math.min(4, enfants);
  final enf = enfCap * Taux.enfant;
  final etu = math.max(0, math.min(4 - enfCap, etudiants)) * Taux.etudiant;
  final hnd = handicapes * Taux.handicape;
  final par = math.min(parents * revenu * Taux.parentTaux, parents > 0 ? Taux.parentPlafond : 0.0);
  final ch = chef ? Taux.chefFamille : 0.0;
  return Deductions(fp, ch, enf.toDouble(), etu.toDouble(), hnd.toDouble(), par);
}

// =========================== 1. SIMULATEUR DE PAIE ===========================
class PaieResult {
  final double brut, cot, imp, assiette, ir, css, net, patronal, aide;
  final Deductions d;
  const PaieResult(this.brut, this.cot, this.imp, this.assiette, this.ir, this.css, this.net, this.d, this.patronal, this.aide);
  double get coutEmployeur => brut + patronal - aide;
}

PaieResult simulateurPaie({
  required bool secteurPublic,
  required bool depuisNet,
  required double montant,
  int enfants = 0,
  int etudiants = 0,
  int handicapes = 0,
  double cssTaux = 0.01,
  bool chef = false,
  bool diplome = false,
  int anneeContrat = 1, // 1..5, 0 = au-delà
}) {
  final tx = secteurPublic ? Taux.cnrps : Taux.cnss;
  List<double> calc(double brut) {
    final cot = brut * tx;
    final imp = brut - cot;
    final annuel = imp * 12;
    final d = deductions(revenu: annuel, chef: chef, enfants: enfants, etudiants: etudiants, handicapes: handicapes);
    final assiette = math.max(0.0, annuel - d.total);
    final ir = irppTranches(assiette).total / 12;
    final css = assiette >= Taux.cssMinAssiette ? assiette * cssTaux / 12 : 0.0;
    return [brut, cot, imp, assiette, ir, css, brut - cot - ir - css];
  }

  double brut;
  if (depuisNet) {
    var lo = montant, hi = montant * 2.5 + 1000;
    for (var i = 0; i < 60; i++) {
      final m = (lo + hi) / 2;
      if (calc(m)[6] < montant) {
        lo = m;
      } else {
        hi = m;
      }
    }
    brut = (lo + hi) / 2;
  } else {
    brut = montant;
  }
  final r = calc(brut);
  final d = deductions(revenu: r[2] * 12, chef: chef, enfants: enfants, etudiants: etudiants, handicapes: handicapes);
  final patr = r[0] * Taux.patronalBase;
  var aide = 0.0;
  if (diplome) {
    const q = {1: 1.0, 2: 0.8, 3: 0.6, 4: 0.4, 5: 0.2, 0: 0.0};
    aide = patr * (q[anneeContrat] ?? 0);
  }
  return PaieResult(r[0], r[1], r[2], r[3], r[4], r[5], r[6], d, patr, aide);
}

// ================================ 2. IRPP =====================================
class IrppCalc {
  final double revenu, assiette, css, effectif;
  final Deductions d;
  final IrppResult r;
  final bool benefice;
  const IrppCalc(this.revenu, this.d, this.assiette, this.r, this.css, this.effectif, this.benefice);
  double get dTotal => benefice ? d.total - d.fp : d.total;
}

IrppCalc calculIrpp({
  required String nature, // salaire | pension | benefice
  required double revenu,
  int enfants = 0,
  int etudiants = 0,
  int handicapes = 0,
  int parents = 0,
  bool chef = true,
  double cssTaux = 0.01,
}) {
  final d = deductions(
    revenu: revenu,
    retraite: nature == 'pension',
    chef: chef,
    enfants: enfants,
    etudiants: etudiants,
    handicapes: handicapes,
    parents: parents,
  );
  final benefice = nature == 'benefice';
  final total = benefice ? d.total - d.fp : d.total;
  final assiette = math.max(0.0, revenu - total);
  final r = irppTranches(assiette);
  final css = assiette >= Taux.cssMinAssiette ? assiette * cssTaux : 0.0;
  final eff = revenu > 0 ? r.total / revenu * 100 : 0.0;
  return IrppCalc(revenu, d, assiette, r, css, eff, benefice);
}

// ========================= 3. RETENUE À LA SOURCE =============================
class RasNature {
  final String id, label;
  final double taux;
  const RasNature(this.id, this.label, this.taux);
}

const rasNatures = [
  RasNature('hono3', 'Honoraires — BNC régime réel et personnes morales', 0.03),
  RasNature('hono10', 'Honoraires — BNC régime du forfait d\'assiette', 0.10),
  RasNature('comm10', 'Commissions, courtages, rémunérations ANC', 0.10),
  RasNature('comm1', 'Commissions distributeurs télécom (IS 20 %)', 0.01),
  RasNature('comm15', 'Commissions distributeurs télécom (IRPP / sociétés de personnes)', 0.015),
  RasNature('art5', 'Artistes, créateurs et droits d\'auteur', 0.05),
  RasNature('loy10', 'Loyers d\'immeubles bâtis et de fonds de commerce', 0.10),
  RasNature('loy5', 'Loyers d\'hôtels (PM et PP régime réel)', 0.05),
  RasNature('eq1', 'Loyers d\'équipements — bailleur IS 20 %', 0.01),
  RasNature('eq15', 'Loyers d\'équipements — bailleur IS 40/35/20 % ou PP', 0.015),
  RasNature('eq05', 'Loyers d\'équipements — bailleur IS 10 % ou déduction 2/3', 0.005),
  RasNature('ach1', 'Achats ≥ 1 000 D — fournisseur IS 20 %', 0.01),
  RasNature('ach15', 'Achats ≥ 1 000 D — fournisseur autres taux d\'IS', 0.015),
  RasNature('ach05', 'Achats ≥ 1 000 D — fournisseur IS 10 % ou déduction 2/3', 0.005),
  RasNature('perf10', 'Rémunération en contrepartie de la performance', 0.10),
];

class RasResult {
  final double ht, tva, timbre, ttc, base, taux, retenue, net;
  const RasResult(this.ht, this.tva, this.timbre, this.ttc, this.base, this.taux, this.retenue, this.net);
}

RasResult retenueSource({required double taux, required double ht, required double tauxTva, required bool baseHt, required bool timbre}) {
  final tva = ht * tauxTva;
  final t = timbre ? 1.0 : 0.0;
  final ttc = ht + tva + t;
  final base = baseHt ? ht : ttc;
  final ret = base * taux;
  return RasResult(ht, tva, t, ttc, base, taux, ret, ttc - ret);
}

// ================================= 4. TVA ======================================
class TvaResult {
  final double ht, tva, timbre, unitHt;
  final int quantite;
  const TvaResult(this.ht, this.tva, this.timbre, this.unitHt, this.quantite);
  double get ttcHorsTimbre => ht + tva;
  double get net => ht + tva + timbre;
}

TvaResult calculTva({required bool depuisTtc, required double taux, required double montant, int quantite = 1, bool timbre = true}) {
  final q = math.max(1, quantite);
  final saisi = montant * q;
  double ht, tva;
  if (depuisTtc) {
    ht = saisi / (1 + taux);
    tva = saisi - ht;
  } else {
    ht = saisi;
    tva = ht * taux;
  }
  return TvaResult(ht, tva, timbre ? 1.0 : 0.0, ht / q, q);
}

// ========================== 5. PENSION DE RETRAITE ============================
class PensionResult {
  final double ref, plafond, taux, brut, cnam, kd, ir, css, net;
  final bool ok, plafonne;
  final int minDuree;
  const PensionResult(this.ref, this.plafond, this.taux, this.brut, this.cnam, this.kd, this.ir, this.css, this.net, this.ok,
      this.plafonne, this.minDuree);
}

PensionResult calculPension({
  required bool secteurPublic,
  required double salaire,
  required int annees,
  int trimestres = 0,
  int enfants = 0,
  double cssTaux = 0.01,
  bool chef = false,
  bool complementaire = false,
}) {
  const plafond = 6 * Taux.smig;
  final ref = (!secteurPublic && !complementaire) ? math.min(salaire, plafond) : salaire;
  final minDuree = secteurPublic ? 15 : 10;
  final ok = annees >= minDuree;
  double taux;
  if (secteurPublic) {
    final a = math.min(annees, 10), b = math.min(math.max(annees - 10, 0), 10), c = math.max(annees - 20, 0);
    taux = a * 0.02 + b * 0.03 + c * 0.02 + trimestres * 0.005;
    taux = math.min(taux, 0.90);
  } else {
    taux = annees >= 10 ? 0.40 + (annees - 10) * 0.02 + trimestres * 0.005 : 0.0;
    taux = math.min(taux, 0.80);
  }
  final brut = ok ? ref * taux : 0.0;
  final cnam = brut * Taux.cnamRetraite, kd = brut * Taux.capitalDeces;
  final imposable = brut - cnam - kd;
  final annuel = imposable * 12;
  final d = deductions(revenu: annuel, retraite: true, chef: chef, enfants: enfants);
  final assiette = math.max(0.0, annuel - d.total);
  final ir = irppTranches(assiette).total / 12;
  final css = assiette >= Taux.cssMinAssiette ? assiette * cssTaux / 12 : 0.0;
  final net = brut - cnam - kd - ir - css;
  return PensionResult(ref, plafond, taux, brut, cnam, kd, ir, css, net, ok, !secteurPublic && !complementaire && salaire > plafond, minDuree);
}

// ============================== 6. VIGNETTE 2026 ==============================
/// puissance -> {pp: [essence, diesel, gpl], pm: [...]}
const Map<String, Map<String, List<double>>> vignetteGrille = {
  '4': {'pp': [65, 215, 390], 'pm': [130, 280, 455]},
  '5-7': {'pp': [130, 280, 455], 'pm': [260, 410, 585]},
  '8': {'pp': [180, 330, 505], 'pm': [360, 510, 685]},
  '9': {'pp': [180, 405, 580], 'pm': [360, 585, 760]},
  '10-11': {'pp': [230, 455, 630], 'pm': [460, 685, 860]},
  '12-13': {'pp': [1050, 1275, 1450], 'pm': [2100, 2325, 2500]},
  '14-15': {'pp': [1400, 1625, 1800], 'pm': [2800, 3025, 3200]},
  '16+': {'pp': [2100, 2323, 2500], 'pm': [4200, 4425, 4600]},
};

String vignetteLabel(String k) => k == '16+' ? '16 CV et plus' : '${k.replaceAll('-', ' à ')} CV';

class VignetteResult {
  final double plein, reduction, du;
  final String limite, note;
  const VignetteResult(this.plein, this.reduction, this.du, this.limite, this.note);
}

/// energie : '0' essence, '1' diesel, '2' GPL, 'e' électrique, 'h0' hybride essence, 'h1' hybride diesel
VignetteResult calculVignette({required bool personneMorale, required String puissance, required String energie, required int dernierChiffre, required bool location}) {
  final grille = vignetteGrille[puissance]![personneMorale ? 'pm' : 'pp']!;
  var idx = 0;
  var reduc = 0.0;
  var note = '';
  if (energie == 'e') {
    idx = 0;
    reduc = 0.5;
    note = 'Réduction de 50 % applicable aux véhicules 100 % électriques.';
  } else if (energie == 'h0') {
    idx = 0;
    note = 'Hybride : tarif du moteur thermique essence, sans réduction spécifique.';
  } else if (energie == 'h1') {
    idx = 1;
    note = 'Hybride : tarif du moteur thermique diesel, sans réduction spécifique.';
  } else {
    idx = int.tryParse(energie) ?? 0;
  }
  final plein = grille[idx];
  final du = plein * (1 - reduc);
  String lim;
  if (location) {
    lim = '5 mai 2026 — location et leasing';
  } else if (personneMorale) {
    lim = '5 février 2026 — personnes morales';
  } else {
    lim = dernierChiffre % 2 == 0 ? '5 mars 2026 — immatriculation paire' : '5 avril 2026 — immatriculation impaire';
  }
  return VignetteResult(plein, plein * reduc, du, lim, note);
}

// =========================== 7. SIMULATEUR DE CRÉDIT ===========================
class EcheanceRow {
  final int n;
  final double mensualite, capital, interets, restant;
  const EcheanceRow(this.n, this.mensualite, this.capital, this.interets, this.restant);
}

class CreditResult {
  final double m1, mN, capital, totInterets, totAssurance, frais;
  final List<EcheanceRow> rows; // 12 premières + dernière
  final bool constant;
  const CreditResult(this.m1, this.mN, this.capital, this.totInterets, this.totAssurance, this.frais, this.rows, this.constant);
  double get coutTotal => totInterets + totAssurance + frais;
  double get totalRembourse => capital + coutTotal;
}

CreditResult simulateurCredit({
  required double montant,
  required int dureeMois,
  required double tauxAnnuelPct,
  required bool mensualiteConstante,
  double assurancePct = 0,
  double frais = 0,
}) {
  final k = montant;
  final n = math.max(1, dureeMois);
  final i = tauxAnnuelPct / 100 / 12;
  final assM = k * (assurancePct / 100) / 12;
  final rows = <EcheanceRow>[];
  var reste = k, totInt = 0.0, m1 = 0.0, mN = 0.0;
  if (mensualiteConstante) {
    final m = i == 0 ? k / n : k * i / (1 - math.pow(1 + i, -n));
    m1 = mN = m + assM;
    for (var j = 1; j <= n; j++) {
      final interet = reste * i;
      final cap = m - interet;
      reste -= cap;
      totInt += interet;
      if (j <= 12 || j == n) rows.add(EcheanceRow(j, m + assM, cap, interet, math.max(0.0, reste)));
    }
  } else {
    final cap = k / n;
    for (var j = 1; j <= n; j++) {
      final interet = reste * i;
      final mens = cap + interet + assM;
      reste -= cap;
      totInt += interet;
      if (j == 1) m1 = mens;
      if (j == n) mN = mens;
      if (j <= 12 || j == n) rows.add(EcheanceRow(j, mens, cap, interet, math.max(0.0, reste)));
    }
  }
  return CreditResult(m1, mN, k, totInt, assM * n, frais, rows, mensualiteConstante);
}

/// Coût annuel moyen rapporté au capital (indicateur de comparaison du site).
double coutAnnuelMoyen(CreditResult r, int dureeMois) =>
    r.capital > 0 ? (r.coutTotal / r.capital) / (math.max(1, dureeMois) / 12) * 100 : 0.0;

// ============================ 8. MATRICULE FISCAL =============================
const mfLettres = 'ABCDEFGHJKLMNPQRSTVWXYZ';
const mfTva = {
  'A': 'Assujetti obligatoire',
  'B': 'Assujetti par option',
  'D': 'Assujetti partiel par option à la TVA',
  'P': 'Assujetti partiel',
  'N': 'Non assujetti',
};
const mfCat = {
  'M': 'Personne morale',
  'C': 'Commerçant ou industriel',
  'P': 'Profession libérale',
  'N': 'Employeur non soumis',
  'E': 'Établissement secondaire',
};

class MatriculeResult {
  final String normalise, chiffres, cle, attendue, tva, cat, etab;
  final bool numOk, cleOk, longueurOk;
  const MatriculeResult(this.normalise, this.chiffres, this.cle, this.attendue, this.tva, this.cat, this.etab, this.numOk,
      this.cleOk, this.longueurOk);
}

MatriculeResult verifierMatricule(String saisie) {
  final raw = saisie.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
  String at(int i) => i < raw.length ? raw[i] : '';
  final chiffres = raw.length >= 7 ? raw.substring(0, 7) : raw;
  final numOk = RegExp(r'^\d{7}$').hasMatch(chiffres);
  final attendue = numOk ? mfLettres[int.parse(chiffres) % 23] : '—';
  final cle = at(7);
  final etab = raw.length > 10 ? raw.substring(10, math.min(13, raw.length)) : '';
  return MatriculeResult(raw, chiffres, cle, attendue, at(8), at(9), etab, numOk, cle == attendue, raw.length >= 9);
}
