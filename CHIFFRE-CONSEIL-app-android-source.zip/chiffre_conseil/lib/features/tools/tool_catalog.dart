import '../../data/models/content.dart';

class ToolEntry {
  final String slug;
  final String name;
  final String short;
  final String description;
  final String intro;

  /// 'site' : simulateur publié sur chiffreconseil.net ; 'gestion' : outil de gestion de l'application.
  final String origin;
  final String article; // fiche du site liée (slug), facultatif

  const ToolEntry({
    required this.slug,
    required this.name,
    required this.short,
    required this.description,
    this.intro = '',
    required this.origin,
    this.article = '',
  });

  bool get isFiscal => origin == 'site';
}

/// Outils de gestion propres à l'application (formules standard, données saisies
/// par l'utilisateur ; aucun résultat officiel).
const managementTools = [
  ToolEntry(
    slug: 'investissement',
    name: 'Investissement : VAN, TRI, payback',
    short: 'VAN / TRI',
    description: 'Évaluez un projet : valeur actuelle nette, taux de rendement interne et délai de récupération.',
    intro: 'Saisissez l’investissement initial, les flux de trésorerie attendus et le taux d’actualisation.',
    origin: 'gestion',
    article: 'evaluation-projets-investissement-van-tri-payback',
  ),
  ToolEntry(
    slug: 'bfr',
    name: 'Besoin en fonds de roulement',
    short: 'BFR',
    description: 'Calculez le BFR, son poids en jours de chiffre d’affaires et l’effet sur la trésorerie nette.',
    intro: 'BFR = stocks + créances clients − dettes fournisseurs.',
    origin: 'gestion',
    article: 'gestion-bfr',
  ),
  ToolEntry(
    slug: 'seuil-rentabilite',
    name: 'Calcul de rentabilité',
    short: 'Seuil',
    description: 'Marge sur coût variable, seuil de rentabilité, point mort et marge de sécurité.',
    intro: 'Séparez charges variables et charges fixes pour trouver le chiffre d’affaires minimum à atteindre.',
    origin: 'gestion',
    article: 'analyse-couts-calcul-rentabilite',
  ),
  ToolEntry(
    slug: 'tresorerie',
    name: 'Analyse de trésorerie',
    short: 'Trésorerie',
    description: 'Plan de trésorerie sur 6 mois : encaissements, décaissements et solde fin de mois.',
    intro: 'Repérez à l’avance les mois de tension et le besoin de financement.',
    origin: 'gestion',
    article: 'gestion-tresorerie-cash-management',
  ),
  ToolEntry(
    slug: 'budget-ecart',
    name: 'Budget / Réalisé / Écart',
    short: 'Écarts',
    description: 'Comparez budget et réalisé ligne par ligne, avec l’écart en valeur et en pourcentage.',
    intro: 'Un écart favorable sur un produit est positif ; sur une charge, il est négatif.',
    origin: 'gestion',
    article: 'elaboration-suivi-budgets',
  ),
];

List<ToolEntry> allTools(ContentBundle c) => [
      ...c.tools.map((t) => ToolEntry(
            slug: t.slug,
            name: t.name,
            short: t.short,
            description: t.description,
            intro: t.intro,
            origin: 'site',
          )),
      ...managementTools,
    ];

ToolEntry? findTool(ContentBundle c, String slug) {
  for (final t in allTools(c)) {
    if (t.slug == slug) return t;
  }
  return null;
}
