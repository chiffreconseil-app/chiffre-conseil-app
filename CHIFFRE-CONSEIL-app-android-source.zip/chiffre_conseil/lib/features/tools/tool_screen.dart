import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/config.dart';
import '../../core/theme/cc_theme.dart';
import '../../state/app_state.dart';
import '../../ui/cc_icons.dart';
import '../../ui/widgets/article_tile.dart';
import '../../ui/widgets/cc_widgets.dart';
import 'engines/fiscal_engines.dart';
import 'tool_catalog.dart';
import 'ui/finance_calculators.dart';
import 'ui/site_calculators.dart';

class ToolScreen extends StatefulWidget {
  const ToolScreen({super.key, required this.slug});
  final String slug;

  @override
  State<ToolScreen> createState() => _ToolScreenState();
}

class _ToolScreenState extends State<ToolScreen> {
  bool _logged = false;

  Widget? _calculator(String slug) => switch (slug) {
        'simulateur-paie' => const PaieCalculator(),
        'calculateur-irpp' => const IrppCalculator(),
        'retenue-a-la-source' => const RasCalculator(),
        'calculateur-tva' => const TvaCalculator(),
        'pension-retraite' => const PensionCalculator(),
        'vignette-2026' => const VignetteCalculator(),
        'simulateur-credit' => const CreditCalculator(),
        'matricule-fiscal' => const MatriculeCalculator(),
        'investissement' => const InvestCalculator(),
        'bfr' => const BfrCalculator(),
        'seuil-rentabilite' => const SeuilCalculator(),
        'tresorerie' => const TresorerieCalculator(),
        'budget-ecart' => const BudgetCalculator(),
        _ => null,
      };

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final t = findTool(s.content, widget.slug);
    final calc = _calculator(widget.slug);
    if (t == null || calc == null) {
      return Scaffold(
        appBar: ccAppBar(context, 'Outil'),
        body: EmptyState(
          icon: Icons.search_off,
          title: 'Outil introuvable',
          message: 'Cet outil n’est pas encore disponible dans l’application.',
          action: SecondaryButton('Voir sur chiffreconseil.net', expand: false, onPressed: () => openLink(context, '${AppConfig.siteUrl}/outils/')),
        ),
      );
    }
    if (!_logged) {
      _logged = true;
      s.analytics.toolUsed(t.slug);
    }
    final related = t.article.isNotEmpty ? s.content.article(t.article) : null;
    return Scaffold(
      appBar: ccAppBar(context, t.name, actions: [FavoriteButton(keyId: 't:${t.slug}')]),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              IconBadge(CCIcons.tool(t.slug), size: 48),
              const SizedBox(width: 12),
              Expanded(child: Text(t.intro.isNotEmpty ? t.intro : t.description, style: TextStyle(color: context.mutedText, height: 1.45))),
            ]),
            const SizedBox(height: 12),
            if (t.isFiscal) const Align(alignment: Alignment.centerLeft, child: Pill(majBareme, icon: Icons.verified_outlined)),
            const SizedBox(height: 14),
            calc,
            const SizedBox(height: 16),
            Disclaimer(t.isFiscal
                ? 'Simulation indicative reprenant le calculateur publié sur chiffreconseil.net. Elle ne remplace ni un conseil personnalisé ni les textes officiels.'
                : 'Outil d’aide à la décision : les résultats dépendent uniquement des hypothèses saisies et ne constituent pas un diagnostic financier certifié.'),
            if (related != null) ...[
              const SizedBox(height: 18),
              Text('Pour aller plus loin', style: context.tt.titleMedium?.copyWith(color: context.strongText)),
              const SizedBox(height: 4),
            ],
            if (related != null) ArticleTile(article: related, showExcerpt: false),
            const SizedBox(height: 18),
            CCCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Besoin d’un regard expert ?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
                const SizedBox(height: 6),
                Text('Le cabinet vous accompagne pour interpréter ces résultats et agir.', style: TextStyle(color: context.mutedText)),
                const SizedBox(height: 14),
                PrimaryButton('PRENDRE RENDEZ-VOUS',
                    icon: Icons.event_available, onPressed: () => go(context, '/rendez-vous', args: {'note': 'Suite à l’outil « ${t.name} »'})),
              ]),
            ),
            if (t.isFiscal) ...[
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => openLink(context, '${AppConfig.siteUrl}/outils/${t.slug}/'),
                icon: const Icon(Icons.open_in_new, size: 18),
                label: const Text('Ouvrir sur chiffreconseil.net'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
