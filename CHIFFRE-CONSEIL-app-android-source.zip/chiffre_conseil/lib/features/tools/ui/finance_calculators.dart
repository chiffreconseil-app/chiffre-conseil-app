import 'package:flutter/material.dart';

import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';
import '../engines/finance_engines.dart';
import 'tool_form.dart';

String _m(double x) => Fmt.dt(x);
const _good = Color(0xFF7BE0B0);
const _bad = Color(0xFFFFB48A);

// ============================== INVESTISSEMENT ===============================
class InvestCalculator extends StatefulWidget {
  const InvestCalculator({super.key});
  @override
  State<InvestCalculator> createState() => _InvestCalculatorState();
}

class _InvestCalculatorState extends State<InvestCalculator> {
  double invest = 0, taux = 10;
  final List<double> flux = [0, 0, 0, 0, 0];

  @override
  Widget build(BuildContext context) {
    final ready = invest > 0 && flux.any((f) => f != 0);
    final r = analyseInvestissement(invest, flux, taux / 100);
    String years(double? y) => y == null ? 'non récupéré sur la période' : '${Fmt.num(y, d: 1)} ans';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        FieldRow(children: [
          NumInput(label: 'Investissement initial', suffix: 'TND', initial: 0, hint: 'ex. 150 000', onChanged: (v) => setState(() => invest = v)),
          NumInput(label: 'Taux d’actualisation', suffix: '%', initial: taux, onChanged: (v) => setState(() => taux = v)),
        ]),
        Text('Flux de trésorerie nets attendus', style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
        const SizedBox(height: 10),
        for (var i = 0; i < flux.length; i++)
          NumInput(
            key: ValueKey('flux_$i'),
            label: 'Année ${i + 1}',
            suffix: 'TND',
            initial: flux[i],
            onChanged: (v) => setState(() => flux[i] = v),
          ),
        Row(children: [
          TextButton.icon(
            onPressed: flux.length >= 10 ? null : () => setState(() => flux.add(0)),
            icon: const Icon(Icons.add),
            label: const Text('Ajouter une année'),
          ),
          const Spacer(),
          if (flux.length > 1)
            TextButton(onPressed: () => setState(() => flux.removeLast()), child: const Text('Retirer')),
        ]),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        if (!ready)
          const ResultNote('Saisissez l’investissement et au moins un flux annuel pour obtenir l’analyse.')
        else ...[
          ResultBig('Valeur actuelle nette (VAN)', _m(r.van), color: r.van >= 0 ? _good : _bad),
          ResultLine('Taux de rendement interne (TRI)', r.tri == null ? 'non calculable' : '${Fmt.num(r.tri! * 100, d: 2)} %',
              color: r.tri == null ? null : (r.tri! * 100 >= taux ? _good : _bad)),
          ResultLine('Délai de récupération (simple)', years(r.paybackAnnees)),
          ResultLine('Délai de récupération actualisé', years(r.paybackActualise)),
          ResultLine('Indice de profitabilité', Fmt.num(r.indiceProfitabilite, d: 2)),
          ResultNote(r.van >= 0
              ? 'VAN positive : au taux de ${Fmt.num(taux, d: 2)} %, le projet crée de la valeur selon les flux saisis.'
              : 'VAN négative : au taux de ${Fmt.num(taux, d: 2)} %, les flux saisis ne couvrent pas l’investissement.'),
        ],
        const ResultNote('Flux supposés perçus en fin d’année. Résultat indicatif, fondé uniquement sur vos hypothèses.'),
      ]),
    ]);
  }
}

// ==================================== BFR ====================================
class BfrCalculator extends StatefulWidget {
  const BfrCalculator({super.key});
  @override
  State<BfrCalculator> createState() => _BfrCalculatorState();
}

class _BfrCalculatorState extends State<BfrCalculator> {
  double stocks = 0, creances = 0, fournisseurs = 0, autresC = 0, autresD = 0, ca = 0, fr = 0;
  bool withFr = false;

  @override
  Widget build(BuildContext context) {
    final r = calculBfr(
      stocks: stocks,
      creances: creances,
      dettesFournisseurs: fournisseurs,
      autresCreances: autresC,
      autresDettes: autresD,
      chiffreAffairesAnnuel: ca,
      fondsDeRoulement: withFr ? fr : null,
    );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        FieldRow(children: [
          NumInput(label: 'Stocks', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => stocks = v)),
          NumInput(label: 'Créances clients', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => creances = v)),
        ]),
        FieldRow(children: [
          NumInput(label: 'Dettes fournisseurs', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => fournisseurs = v)),
          NumInput(label: 'Chiffre d’affaires annuel', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => ca = v)),
        ]),
        FieldRow(children: [
          NumInput(label: 'Autres créances d’exploitation', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => autresC = v)),
          NumInput(label: 'Autres dettes d’exploitation', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => autresD = v)),
        ]),
        ToggleInput(label: 'Je connais mon fonds de roulement', value: withFr, onChanged: (v) => setState(() => withFr = v)),
        if (withFr) NumInput(label: 'Fonds de roulement', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => fr = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultBig('BFR', _m(r.bfr)),
        ResultLine('BFR en jours de chiffre d’affaires', ca > 0 ? '${Fmt.num(r.joursCa, d: 0)} jours' : '—'),
        if (withFr)
          ResultLine('Trésorerie nette (FR − BFR)', _m(r.tresorerieNette), color: r.tresorerieNette >= 0 ? _good : _bad),
        if (withFr && r.tresorerieNette < 0)
          const ResultNote('Un BFR supérieur au fonds de roulement se traduit par un besoin de trésorerie (découvert).', warning: true),
        const ResultNote('Leviers : délais clients, rotation des stocks et délais fournisseurs. Réduire le BFR libère de la trésorerie sans emprunt.'),
      ]),
    ]);
  }
}

// ============================ SEUIL DE RENTABILITÉ ===========================
class SeuilCalculator extends StatefulWidget {
  const SeuilCalculator({super.key});
  @override
  State<SeuilCalculator> createState() => _SeuilCalculatorState();
}

class _SeuilCalculatorState extends State<SeuilCalculator> {
  double ca = 0, cv = 0, cf = 0;

  @override
  Widget build(BuildContext context) {
    final r = seuilRentabilite(ca: ca, chargesVariables: cv, chargesFixes: cf);
    final ready = ca > 0;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        NumInput(label: 'Chiffre d’affaires (annuel)', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => ca = v)),
        FieldRow(children: [
          NumInput(label: 'Charges variables', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => cv = v)),
          NumInput(label: 'Charges fixes', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => cf = v)),
        ]),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        if (!ready)
          const ResultNote('Saisissez le chiffre d’affaires et les charges pour obtenir le seuil.')
        else ...[
          ResultLine('Marge sur coût variable', _m(r.mcv)),
          ResultLine('Taux de marge sur coût variable', '${Fmt.num(r.tauxMcv * 100, d: 2)} %'),
          ResultBig('Seuil de rentabilité', r.seuil.isFinite ? _m(r.seuil) : 'non atteignable'),
          ResultLine('Résultat', _m(r.resultat), color: r.resultat >= 0 ? _good : _bad),
          ResultLine('Marge de sécurité', r.seuil.isFinite ? _m(r.margeSecurite) : '—'),
          ResultLine('Point mort', r.pointMortJours.isFinite ? '${Fmt.num(r.pointMortJours, d: 0)} jours (base 360)' : '—'),
          ResultNote(r.atteint ? 'Le chiffre d’affaires dépasse le seuil : l’activité est bénéficiaire.' : 'Le chiffre d’affaires est inférieur au seuil : l’activité est déficitaire.',
              warning: !r.atteint),
        ],
      ]),
    ]);
  }
}

// ========================== TRÉSORERIE PRÉVISIONNELLE ========================
class TresorerieCalculator extends StatefulWidget {
  const TresorerieCalculator({super.key});
  @override
  State<TresorerieCalculator> createState() => _TresorerieCalculatorState();
}

class _TresorerieCalculatorState extends State<TresorerieCalculator> {
  double initial = 0;
  final enc = List<double>.filled(6, 0);
  final dec = List<double>.filled(6, 0);

  @override
  Widget build(BuildContext context) {
    final plan = planTresorerie(soldeInitial: initial, encaissements: enc, decaissements: dec);
    final minSolde = plan.isEmpty ? initial : plan.map((m) => m.soldeFin).reduce((a, b) => a < b ? a : b);
    final now = DateTime.now();
    String month(int i) => Fmt.monthYear(DateTime(now.year, now.month + i, 1));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        NumInput(label: 'Trésorerie disponible aujourd’hui', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => initial = v)),
        for (var i = 0; i < 6; i++) ...[
          Text(month(i)[0].toUpperCase() + month(i).substring(1),
              style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
          const SizedBox(height: 8),
          FieldRow(children: [
            NumInput(key: ValueKey('e$i'), label: 'Encaissements', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => enc[i] = v)),
            NumInput(key: ValueKey('d$i'), label: 'Décaissements', suffix: 'TND', initial: 0, onChanged: (v) => setState(() => dec[i] = v)),
          ]),
        ],
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        for (final m in plan)
          ResultLine('Fin ${month(m.mois - 1)}', _m(m.soldeFin), color: m.soldeFin >= 0 ? null : _bad),
        ResultBig('Solde le plus bas', _m(minSolde), color: minSolde >= 0 ? _good : _bad),
        ResultNote(minSolde < 0
            ? 'Besoin de financement de ${_m(-minSolde)} à anticiper (découvert, facilité de caisse, décalage de paiements…).'
            : 'Aucun mois de tension sur la période, selon vos prévisions.'),
      ]),
    ]);
  }
}

// =========================== BUDGET / RÉALISÉ / ÉCART ========================
class BudgetCalculator extends StatefulWidget {
  const BudgetCalculator({super.key});
  @override
  State<BudgetCalculator> createState() => _BudgetCalculatorState();
}

class _Line {
  String label;
  double budget = 0, realise = 0;
  bool charge;
  _Line(this.label, this.charge);
}

class _BudgetCalculatorState extends State<BudgetCalculator> {
  final _lines = <_Line>[
    _Line('Chiffre d’affaires', false),
    _Line('Achats consommés', true),
    _Line('Charges de personnel', true),
    _Line('Autres charges', true),
  ];
  int _seq = 0;

  @override
  Widget build(BuildContext context) {
    final lines = [for (final l in _lines) BudgetLine(l.label, l.budget, l.realise, charge: l.charge)];
    double resultat(bool real) => lines.fold(0.0, (s, l) => s + (l.charge ? -1 : 1) * (real ? l.realise : l.budget));
    final rb = resultat(false), rr = resultat(true);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      for (var i = 0; i < _lines.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: FormCard(children: [
            Row(children: [
              Expanded(
                child: TextInput(
                  key: ValueKey('lbl_${_lines[i].hashCode}'),
                  label: 'Libellé',
                  initial: _lines[i].label,
                  onChanged: (v) => setState(() => _lines[i].label = v),
                ),
              ),
              IconButton(
                tooltip: 'Supprimer la ligne',
                onPressed: _lines.length <= 1 ? null : () => setState(() => _lines.removeAt(i)),
                icon: const Icon(Icons.delete_outline),
              ),
            ]),
            ChoiceInput<bool>(
              label: 'Nature',
              value: _lines[i].charge,
              items: const [(false, 'Produit (recette)'), (true, 'Charge (dépense)')],
              onChanged: (v) => setState(() => _lines[i].charge = v),
            ),
            FieldRow(children: [
              NumInput(key: ValueKey('b_${_lines[i].hashCode}'), label: 'Budget', suffix: 'TND', initial: _lines[i].budget, onChanged: (v) => setState(() => _lines[i].budget = v)),
              NumInput(key: ValueKey('r_${_lines[i].hashCode}'), label: 'Réalisé', suffix: 'TND', initial: _lines[i].realise, onChanged: (v) => setState(() => _lines[i].realise = v)),
            ]),
          ]),
        ),
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () => setState(() => _lines.add(_Line('Nouvelle ligne ${++_seq}', true))),
          icon: const Icon(Icons.add),
          label: const Text('Ajouter une ligne'),
        ),
      ),
      const SizedBox(height: 8),
      ResultPanel(children: [
        for (final l in lines)
          ResultLine(
            l.libelle,
            '${l.ecart >= 0 ? '+' : ''}${Fmt.num(l.ecart)}${l.ecartPct == null ? '' : '  (${l.ecartPct! >= 0 ? '+' : ''}${Fmt.num(l.ecartPct! * 100, d: 1)} %)'}',
            color: l.budget == 0 && l.realise == 0 ? null : (l.favorable ? _good : _bad),
          ),
        ResultLine('Résultat budgété', _m(rb)),
        ResultBig('Résultat réalisé', _m(rr), color: rr >= rb ? _good : _bad),
        const ResultNote('Écart = Réalisé − Budget. Vert : écart favorable ; orange : écart défavorable (une charge supérieure au budget est défavorable).'),
      ]),
      const SizedBox(height: 8),
      Text('Astuce : renseignez vos montants mensuels ou cumulés à date.', style: TextStyle(fontSize: 12, color: context.mutedText)),
    ]);
  }
}
