import 'package:flutter/material.dart';

import '../../../core/utils/format.dart';
import '../engines/fiscal_engines.dart';
import 'tool_form.dart';

const _cssItems = [(0.01, '1 % (2026)'), (0.005, '0,5 % (2023-2025)')];

String _m(double x) => Fmt.dt(x);
int _ci(double v, int lo, int hi) {
  final r = v.round();
  return r < lo ? lo : (r > hi ? hi : r);
}
String _neg(double x) => '- ${Fmt.dt(x)}';

// =============================== 1. PAIE ======================================
class PaieCalculator extends StatefulWidget {
  const PaieCalculator({super.key});
  @override
  State<PaieCalculator> createState() => _PaieCalculatorState();
}

class _PaieCalculatorState extends State<PaieCalculator> {
  bool public = false, fromNet = false, chef = false, diplome = false;
  double montant = 2200, css = 0.01;
  int enfants = 0, etudiants = 0, handicapes = 0, annee = 1;

  @override
  Widget build(BuildContext context) {
    final r = simulateurPaie(
      secteurPublic: public,
      depuisNet: fromNet,
      montant: montant,
      enfants: enfants,
      etudiants: etudiants,
      handicapes: handicapes,
      cssTaux: css,
      chef: chef,
      diplome: diplome,
      anneeContrat: annee,
    );
    final tx = public ? Taux.cnrps : Taux.cnss;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<bool>(label: 'Secteur', value: public, items: const [(false, 'Privé — CNSS 9,68 %'), (true, 'Public — CNRPS 12,95 %')], onChanged: (v) => setState(() => public = v)),
        ChoiceInput<bool>(label: 'Point de départ', value: fromNet, items: const [(false, 'Je connais le brut'), (true, 'Je connais le net')], onChanged: (v) => setState(() => fromNet = v)),
        NumInput(
            key: ValueKey(fromNet),
            label: fromNet ? 'Salaire net mensuel souhaité' : 'Salaire brut mensuel',
            suffix: 'TND',
            initial: montant,
            onChanged: (v) => setState(() => montant = v)),
        FieldRow(children: [
          NumInput(label: 'Enfants < 20 ans', integer: true, initial: 0, onChanged: (v) => setState(() => enfants = _ci(v, 0, 4))),
          NumInput(label: 'Étudiants < 25 ans', integer: true, initial: 0, onChanged: (v) => setState(() => etudiants = _ci(v, 0, 4))),
        ]),
        FieldRow(children: [
          NumInput(label: 'Enfants handicapés', integer: true, initial: 0, onChanged: (v) => setState(() => handicapes = v.round())),
          ChoiceInput<double>(label: 'Taux CSS', value: css, items: _cssItems, onChanged: (v) => setState(() => css = v)),
        ]),
        ToggleInput(label: 'Chef de famille', subtitle: 'Déduction de 300 D par an', value: chef, onChanged: (v) => setState(() => chef = v)),
        ToggleInput(label: 'Diplômé du supérieur recruté à partir du 01/01/2026', value: diplome, onChanged: (v) => setState(() => diplome = v)),
        if (diplome)
          ChoiceInput<int>(
            label: 'Année du contrat',
            value: annee,
            items: const [(1, 'Année 1 — 100 % pris en charge'), (2, 'Année 2 — 80 %'), (3, 'Année 3 — 60 %'), (4, 'Année 4 — 40 %'), (5, 'Année 5 — 20 %'), (0, 'Au-delà — aucune prise en charge')],
            onChanged: (v) => setState(() => annee = v),
          ),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Salaire brut', _m(r.brut)),
        ResultLine('Retenue ${public ? 'CNRPS' : 'CNSS'} (${Fmt.num(tx * 100, d: 2)} %)', _neg(r.cot), negative: true),
        ResultLine('Salaire brut imposable', _m(r.imp)),
        ResultLine('Retenue à la source (IRPP)', _neg(r.ir), negative: true),
        ResultLine('Contribution sociale de solidarité', _neg(r.css), negative: true),
        ResultBig('Salaire net', _m(r.net)),
        const ResultNote('Côté employeur'),
        ResultLine('Cotisation patronale (16,57 %)', _m(r.patronal)),
        if (r.aide > 0) ResultLine('Prise en charge État (LF 2026)', _neg(r.aide), negative: true),
        ResultLine('Coût total employeur', _m(r.coutEmployeur)),
        ResultNote('Assiette imposable annuelle : ${_m(r.assiette)} — déductions appliquées : ${_m(r.d.total)}.'),
        const ResultNote('La déduction pour parents à charge n’est pas intégrée : elle n’est prise en compte qu’au moment de la déclaration à la recette des finances.'),
      ]),
    ]);
  }
}

// =============================== 2. IRPP ======================================
class IrppCalculator extends StatefulWidget {
  const IrppCalculator({super.key});
  @override
  State<IrppCalculator> createState() => _IrppCalculatorState();
}

class _IrppCalculatorState extends State<IrppCalculator> {
  String nature = 'salaire';
  double revenu = 36000, css = 0.01;
  int enfants = 2, etudiants = 0, handicapes = 0, parents = 0;
  bool chef = true;

  @override
  Widget build(BuildContext context) {
    final r = calculIrpp(
        nature: nature, revenu: revenu, enfants: enfants, etudiants: etudiants, handicapes: handicapes, parents: parents, chef: chef, cssTaux: css);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<String>(
            label: 'Nature du revenu',
            value: nature,
            items: const [('salaire', 'Salaire (actif)'), ('pension', 'Pension de retraite'), ('benefice', 'Bénéfice net (BIC / BNC)')],
            onChanged: (v) => setState(() => nature = v)),
        NumInput(label: 'Revenu imposable annuel', suffix: 'TND', initial: revenu, onChanged: (v) => setState(() => revenu = v)),
        FieldRow(children: [
          NumInput(label: 'Enfants < 20 ans', integer: true, initial: 2, onChanged: (v) => setState(() => enfants = _ci(v, 0, 4))),
          NumInput(label: 'Étudiants < 25 ans', integer: true, initial: 0, onChanged: (v) => setState(() => etudiants = _ci(v, 0, 4))),
        ]),
        FieldRow(children: [
          NumInput(label: 'Enfants handicapés', integer: true, initial: 0, onChanged: (v) => setState(() => handicapes = v.round())),
          NumInput(label: 'Parents à charge', integer: true, initial: 0, onChanged: (v) => setState(() => parents = _ci(v, 0, 4))),
        ]),
        ToggleInput(label: 'Chef de famille', value: chef, onChanged: (v) => setState(() => chef = v)),
        ChoiceInput<double>(label: 'Taux CSS', value: css, items: _cssItems, onChanged: (v) => setState(() => css = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Revenu imposable', _m(r.revenu)),
        if (!r.benefice) ResultLine('Frais professionnels', _neg(r.d.fp), negative: true),
        ResultLine('Chef de famille', _neg(r.d.chef), negative: true),
        ResultLine('Enfants et étudiants', _neg(r.d.enf + r.d.etu), negative: true),
        ResultLine('Enfants handicapés', _neg(r.d.hnd), negative: true),
        ResultLine('Parents à charge', _neg(r.d.par), negative: true),
        ResultLine('Assiette imposable', _m(r.assiette)),
        ResultBig('IRPP annuel', _m(r.r.total)),
        ResultLine('IRPP mensuel', _m(r.r.total / 12)),
        ResultLine('Contribution sociale de solidarité', _m(r.css)),
        ResultLine('Total annuel à payer', _m(r.r.total + r.css)),
        ResultLine('Taux effectif d’imposition', '${Fmt.num(r.effectif, d: 2)} %'),
      ]),
      const SizedBox(height: 16),
      Text('Détail par tranche', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      SimpleTable(
        headers: const ['Tranche', 'Taux', 'Base', 'Impôt'],
        rows: r.r.lignes.isEmpty
            ? [const ['Aucun impôt dû.', '', '', '']]
            : [
                for (final l in r.r.lignes)
                  [
                    l.bas == 0
                        ? 'Jusqu’à ${Fmt.num(l.haut, d: 0)} D'
                        : 'De ${Fmt.num(l.bas, d: 0)} à ${l.haut.isFinite ? Fmt.num(l.haut, d: 0) : '∞'} D',
                    '${(l.taux * 100).round()} %',
                    Fmt.num(l.base),
                    Fmt.num(l.impot),
                  ],
              ],
      ),
    ]);
  }
}

// ======================== 3. RETENUE À LA SOURCE ==============================
class RasCalculator extends StatefulWidget {
  const RasCalculator({super.key});
  @override
  State<RasCalculator> createState() => _RasCalculatorState();
}

class _RasCalculatorState extends State<RasCalculator> {
  String nature = rasNatures.first.id;
  double ht = 5000, tva = 0.19;
  bool baseHt = false, timbre = true;

  @override
  Widget build(BuildContext context) {
    final n = rasNatures.firstWhere((e) => e.id == nature);
    final r = retenueSource(taux: n.taux, ht: ht, tauxTva: tva, baseHt: baseHt, timbre: timbre);
    final next = DateTime(DateTime.now().year, DateTime.now().month + 1, 1);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<String>(
          label: 'Nature du paiement',
          value: nature,
          items: [for (final e in rasNatures) (e.id, '${e.label} — ${Fmt.rate(e.taux)}')],
          onChanged: (v) => setState(() => nature = v),
        ),
        NumInput(label: 'Montant hors taxes', suffix: 'TND', initial: ht, onChanged: (v) => setState(() => ht = v)),
        FieldRow(children: [
          ChoiceInput<double>(
              label: 'TVA applicable',
              value: tva,
              items: const [(0.19, '19 %'), (0.13, '13 %'), (0.07, '7 %'), (0.0, 'Exonéré / hors champ')],
              onChanged: (v) => setState(() => tva = v)),
          ChoiceInput<bool>(
              label: 'Base de la retenue',
              value: baseHt,
              items: const [(false, 'Montant TTC'), (true, 'Montant HT')],
              onChanged: (v) => setState(() => baseHt = v)),
        ]),
        ToggleInput(label: 'Ajouter le droit de timbre de 1 dinar', value: timbre, onChanged: (v) => setState(() => timbre = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Montant HT', _m(r.ht)),
        ResultLine('TVA (${Fmt.rate(tva)})', _m(r.tva)),
        ResultLine('Droit de timbre', _m(r.timbre)),
        ResultLine('Montant TTC', _m(r.ttc)),
        ResultLine('Base de la retenue', _m(r.base)),
        ResultLine('Taux appliqué', Fmt.rate(r.taux)),
        ResultBig('Retenue à la source', _m(r.retenue)),
        ResultLine('Net à payer au bénéficiaire', _m(r.net)),
        ResultNote(
            'À reverser au plus tard le 28 ${Fmt.monthYear(next)}. Certificat à générer exclusivement sur la plateforme TEJ. Pénalité jusqu’à 30 % du montant, minimum 50 dinars, en cas de manquement.'),
        const ResultNote('La retenue s’applique au moment du règlement, pas de la facturation.'),
      ]),
    ]);
  }
}

// =================================== 4. TVA ===================================
class TvaCalculator extends StatefulWidget {
  const TvaCalculator({super.key});
  @override
  State<TvaCalculator> createState() => _TvaCalculatorState();
}

class _TvaCalculatorState extends State<TvaCalculator> {
  bool fromTtc = false, timbre = true;
  double taux = 0.19, montant = 1000;
  int qte = 1;

  @override
  Widget build(BuildContext context) {
    final r = calculTva(depuisTtc: fromTtc, taux: taux, montant: montant, quantite: qte, timbre: timbre);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<bool>(
            label: 'Sens du calcul',
            value: fromTtc,
            items: const [(false, 'Du HT vers le TTC'), (true, 'Du TTC vers le HT')],
            onChanged: (v) => setState(() => fromTtc = v)),
        ChoiceInput<double>(
            label: 'Taux de TVA',
            value: taux,
            items: const [(0.19, '19 % — taux de droit commun'), (0.13, '13 % — hôtellerie, tourisme'), (0.07, '7 % — première nécessité, santé'), (0.0, '0 % — exonéré')],
            onChanged: (v) => setState(() => taux = v)),
        NumInput(
            key: ValueKey(fromTtc),
            label: fromTtc ? 'Montant toutes taxes comprises' : 'Montant hors taxes',
            suffix: 'TND',
            initial: montant,
            onChanged: (v) => setState(() => montant = v)),
        NumInput(label: 'Quantité', integer: true, initial: 1, onChanged: (v) => setState(() => qte = v.round() < 1 ? 1 : v.round())),
        ToggleInput(
            label: 'Droit de timbre fiscal de 1 dinar',
            subtitle: 'Il s’ajoute après le calcul de la TVA et ne fait pas partie de la base imposable.',
            value: timbre,
            onChanged: (v) => setState(() => timbre = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Montant hors taxes', _m(r.ht)),
        ResultLine('TVA (${Fmt.rate(taux)})', _m(r.tva)),
        ResultLine('Total TTC hors timbre', _m(r.ttcHorsTimbre)),
        ResultLine('Droit de timbre', _m(r.timbre)),
        ResultBig('Net à payer', _m(r.net)),
        ResultNote('Prix unitaire HT : ${_m(r.unitHt)} — quantité : ${r.quantite}.'),
      ]),
    ]);
  }
}

// ============================ 5. PENSION DE RETRAITE ==========================
class PensionCalculator extends StatefulWidget {
  const PensionCalculator({super.key});
  @override
  State<PensionCalculator> createState() => _PensionCalculatorState();
}

class _PensionCalculatorState extends State<PensionCalculator> {
  bool public = false, chef = false, comp = false;
  double salaire = 2000, css = 0.01;
  int annees = 30, trimestres = 0, enfants = 0;

  @override
  Widget build(BuildContext context) {
    final r = calculPension(
        secteurPublic: public, salaire: salaire, annees: annees, trimestres: trimestres, enfants: enfants, cssTaux: css, chef: chef, complementaire: comp);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<bool>(
            label: 'Régime',
            value: public,
            items: const [(false, 'Secteur privé — CNSS'), (true, 'Secteur public — CNRPS')],
            onChanged: (v) => setState(() => public = v)),
        NumInput(
            key: ValueKey(public),
            label: public ? 'Dernier salaire brut perçu pendant 3 ans (par mois)' : 'Salaire brut moyen actualisé des 10 dernières années (par mois)',
            suffix: 'TND',
            initial: salaire,
            onChanged: (v) => setState(() => salaire = v)),
        FieldRow(children: [
          NumInput(label: 'Durée de cotisation (années)', integer: true, initial: 30, onChanged: (v) => setState(() => annees = _ci(v, 0, 45))),
          NumInput(label: 'Trimestres supplémentaires', integer: true, initial: 0, onChanged: (v) => setState(() => trimestres = _ci(v, 0, 3))),
        ]),
        FieldRow(children: [
          NumInput(label: 'Enfants à charge', integer: true, initial: 0, onChanged: (v) => setState(() => enfants = _ci(v, 0, 4))),
          ChoiceInput<double>(label: 'Taux CSS', value: css, items: _cssItems, onChanged: (v) => setState(() => css = v)),
        ]),
        ToggleInput(label: 'Chef de famille', value: chef, onChanged: (v) => setState(() => chef = v)),
        ToggleInput(label: 'Retraite complémentaire souscrite (déplafonnement)', value: comp, onChanged: (v) => setState(() => comp = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        if (!r.ok) ResultNote('Durée de cotisation insuffisante : ${r.minDuree} ans minimum requis dans ce régime.', warning: true),
        ResultLine('Salaire brut de référence', _m(r.ref)),
        if (r.plafonne) ResultLine('Plafond appliqué (6 × SMIG)', _m(r.plafond)),
        ResultLine('Taux de pension', '${Fmt.num(r.taux * 100, d: 2)} %'),
        ResultLine('Pension brute', _m(r.brut)),
        ResultLine('Assurance maladie (4 %)', _neg(r.cnam), negative: true),
        ResultLine('Capital décès (0,5 %)', _neg(r.kd), negative: true),
        ResultLine('Impôt sur le revenu', _neg(r.ir), negative: true),
        ResultLine('Contribution sociale de solidarité', _neg(r.css), negative: true),
        ResultBig('Pension nette mensuelle', _m(r.net)),
        ResultNote('Plafond de référence dans le privé : 6 × SMIG, soit ${_m(r.plafond)}. Les retraités bénéficient d’une déduction pour frais professionnels de 25 % sans plafond.'),
      ]),
    ]);
  }
}

// ================================ 6. VIGNETTE ==================================
class VignetteCalculator extends StatefulWidget {
  const VignetteCalculator({super.key});
  @override
  State<VignetteCalculator> createState() => _VignetteCalculatorState();
}

class _VignetteCalculatorState extends State<VignetteCalculator> {
  bool pm = false, location = false;
  String cv = '4', energie = '0';
  int chiffre = 4;

  @override
  Widget build(BuildContext context) {
    final r = calculVignette(personneMorale: pm, puissance: cv, energie: energie, dernierChiffre: chiffre, location: location);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        ChoiceInput<bool>(
            label: 'Propriétaire', value: pm, items: const [(false, 'Personne physique'), (true, 'Personne morale')], onChanged: (v) => setState(() => pm = v)),
        ChoiceInput<String>(
            label: 'Puissance fiscale',
            value: cv,
            items: [for (final k in vignetteGrille.keys) (k, vignetteLabel(k))],
            onChanged: (v) => setState(() => cv = v)),
        ChoiceInput<String>(
            label: 'Énergie',
            value: energie,
            items: const [('0', 'Essence'), ('1', 'Diesel'), ('2', 'GPL'), ('e', '100 % électrique'), ('h0', 'Hybride essence'), ('h1', 'Hybride diesel')],
            onChanged: (v) => setState(() => energie = v)),
        NumInput(label: 'Dernier chiffre de l’immatriculation', integer: true, initial: 4, onChanged: (v) => setState(() => chiffre = v.round() % 10)),
        ToggleInput(label: 'Véhicule de location ou en leasing (Ijâra)', value: location, onChanged: (v) => setState(() => location = v)),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Tarif de base', _m(r.plein)),
        if (r.reduction > 0) ResultLine('Réduction véhicule électrique', _neg(r.reduction), negative: true),
        ResultBig('Vignette 2026 à payer', _m(r.du)),
        ResultLine('Date limite de paiement', r.limite),
        ResultNote('${r.note.isEmpty ? '' : '${r.note} '}Paiement en ligne sur taxe-circulation.finances.gov.tn ou au guichet des recettes des finances. Conservez le récépissé ou le QR code : il n’y a plus de macaron à coller. Amnistie LF 2026 : payer dans les délais régularise gratuitement les impayés antérieurs à 2025.'),
      ]),
    ]);
  }
}

// ============================ 7. SIMULATEUR DE CRÉDIT =========================
class CreditCalculator extends StatefulWidget {
  const CreditCalculator({super.key});
  @override
  State<CreditCalculator> createState() => _CreditCalculatorState();
}

class _CreditCalculatorState extends State<CreditCalculator> {
  double montant = 100000, taux = 10.5, ass = 0.4, frais = 500;
  int duree = 84;
  bool constante = true;

  @override
  Widget build(BuildContext context) {
    final r = simulateurCredit(montant: montant, dureeMois: duree, tauxAnnuelPct: taux, mensualiteConstante: constante, assurancePct: ass, frais: frais);
    final teg = coutAnnuelMoyen(r, duree);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        FieldRow(children: [
          NumInput(label: 'Montant emprunté', suffix: 'TND', initial: montant, onChanged: (v) => setState(() => montant = v)),
          NumInput(label: 'Durée', suffix: 'mois', integer: true, initial: 84, onChanged: (v) => setState(() => duree = _ci(v, 1, 360))),
        ]),
        FieldRow(children: [
          NumInput(label: 'Taux annuel nominal', suffix: '%', initial: taux, onChanged: (v) => setState(() => taux = v)),
          ChoiceInput<bool>(
              label: 'Amortissement',
              value: constante,
              items: const [(true, 'Mensualité constante'), (false, 'Amortissement constant')],
              onChanged: (v) => setState(() => constante = v)),
        ]),
        FieldRow(children: [
          NumInput(label: 'Assurance (% annuel)', suffix: '%', initial: ass, onChanged: (v) => setState(() => ass = v)),
          NumInput(label: 'Frais de dossier', suffix: 'TND', initial: frais, onChanged: (v) => setState(() => frais = v)),
        ]),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultBig(constante ? 'Mensualité' : 'Première mensualité', _m(r.m1)),
        if (!constante) ResultLine('Dernière mensualité', _m(r.mN)),
        ResultLine('Capital emprunté', _m(r.capital)),
        ResultLine('Total des intérêts', _m(r.totInterets)),
        ResultLine('Total assurance', _m(r.totAssurance)),
        ResultLine('Frais de dossier', _m(r.frais)),
        ResultLine('Coût total du crédit', _m(r.coutTotal)),
        ResultLine('Total remboursé', _m(r.totalRembourse)),
        ResultLine('Coût annuel moyen rapporté au capital', '${Fmt.num(teg, d: 2)} %'),
        const ResultNote('Indicateur de comparaison, distinct du taux effectif global calculé par la banque selon ses propres règles.'),
      ]),
      const SizedBox(height: 16),
      Text('Tableau d’amortissement — 12 premières échéances et dernière', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      SimpleTable(
        headers: const ['N°', 'Mensualité', 'Capital', 'Intérêts', 'Restant dû'],
        rows: [for (final e in r.rows) ['${e.n}', Fmt.num(e.mensualite), Fmt.num(e.capital), Fmt.num(e.interets), Fmt.num(e.restant)]],
      ),
    ]);
  }
}

// ============================= 8. MATRICULE FISCAL ============================
class MatriculeCalculator extends StatefulWidget {
  const MatriculeCalculator({super.key});
  @override
  State<MatriculeCalculator> createState() => _MatriculeCalculatorState();
}

class _MatriculeCalculatorState extends State<MatriculeCalculator> {
  String saisie = '1234567AMC000';

  @override
  Widget build(BuildContext context) {
    final r = verifierMatricule(saisie);
    String st(bool b) => b ? 'conforme' : 'à vérifier';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FormCard(children: [
        TextInput(label: 'Matricule fiscal', initial: saisie, caps: true, onChanged: (v) => setState(() => saisie = v)),
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            'Format attendu : 7 chiffres, une clé de contrôle, un code TVA, un code catégorie et trois chiffres d’établissement. Les séparateurs, espaces et barres obliques sont ignorés.\n\nCodes TVA : A assujetti obligatoire · B assujetti par option · D assujetti partiel par option · P assujetti partiel · N non assujetti.\nCodes catégorie : M personne morale · C commerçant ou industriel · P profession libérale · N employeur non soumis · E établissement secondaire.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5),
          ),
        ),
      ]),
      const SizedBox(height: 16),
      ResultPanel(children: [
        ResultLine('Saisie normalisée', r.normalise.isEmpty ? '—' : r.normalise),
        ResultLine('Longueur', '${r.normalise.length} caractères${r.normalise.length == 13 ? '' : ' (13 attendus)'}'),
        ResultLine('Identifiant fiscal', r.numOk ? r.chiffres : 'format invalide'),
        ResultLine('Clé de contrôle saisie', r.cle.isEmpty ? '—' : r.cle),
        ResultLine('Clé recalculée (modulo 23)', r.attendue),
        ResultLine('Structure de la clé', r.longueurOk && r.numOk ? st(r.cleOk) : '—',
            color: r.longueurOk && r.numOk ? (r.cleOk ? const Color(0xFF7BE0B0) : const Color(0xFFFFB48A)) : null),
        ResultLine('Code TVA — ${r.tva.isEmpty ? '—' : r.tva}', mfTva[r.tva] ?? 'code inconnu'),
        ResultLine('Code catégorie — ${r.cat.isEmpty ? '—' : r.cat}', mfCat[r.cat] ?? 'code inconnu'),
        ResultLine('Établissement', r.etab == '000' ? '000 — établissement principal' : (r.etab.isNotEmpty ? '${r.etab} — établissement secondaire' : '—')),
        const ResultNote('Vérification indicative de la structure. Seule l’administration fiscale fait foi sur la validité d’un matricule ; consultez le portail des impôts pour une confirmation officielle.'),
      ]),
    ]);
  }
}
