import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';

InputDecoration toolDecoration(BuildContext context, String label, {String? suffix, String? hint}) {
  final r = BorderRadius.circular(12);
  return InputDecoration(
    labelText: label,
    hintText: hint,
    suffixText: suffix,
    isDense: false,
    filled: true,
    fillColor: context.isDark ? CC.darkSurface : CC.mist,
    floatingLabelBehavior: FloatingLabelBehavior.always,
    contentPadding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
    border: OutlineInputBorder(borderRadius: r, borderSide: BorderSide(color: context.lineColor)),
    enabledBorder: OutlineInputBorder(borderRadius: r, borderSide: BorderSide(color: context.lineColor)),
    focusedBorder: OutlineInputBorder(borderRadius: r, borderSide: BorderSide(color: context.accentText, width: 1.6)),
    labelStyle: TextStyle(color: context.mutedText, fontWeight: FontWeight.w600),
  );
}

/// Champ numérique (décimales acceptées avec virgule ou point).
class NumInput extends StatefulWidget {
  const NumInput({super.key, required this.label, required this.initial, required this.onChanged, this.suffix, this.integer = false, this.hint});
  final String label;
  final double initial;
  final ValueChanged<double> onChanged;
  final String? suffix;
  final bool integer;
  final String? hint;

  @override
  State<NumInput> createState() => _NumInputState();
}

class _NumInputState extends State<NumInput> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    final v = widget.initial;
    _c = TextEditingController(text: widget.integer || v == v.roundToDouble() ? v.round().toString() : v.toString().replaceAll('.', ','));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: _c,
        keyboardType: TextInputType.numberWithOptions(decimal: !widget.integer, signed: false),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(widget.integer ? r'[0-9]' : r'[0-9.,\s]'))],
        decoration: toolDecoration(context, widget.label, suffix: widget.suffix, hint: widget.hint),
        style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText),
        onChanged: (v) => widget.onChanged(Fmt.parse(v)),
      ),
    );
  }
}

class TextInput extends StatefulWidget {
  const TextInput({super.key, required this.label, required this.initial, required this.onChanged, this.caps = false});
  final String label;
  final String initial;
  final ValueChanged<String> onChanged;
  final bool caps;

  @override
  State<TextInput> createState() => _TextInputState();
}

class _TextInputState extends State<TextInput> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: _c,
          textCapitalization: widget.caps ? TextCapitalization.characters : TextCapitalization.none,
          decoration: toolDecoration(context, widget.label),
          style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: widget.caps ? 1.2 : 0, color: context.strongText),
          onChanged: widget.onChanged,
        ),
      );
}

/// Liste de choix (sans DropdownButtonFormField pour rester compatible toutes versions).
class ChoiceInput<T> extends StatelessWidget {
  const ChoiceInput({super.key, required this.label, required this.value, required this.items, required this.onChanged});
  final String label;
  final T value;
  final List<(T, String)> items;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: InputDecorator(
        decoration: toolDecoration(context, label).copyWith(contentPadding: const EdgeInsets.fromLTRB(14, 6, 8, 6)),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<T>(
            value: value,
            isExpanded: true,
            borderRadius: BorderRadius.circular(14),
            dropdownColor: context.cardColor,
            style: TextStyle(fontFamily: CCTheme.font, fontWeight: FontWeight.w700, color: context.strongText, fontSize: 14),
            items: [
              for (final it in items)
                DropdownMenuItem<T>(value: it.$1, child: Text(it.$2, maxLines: 2, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: (v) {
              if (v != null) onChanged(v);
            },
          ),
        ),
      ),
    );
  }
}

class ToggleInput extends StatelessWidget {
  const ToggleInput({super.key, required this.label, required this.value, required this.onChanged, this.subtitle});
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: SwitchListTile.adaptive(
        value: value,
        onChanged: onChanged,
        contentPadding: EdgeInsets.zero,
        title: Text(label, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: context.strongText)),
        subtitle: subtitle == null ? null : Text(subtitle!, style: TextStyle(fontSize: 12, color: context.mutedText)),
      ),
    );
  }
}

/// Deux champs côte à côte si la largeur le permet.
class FieldRow extends StatelessWidget {
  const FieldRow({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      if (c.maxWidth < 340) return Column(children: children);
      return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (var i = 0; i < children.length; i++) ...[
          if (i > 0) const SizedBox(width: 12),
          Expanded(child: children[i]),
        ],
      ]);
    });
  }
}

// ================================ résultats ==================================

class ResultPanel extends StatelessWidget {
  const ResultPanel({super.key, required this.children, this.title = 'Résultat'});
  final List<Widget> children;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title.toUpperCase(),
            style: const TextStyle(color: CC.orangeLight, fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1.6)),
        const SizedBox(height: 8),
        ...children,
      ]),
    );
  }
}

class ResultLine extends StatelessWidget {
  const ResultLine(this.label, this.value, {super.key, this.negative = false, this.color});
  final String label;
  final String value;
  final bool negative;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: CC.white.withValues(alpha: 0.1)))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Text(label, style: TextStyle(color: CC.white.withValues(alpha: 0.78), fontSize: 13.5, height: 1.35))),
        const SizedBox(width: 12),
        Flexible(
          child: Text(value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: color ?? (negative ? const Color(0xFFFFB48A) : CC.white),
                fontWeight: FontWeight.w700,
                fontSize: 13.5,
              )),
        ),
      ]),
    );
  }
}

class ResultBig extends StatelessWidget {
  const ResultBig(this.label, this.value, {super.key, this.color});
  final String label;
  final String value;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: CC.white.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14)),
      child: Row(children: [
        Expanded(child: Text(label, style: const TextStyle(color: CC.white, fontWeight: FontWeight.w700, fontSize: 14))),
        const SizedBox(width: 10),
        Flexible(
          child: Text(value,
              textAlign: TextAlign.right,
              style: TextStyle(color: color ?? CC.orangeLight, fontWeight: FontWeight.w800, fontSize: 20)),
        ),
      ]),
    );
  }
}

class ResultNote extends StatelessWidget {
  const ResultNote(this.text, {super.key, this.warning = false});
  final String text;
  final bool warning;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Text(text,
            style: TextStyle(color: warning ? const Color(0xFFFFB48A) : CC.white.withValues(alpha: 0.65), fontSize: 12, height: 1.5)),
      );
}

/// Tableau défilant horizontalement (échéancier, tranches…).
class SimpleTable extends StatelessWidget {
  const SimpleTable({super.key, required this.headers, required this.rows, this.numericFrom = 1});
  final List<String> headers;
  final List<List<String>> rows;
  final int numericFrom;

  @override
  Widget build(BuildContext context) {
    final head = TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: context.strongText);
    final cell = TextStyle(fontSize: 12.5, color: context.strongText);
    return Container(
      decoration: BoxDecoration(
        color: context.cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: context.lineColor),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.all(4),
        child: DataTable(
          headingRowHeight: 40,
          dataRowMinHeight: 36,
          dataRowMaxHeight: 52,
          columnSpacing: 22,
          horizontalMargin: 12,
          columns: [
            for (var i = 0; i < headers.length; i++)
              DataColumn(label: Text(headers[i], style: head), numeric: i >= numericFrom),
          ],
          rows: [
            for (final r in rows)
              DataRow(cells: [
                for (var i = 0; i < headers.length; i++) DataCell(Text(i < r.length ? r[i] : '', style: cell)),
              ]),
          ],
        ),
      ),
    );
  }
}

/// Carte blanche du formulaire.
class FormCard extends StatelessWidget {
  const FormCard({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
      decoration: BoxDecoration(
        color: context.cardColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: context.lineColor),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
    );
  }
}
