import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';
import 'core/services/analytics_service.dart';
import 'core/services/api_client.dart';
import 'core/services/connectivity_service.dart';
import 'core/services/push_service.dart';
import 'core/services/storage_service.dart';
import 'state/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Gestion propre des erreurs : rien n'est affiché à l'utilisateur en release,
  // les erreurs sont tracées en debug (et transmises à Crashlytics si activé).
  FlutterError.onError = (details) {
    if (kDebugMode) FlutterError.presentError(details);
  };
  WidgetsBinding.instance.platformDispatcher.onError = (error, stack) {
    if (kDebugMode) debugPrint('Erreur non gérée : $error');
    return true;
  };

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  final storage = await StorageService.create();
  final connectivity = ConnectivityService()..start();
  final state = AppState(
    storage: storage,
    api: ApiClient(),
    connectivity: connectivity,
    analytics: AnalyticsService(),
    push: PushService(),
  );
  unawaited(state.init());

  runApp(ChiffreConseilApp(state: state));
}
