import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../core/services/analytics_service.dart';
import '../core/services/api_client.dart';
import '../core/services/connectivity_service.dart';
import '../core/services/push_service.dart';
import '../core/services/storage_service.dart';
import '../data/models/content.dart';
import '../data/models/user_data.dart';
import '../data/repositories/content_repository.dart';

/// État global de l'application (ChangeNotifier, sans dépendance externe).
class AppState extends ChangeNotifier {
  AppState({
    required this.storage,
    required this.api,
    required this.connectivity,
    required this.analytics,
    required this.push,
  }) : _repo = ContentRepository(api);

  final StorageService storage;
  final ApiClient api;
  final ConnectivityService connectivity;
  final AnalyticsService analytics;
  final PushService push;
  final ContentRepository _repo;

  // Clés de stockage
  static const _kTheme = 'theme_mode';
  static const _kOnboarding = 'onboarding_done';
  static const _kFavorites = 'favorites';
  static const _kSeen = 'seen_articles';
  static const _kRecent = 'recent_articles';
  static const _kNotices = 'notices';
  static const _kNotifPrefs = 'notif_prefs';
  static const _kConsent = 'analytics_consent';
  static const _kConsentAsked = 'analytics_consent_asked';
  static const _sProfile = 'profile';
  static const _sCompanies = 'companies';
  static const _sRequests = 'requests';

  ContentBundle? _content;
  bool _refreshing = false;
  ThemeMode _themeMode = ThemeMode.system;
  bool _onboardingDone = false;
  Set<String> _favorites = {};
  List<String> _recent = [];
  Map<String, Article> _saved = {};
  UserProfile _profile = const UserProfile();
  List<Company> _companies = [];
  List<RequestRecord> _requests = [];
  List<AppNotice> _notices = [];
  Map<String, bool> _notifPrefs = {};
  bool _consent = false;
  bool _consentAsked = false;

  ContentBundle get content => _content!;
  bool get ready => _content != null;
  bool get refreshing => _refreshing;
  ThemeMode get themeMode => _themeMode;
  bool get onboardingDone => _onboardingDone;
  Set<String> get favorites => _favorites;
  List<Article> get savedDocs => _saved.values.toList()..sort((a, b) => a.title.compareTo(b.title));
  UserProfile get profile => _profile;
  List<Company> get companies => _companies;
  List<RequestRecord> get requests => _requests;
  List<AppNotice> get notices => _notices;
  int get unreadNotices => _notices.where((n) => !n.read).length;
  Map<String, bool> get notifPrefs => _notifPrefs;
  bool get analyticsConsent => _consent;
  bool get consentAsked => _consentAsked;
  bool get online => connectivity.online;

  List<Article> get recentArticles {
    final out = <Article>[];
    for (final s in _recent) {
      final a = _saved[s] ?? _content?.article(s);
      if (a != null) out.add(a);
    }
    return out;
  }

  List<Article> get favoriteArticles =>
      _content == null ? [] : _content!.articles.where((a) => _favorites.contains('a:${a.slug}')).toList();

  // ------------------------------------------------------------- démarrage --
  Future<void> init() async {
    _themeMode = switch (storage.getString(_kTheme)) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    _onboardingDone = storage.getBool(_kOnboarding);
    _favorites = storage.getList(_kFavorites).toSet();
    _recent = List<String>.of(storage.getList(_kRecent)); // copie modifiable (getList peut renvoyer une liste const)
    _consent = storage.getBool(_kConsent);
    _consentAsked = storage.getBool(_kConsentAsked);
    await analytics.setConsent(_consent);
    try {
      final raw = storage.getString(_kNotifPrefs);
      if (raw != null) {
        _notifPrefs = Map<String, dynamic>.from(jsonDecode(raw) as Map).map((k, v) => MapEntry(k, v == true));
      }
    } catch (_) {}
    for (final t in PushService.topics) {
      _notifPrefs.putIfAbsent(t.id, () => true);
    }
    try {
      final raw = storage.getString(_kNotices);
      if (raw != null) {
        _notices = (jsonDecode(raw) as List).whereType<Map>().map((e) => AppNotice.fromJson(Map<String, dynamic>.from(e))).toList();
      }
    } catch (_) {}

    final p = await storage.readSecureJson(_sProfile);
    if (p != null) _profile = UserProfile.fromJson(p);
    _companies = (await storage.readSecureList(_sCompanies)).map(Company.fromJson).toList();
    _requests = (await storage.readSecureList(_sRequests)).map(RequestRecord.fromJson).toList();
    await _loadSaved();

    _content = await _repo.loadLocal();
    _seedSeenOnFirstRun();
    notifyListeners();

    connectivity.addListener(_onConnectivity);
    await push.init();
    await push.apply(_notifPrefs);
    // actualisation en arrière-plan
    refreshContent();
  }

  void _onConnectivity() {
    notifyListeners();
    if (connectivity.online) {
      retryPending();
    }
  }

  Future<void> refreshContent() async {
    if (_refreshing || _content == null) return;
    _refreshing = true;
    notifyListeners();
    final next = await _repo.refresh(_content!);
    if (next == null) {
      connectivity.reportFailure();
    } else {
      connectivity.reportSuccess();
      _detectNew(next);
      _content = next;
    }
    _refreshing = false;
    notifyListeners();
  }

  // -------------------------------------------- nouveautés -> notifications --
  void _seedSeenOnFirstRun() {
    if (storage.getList(_kSeen).isEmpty && _content != null) {
      storage.setList(_kSeen, _content!.articles.map((a) => a.slug).toList());
    }
  }

  void _detectNew(ContentBundle next) {
    final seen = storage.getList(_kSeen).toSet();
    final fresh = next.articles.where((a) => !seen.contains(a.slug)).toList();
    if (fresh.isEmpty) return;
    for (final a in fresh.take(5)) {
      final topic = a.category == 'Fiscalité' ? 'fiscalite' : (a.kind == 'guide' ? 'ressources' : 'articles');
      if (_notifPrefs[topic] == false) continue;
      _notices.insert(
        0,
        AppNotice(
          id: 'n_${a.slug}',
          topic: topic,
          title: a.kind == 'guide' ? 'Nouveau guide disponible' : 'Nouvelle analyse disponible',
          body: a.title,
          date: DateTime.now(),
          route: '/blog/${a.slug}',
        ),
      );
    }
    seen.addAll(fresh.map((a) => a.slug));
    storage.setList(_kSeen, seen.toList());
    _saveNotices();
  }

  void markNoticeRead(String id) {
    _notices = _notices.map((n) => n.id == id ? n.markRead() : n).toList();
    _saveNotices();
    notifyListeners();
  }

  void markAllNoticesRead() {
    _notices = _notices.map((n) => n.markRead()).toList();
    _saveNotices();
    notifyListeners();
  }

  void clearNotices() {
    _notices = [];
    _saveNotices();
    notifyListeners();
  }

  void addNotice(AppNotice n) {
    _notices.insert(0, n);
    if (_notices.length > 60) _notices = _notices.sublist(0, 60);
    _saveNotices();
    notifyListeners();
  }

  void _saveNotices() => storage.setString(_kNotices, jsonEncode(_notices.map((n) => n.toJson()).toList()));

  // ------------------------------------------------------------ préférences --
  void setThemeMode(ThemeMode m) {
    _themeMode = m;
    storage.setString(_kTheme, m == ThemeMode.light ? 'light' : (m == ThemeMode.dark ? 'dark' : 'system'));
    notifyListeners();
  }

  void completeOnboarding() {
    _onboardingDone = true;
    storage.setBool(_kOnboarding, true);
    if (_notices.isEmpty) {
      addNotice(AppNotice(
        id: 'welcome',
        topic: 'infos',
        title: 'Bienvenue dans l’application CHIFFRE CONSEIL',
        body: 'Outils gratuits, bibliothèque de plus de 50 documents et check-up de votre entreprise : tout est accessible, même hors connexion.',
        date: DateTime.now(),
        route: '/check-up',
      ));
    }
    notifyListeners();
  }

  Future<void> setAnalyticsConsent(bool v) async {
    _consent = v;
    _consentAsked = true;
    await storage.setBool(_kConsent, v);
    await storage.setBool(_kConsentAsked, true);
    await analytics.setConsent(v);
    notifyListeners();
  }

  Future<void> setNotifPref(String topic, bool v) async {
    _notifPrefs[topic] = v;
    await storage.setString(_kNotifPrefs, jsonEncode(_notifPrefs));
    await push.apply(_notifPrefs);
    notifyListeners();
  }

  // ---------------------------------------------------------------- favoris --
  bool isFavorite(String key) => _favorites.contains(key);

  void toggleFavorite(String key) {
    if (!_favorites.remove(key)) _favorites.add(key);
    storage.setList(_kFavorites, _favorites.toList());
    notifyListeners();
  }

  void recordViewed(Article a) {
    _recent.remove(a.slug);
    _recent.insert(0, a.slug);
    if (_recent.length > 15) _recent = _recent.sublist(0, 15);
    storage.setList(_kRecent, _recent);
    analytics.articleRead(a.slug);
  }

  // ------------------------------------------- documents hors ligne (files) --
  Future<File?> _savedFile() async {
    try {
      final dir = await getApplicationSupportDirectory();
      return File('${dir.path}/saved_documents.json');
    } catch (_) {
      return null;
    }
  }

  Future<void> _loadSaved() async {
    try {
      final f = await _savedFile();
      if (f == null || !await f.exists()) return;
      final list = jsonDecode(await f.readAsString()) as List;
      _saved = {
        for (final m in list.whereType<Map>())
          (m['slug'] ?? '').toString(): Article.fromJson(Map<String, dynamic>.from(m)),
      };
    } catch (_) {}
  }

  Future<void> _persistSaved() async {
    final f = await _savedFile();
    await f?.writeAsString(jsonEncode(_saved.values.map((a) => a.toJson()).toList()));
  }

  bool isSaved(String slug) => _saved.containsKey(slug);

  Future<void> saveDocument(Article a) async {
    _saved[a.slug] = a;
    await _persistSaved();
    analytics.documentSaved(a.slug);
    notifyListeners();
  }

  Future<void> removeDocument(String slug) async {
    _saved.remove(slug);
    await _persistSaved();
    notifyListeners();
  }

  // ----------------------------------------------------------------- profil --
  Future<void> updateProfile(UserProfile p) async {
    _profile = p;
    await storage.writeSecure(_sProfile, p.toJson());
    notifyListeners();
  }

  // ------------------------------------------------------------- entreprises --
  String newId(String prefix) => '${prefix}_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(9999)}';

  Company? company(String id) {
    for (final c in _companies) {
      if (c.id == id) return c;
    }
    return null;
  }

  Future<void> upsertCompany(Company c) async {
    final i = _companies.indexWhere((x) => x.id == c.id);
    if (i >= 0) {
      _companies[i] = c;
    } else {
      _companies.add(c);
    }
    await storage.writeSecure(_sCompanies, _companies.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  Future<void> deleteCompany(String id) async {
    _companies.removeWhere((c) => c.id == id);
    await storage.writeSecure(_sCompanies, _companies.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  // ---------------------------------------------------------------- demandes --
  Future<void> addRequest(RequestRecord r) async {
    _requests.insert(0, r);
    await _persistRequests();
    notifyListeners();
  }

  Future<void> _persistRequests() => storage.writeSecure(_sRequests, _requests.map((e) => e.toJson()).toList());

  Future<void> deleteRequest(String id) async {
    _requests.removeWhere((r) => r.id == id);
    await _persistRequests();
    notifyListeners();
  }

  static String formType(RequestKind k) => switch (k) {
        RequestKind.rendezVous => 'Demande de rendez-vous',
        RequestKind.devis => 'Demande de devis',
        RequestKind.contact => 'Demande de contact',
      };

  bool _retrying = false;

  /// Renvoi automatique des demandes enregistrées hors connexion.
  Future<int> retryPending() async {
    if (_retrying) return 0;
    _retrying = true;
    var sent = 0;
    try {
      for (var i = 0; i < _requests.length; i++) {
        final r = _requests[i];
        if (r.status != RequestStatus.pending) continue;
        final res = await api.submitForm(type: formType(r.kind), fields: r.fields, elapsedMs: 15000);
        if (res.ok) {
          _requests[i] = r.copyWith(status: RequestStatus.sent, serverRef: res.reference);
          sent++;
          addNotice(AppNotice(
            id: newId('sent'),
            topic: 'rendez_vous',
            title: 'Demande transmise',
            body: '${r.typeLabel} envoyée au cabinet.',
            date: DateTime.now(),
            route: '/profil/demandes',
          ));
        } else if (res.networkError) {
          break;
        }
      }
      if (sent > 0) {
        await _persistRequests();
        notifyListeners();
      }
    } finally {
      _retrying = false;
    }
    return sent;
  }

  // -------------------------------------------------------- confidentialité --
  Future<void> wipeAllData() async {
    await storage.wipeAll();
    final f = await _savedFile();
    try {
      if (f != null && await f.exists()) await f.delete();
    } catch (_) {}
    _favorites = {};
    _recent = [];
    _saved = {};
    _profile = const UserProfile();
    _companies = [];
    _requests = [];
    _notices = [];
    _consent = false;
    _consentAsked = false;
    _onboardingDone = true;
    await storage.setBool(_kOnboarding, true);
    await analytics.setConsent(false);
    notifyListeners();
  }

  @override
  void dispose() {
    connectivity.removeListener(_onConnectivity);
    super.dispose();
  }
}

/// Accès à l'état depuis l'arbre de widgets.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child}) : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope introuvable');
    return scope!.notifier!;
  }

  /// Lecture sans abonnement aux changements (callbacks, initState).
  static AppState read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    return scope!.notifier!;
  }
}
