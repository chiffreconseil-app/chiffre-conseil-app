import 'package:flutter/material.dart';

/// Icônes professionnelles (Material Symbols) associées aux contenus du site.
class CCIcons {
  CCIcons._();

  static IconData expertise(String slug) => switch (slug) {
        'finance' => Icons.query_stats,
        'fiscalite' => Icons.receipt_long,
        'management' => Icons.account_tree,
        'grh' => Icons.groups,
        'marketing' => Icons.campaign,
        'it-digital' => Icons.devices,
        _ => Icons.insights,
      };

  static IconData tool(String slug) => switch (slug) {
        'simulateur-paie' => Icons.payments,
        'calculateur-irpp' => Icons.percent,
        'retenue-a-la-source' => Icons.request_quote,
        'calculateur-tva' => Icons.calculate,
        'pension-retraite' => Icons.elderly,
        'vignette-2026' => Icons.directions_car,
        'simulateur-credit' => Icons.account_balance,
        'matricule-fiscal' => Icons.verified,
        'investissement' => Icons.trending_up,
        'bfr' => Icons.sync_alt,
        'seuil-rentabilite' => Icons.balance,
        'budget-ecart' => Icons.fact_check,
        'tresorerie' => Icons.waterfall_chart,
        _ => Icons.calculate,
      };

  static IconData category(String c) => switch (c) {
        'Fiscalité' => Icons.receipt_long,
        'GRH & Paie' => Icons.groups,
        'Risk Management' => Icons.shield_outlined,
        'Investissement' => Icons.trending_up,
        'Gestion' => Icons.fact_check,
        'Banque & Financement' => Icons.account_balance,
        'Comptabilité' => Icons.menu_book,
        'Actualités' => Icons.newspaper,
        _ => Icons.query_stats,
      };
}
