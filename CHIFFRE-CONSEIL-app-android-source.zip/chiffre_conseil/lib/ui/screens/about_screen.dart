import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../state/app_state.dart';
import '../cc_icons.dart';
import '../widgets/cc_widgets.dart';

/// Le cabinet : mission, vision, valeurs, parcours client (contenu du site).
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final a = s.content.about;
    return Scaffold(
      appBar: ccAppBar(context, 'Le cabinet'),
      body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(colors: [CC.navy, CC.navySoft]),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Image.asset('assets/images/brand/logo_inverse.png', height: 30),
              const SizedBox(height: 18),
              Text(a.mission, style: const TextStyle(color: CC.white, fontSize: 18, fontWeight: FontWeight.w700, height: 1.4)),
              const SizedBox(height: 14),
              Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: Image.asset('assets/images/brand/houssem.jpg', width: 48, height: 48, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('${a.founded}\nM. Houssem Khammassi, Directeur Général',
                      style: TextStyle(color: CC.white.withValues(alpha: 0.8), fontSize: 12.5, height: 1.45)),
                ),
              ]),
            ]),
          ),
        ),
        const SectionTitle('Notre vision', eyebrow: 'Trois axes complémentaires'),
        for (var i = 0; i < a.vision.length; i++)
          _NumberedTile(n: i + 1, title: a.vision[i][0], text: a.vision[i].length > 1 ? a.vision[i][1] : ''),
        const SectionTitle('Nos valeurs'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: LayoutBuilder(builder: (context, c) {
            final w = (c.maxWidth - 12) / 2;
            return Wrap(spacing: 12, runSpacing: 12, children: [
              for (final v in a.values)
                SizedBox(
                  width: w,
                  child: CCCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(width: 10, height: 10, color: CC.orange),
                      const SizedBox(height: 10),
                      Text(v[0], style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
                      const SizedBox(height: 4),
                      Text(v.length > 1 ? v[1] : '', style: TextStyle(fontSize: 12, height: 1.4, color: context.mutedText)),
                    ]),
                  ),
                ),
            ]);
          }),
        ),
        const SectionTitle('Le parcours client', eyebrow: 'De votre problématique à la solution'),
        for (var i = 0; i < a.journey.length; i++)
          _NumberedTile(n: i + 1, title: a.journey[i][0], text: a.journey[i].length > 1 ? a.journey[i][1] : ''),
        const SectionTitle('Nos expertises'),
        for (final e in s.content.expertises)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: CCCard(
              onTap: () => go(context, '/expertises/${e.slug}'),
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                IconBadge(CCIcons.expertise(e.slug), size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(e.name, style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
                    Text(e.punch, style: TextStyle(fontSize: 12, color: context.mutedText)),
                  ]),
                ),
                Icon(Icons.chevron_right, color: context.mutedText),
              ]),
            ),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: SecondaryButton('Profil LinkedIn de Houssem Khammassi',
              icon: Icons.open_in_new, onPressed: () => openLink(context, s.content.contact.linkedinDirector)),
        ),
      ]),
    );
  }
}

class _NumberedTile extends StatelessWidget {
  const _NumberedTile({required this.n, required this.title, required this.text});
  final int n;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: CCCard(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          Text(n.toString().padLeft(2, '0'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: CC.orange)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
              if (text.isNotEmpty) Text(text, style: TextStyle(fontSize: 12.5, color: context.mutedText, height: 1.4)),
            ]),
          ),
        ]),
      ),
    );
  }
}
