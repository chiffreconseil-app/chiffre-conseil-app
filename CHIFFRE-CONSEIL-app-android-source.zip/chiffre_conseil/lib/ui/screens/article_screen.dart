import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../core/utils/format.dart';
import '../../data/models/content.dart';
import '../../state/app_state.dart';
import '../widgets/article_tile.dart';
import '../widgets/cc_widgets.dart';

/// Lecture native d'un article ou d'une fiche (hors connexion si téléchargé).
class ArticleScreen extends StatefulWidget {
  const ArticleScreen({super.key, required this.slug});
  final String slug;

  @override
  State<ArticleScreen> createState() => _ArticleScreenState();
}

class _ArticleScreenState extends State<ArticleScreen> {
  bool _recorded = false;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final Article? a = s.content.article(widget.slug) ?? (s.isSaved(widget.slug) ? s.savedDocs.firstWhere((d) => d.slug == widget.slug) : null);
    if (a == null) {
      return Scaffold(
        appBar: ccAppBar(context, 'Article'),
        body: EmptyState(
          icon: Icons.article_outlined,
          title: 'Article indisponible',
          message: 'Cet article n’est pas encore dans l’application. Vous pouvez le lire sur le site.',
          action: SecondaryButton('Ouvrir sur chiffreconseil.net',
              expand: false, onPressed: () => openLink(context, 'https://chiffreconseil.net/blog/${widget.slug}/', inApp: true)),
        ),
      );
    }
    if (!_recorded) {
      _recorded = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => s.recordViewed(a));
    }
    final saved = s.isSaved(a.slug);
    final related = s.content.articles.where((x) => x.slug != a.slug && x.category == a.category && x.hasBody).take(3).toList();
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 220,
          backgroundColor: CC.navy,
          foregroundColor: CC.white,
          surfaceTintColor: Colors.transparent,
          actions: [
            FavoriteButton(keyId: 'a:${a.slug}', color: CC.white),
            if (a.hasBody)
              IconButton(
                tooltip: saved ? 'Retirer des téléchargements' : 'Télécharger (hors connexion)',
                icon: Icon(saved ? Icons.download_done : Icons.download),
                onPressed: () async {
                  if (saved) {
                    await s.removeDocument(a.slug);
                  } else {
                    await s.saveDocument(a);
                  }
                  if (context.mounted) showSnack(context, saved ? 'Retiré des téléchargements' : 'Disponible hors connexion');
                },
              ),
            IconButton(
              tooltip: 'Ouvrir sur le site',
              icon: const Icon(Icons.open_in_new),
              onPressed: () => openLink(context, a.url, inApp: true),
            ),
          ],
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(fit: StackFit.expand, children: [
              ArticleImage(thumb: a.thumb, url: a.image, radius: 0),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0x990E1B4D), Color(0x000E1B4D), Color(0xCC0E1B4D)],
                  ),
                ),
              ),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                Pill(a.kindLabel),
                if (a.tag.isNotEmpty) Pill(a.tag, color: context.isDark ? CC.darkCard : const Color(0xFFEEF1F8), textColor: context.strongText),
              ]),
              const SizedBox(height: 12),
              Text(a.title, style: context.tt.headlineSmall?.copyWith(color: context.strongText, height: 1.25)),
              if (a.subtitle.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(a.subtitle, style: TextStyle(fontSize: 16, height: 1.45, color: context.mutedText, fontWeight: FontWeight.w500)),
              ],
              const SizedBox(height: 14),
              Row(children: [
                if (a.author.contains('Houssem'))
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset('assets/images/brand/houssem.jpg', width: 36, height: 36, fit: BoxFit.cover),
                  )
                else
                  const IconBadge(Icons.edit_note, size: 36),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${a.author.isEmpty ? 'CHIFFRE CONSEIL' : (a.author.contains('Houssem') ? 'M. Houssem Khammassi' : a.author)}'
                    '${a.date.isEmpty ? '' : '\nPublié le ${Fmt.isoDate(a.date)}'}',
                    style: TextStyle(fontSize: 12.5, height: 1.4, color: context.mutedText),
                  ),
                ),
              ]),
              const SizedBox(height: 18),
              if (a.shortAnswer.isNotEmpty) _ShortAnswer(text: a.shortAnswer),
              if (!a.hasBody) ...[
                Text(a.description, style: context.tt.bodyLarge),
                const SizedBox(height: 18),
                PrimaryButton('LIRE L’ARTICLE COMPLET', icon: Icons.open_in_new, onPressed: () => openLink(context, a.url, inApp: true)),
              ],
            ]),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate((context, i) => ArticleBlockView(block: a.blocks[i]), childCount: a.blocks.length),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
            child: CCCard(
              color: context.isDark ? CC.darkCard : const Color(0xFFFFF3EE),
              border: false,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Un sujet à traiter dans votre entreprise ?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
                const SizedBox(height: 6),
                Text('Échangez avec le cabinet lors d’un entretien de découverte de 30 minutes, sans engagement.',
                    style: TextStyle(color: context.mutedText, height: 1.45)),
                const SizedBox(height: 14),
                PrimaryButton('PRENDRE RENDEZ-VOUS',
                    icon: Icons.event_available, onPressed: () => go(context, '/rendez-vous', args: {'note': 'Suite à la lecture : « ${a.title} »'})),
              ]),
            ),
          ),
        ),
        if (related.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionTitle('À lire aussi')),
          SliverList(delegate: SliverChildBuilderDelegate((context, i) => ArticleTile(article: related[i], showExcerpt: false), childCount: related.length)),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 40)),
      ]),
    );
  }
}

class _ShortAnswer extends StatelessWidget {
  const _ShortAnswer({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AccentBox(
        background: context.isDark ? CC.darkCard : const Color(0xFFEEF1F8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Eyebrow('Réponse courte'),
          const SizedBox(height: 8),
          RichMarkdownText(text, style: context.tt.bodyLarge?.copyWith(fontWeight: FontWeight.w500)),
        ]),
      ),
    );
  }
}

/// Rendu natif des blocs extraits du site.
class ArticleBlockView extends StatelessWidget {
  const ArticleBlockView({super.key, required this.block});
  final ArticleBlock block;

  @override
  Widget build(BuildContext context) {
    final b = block;
    final body = context.tt.bodyLarge?.copyWith(fontSize: 15.5);
    switch (b.type) {
      case 'h2':
        return Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 8),
          child: Text(b.text, style: context.tt.titleLarge?.copyWith(color: context.strongText, fontSize: 20, height: 1.25)),
        );
      case 'h3':
        return Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 6),
          child: Text(b.text, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16.5, color: context.strongText, height: 1.3)),
        );
      case 'h4':
        return Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: Text(b.text, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: context.accentText)),
        );
      case 'ul':
      case 'ol':
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (var i = 0; i < b.items.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(
                    width: 26,
                    child: b.type == 'ol'
                        ? Text('${i + 1}.', style: TextStyle(fontWeight: FontWeight.w800, color: context.accentText, fontSize: 15))
                        : Padding(
                            padding: const EdgeInsets.only(top: 9),
                            child: Container(width: 7, height: 7, color: CC.orange),
                          ),
                  ),
                  Expanded(child: RichMarkdownText(b.items[i], style: body)),
                ]),
              ),
          ]),
        );
      case 'dl':
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            for (final p in b.rows)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: context.softFill, borderRadius: BorderRadius.circular(12)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.isNotEmpty ? p[0] : '', style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
                  const SizedBox(height: 4),
                  RichMarkdownText(p.length > 1 ? p[1] : '', style: body?.copyWith(fontSize: 14)),
                ]),
              ),
          ]),
        );
      case 'table':
        if (b.rows.isEmpty) return const SizedBox.shrink();
        final cols = b.rows.map((r) => r.length).fold<int>(0, (m, l) => l > m ? l : m);
        if (cols == 0) return const SizedBox.shrink(); // DataTable exige au moins une colonne
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Container(
            decoration: BoxDecoration(border: Border.all(color: context.lineColor), borderRadius: BorderRadius.circular(12)),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowColor: WidgetStatePropertyAll(context.isDark ? CC.darkCard : const Color(0xFFEEF1F8)),
                columnSpacing: 18,
                horizontalMargin: 12,
                dataRowMinHeight: 40,
                dataRowMaxHeight: double.infinity,
                columns: [
                  for (var i = 0; i < cols; i++)
                    DataColumn(
                      label: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 220),
                        child: Text(i < b.rows.first.length ? b.rows.first[i] : '',
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: context.strongText)),
                      ),
                    ),
                ],
                rows: [
                  for (final r in b.rows.skip(1))
                    DataRow(cells: [
                      for (var i = 0; i < cols; i++)
                        DataCell(ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 220),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Text(i < r.length ? r[i] : '', style: TextStyle(fontSize: 13, color: context.strongText, height: 1.35)),
                          ),
                        )),
                    ]),
                ],
              ),
            ),
          ),
        );
      case 'formula':
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: context.isDark ? CC.navySoft : CC.navy,
            borderRadius: BorderRadius.circular(14),
          ),
          child: RichMarkdownText(b.text,
              style: const TextStyle(color: CC.white, fontWeight: FontWeight.w600, fontSize: 14.5, height: 1.5)),
        );
      case 'callout':
      case 'quote':
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: AccentBox(
            background: context.isDark ? CC.darkCard : const Color(0xFFFFF3EE),
            child: RichMarkdownText(b.text, style: body?.copyWith(fontSize: 14.5)),
          ),
        );
      default:
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: RichMarkdownText(b.text, style: body),
        );
    }
  }
}
