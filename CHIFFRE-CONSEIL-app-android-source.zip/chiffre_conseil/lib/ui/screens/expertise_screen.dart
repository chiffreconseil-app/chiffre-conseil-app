import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../features/tools/tool_catalog.dart';
import '../../state/app_state.dart';
import '../cc_icons.dart';
import '../widgets/cc_widgets.dart';

class ExpertiseScreen extends StatelessWidget {
  const ExpertiseScreen({super.key, required this.slug});
  final String slug;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return Scaffold(appBar: ccAppBar(context, 'Expertise'), body: const Center(child: CircularProgressIndicator()));
    final e = s.content.expertise(slug);
    if (e == null) {
      return Scaffold(
        appBar: ccAppBar(context, 'Expertise'),
        body: const EmptyState(icon: Icons.search_off, title: 'Expertise introuvable'),
      );
    }
    final tools = e.tools.map((t) => findTool(s.content, t)).whereType<ToolEntry>().toList();
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 230,
          backgroundColor: CC.navy,
          foregroundColor: CC.white,
          surfaceTintColor: Colors.transparent,
          title: Text(e.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          flexibleSpace: FlexibleSpaceBar(
            collapseMode: CollapseMode.parallax,
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [CC.navySoft, CC.navy, CC.navyDeep], begin: Alignment.topLeft, end: Alignment.bottomRight),
              ),
              padding: const EdgeInsets.fromLTRB(20, 90, 20, 20),
              alignment: Alignment.bottomLeft,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                IconBadge(CCIcons.expertise(e.slug), size: 58, background: CC.white.withValues(alpha: 0.1), color: CC.orangeLight),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(e.punch,
                      style: const TextStyle(color: CC.white, fontSize: 21, fontWeight: FontWeight.w800, height: 1.2)),
                ),
              ]),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Text(e.intro, style: context.tt.bodyLarge),
          ),
        ),
        if (e.pains.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionTitle('Vous reconnaissez-vous ?', eyebrow: 'Situations fréquentes')),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: CCCard(
                child: Column(children: [
                  for (final p in e.pains)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.error_outline, size: 18, color: CC.orangeText),
                        const SizedBox(width: 10),
                        Expanded(child: Text(p, style: TextStyle(color: context.strongText, height: 1.4))),
                      ]),
                    ),
                ]),
              ),
            ),
          ),
        ],
        const SliverToBoxAdapter(child: SectionTitle('Prestations', eyebrow: 'Ce que nous faisons')),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in e.services)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: context.cardColor,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: context.lineColor),
                  ),
                  child: Text(p, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: context.strongText)),
                ),
            ]),
          ),
        ),
        if (e.deliverables.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionTitle('Livrables', eyebrow: 'Ce que vous recevez')),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: CCCard(
                child: Column(children: [
                  for (final d in e.deliverables)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(children: [
                        const Icon(Icons.check_circle, size: 18, color: CC.success),
                        const SizedBox(width: 10),
                        Expanded(child: Text(d, style: TextStyle(color: context.strongText, fontWeight: FontWeight.w600))),
                      ]),
                    ),
                ]),
              ),
            ),
          ),
        ],
        if (tools.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionTitle('Outils associés', eyebrow: 'Gratuits')),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) => Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: CCCard(
                  onTap: () => go(context, '/outils/${tools[i].slug}'),
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    IconBadge(CCIcons.tool(tools[i].slug), size: 40),
                    const SizedBox(width: 12),
                    Expanded(child: Text(tools[i].name, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText))),
                    Text('UTILISER', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: context.accentText)),
                  ]),
                ),
              ),
              childCount: tools.length,
            ),
          ),
        ],
        if (e.prices.isNotEmpty) ...[
          const SliverToBoxAdapter(child: SectionTitle('Tarifs indicatifs 2026', eyebrow: 'Hors taxes — source : chiffreconseil.net/tarifs')),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: CCCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                child: Column(children: [
                  for (var i = 0; i < e.prices.length; i++) _PriceRow(row: e.prices[i], last: i == e.prices.length - 1),
                ]),
              ),
            ),
          ),
        ],
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 26, 16, 40),
            child: Column(children: [
              PrimaryButton('DEMANDER UN DEVIS', icon: Icons.request_quote, onPressed: () => go(context, '/devis', args: {'pole': e.slug})),
              const SizedBox(height: 10),
              SecondaryButton('PRENDRE RENDEZ-VOUS',
                  icon: Icons.event_available, onPressed: () => go(context, '/rendez-vous', args: {'objet': e.name})),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _PriceRow extends StatelessWidget {
  const _PriceRow({required this.row, required this.last});
  final List<String> row;
  final bool last;

  @override
  Widget build(BuildContext context) {
    String at(int i) => i < row.length ? row[i] : '';
    final price = at(4);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: context.lineColor))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(at(1), style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
            const SizedBox(height: 2),
            Text(at(2), style: TextStyle(fontSize: 12, color: context.mutedText, height: 1.35)),
            const SizedBox(height: 2),
            Text('${at(0)} · ${at(3)}', style: TextStyle(fontSize: 11, color: context.mutedText)),
          ]),
        ),
        const SizedBox(width: 10),
        Text(price.contains('devis') ? price : '$price TND',
            style: TextStyle(fontWeight: FontWeight.w800, color: context.accentText, fontSize: 13)),
      ]),
    );
  }
}
