import 'package:flutter/material.dart';

import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../data/models/content.dart';
import '../../features/tools/tool_catalog.dart';
import '../../state/app_state.dart';
import '../widgets/article_tile.dart';
import '../widgets/cc_widgets.dart';
import 'tools_screen.dart';

class _Topic {
  final String id, title, subtitle;
  final IconData icon;
  final List<String> articles, tools;
  final bool Function(ReferenceLink r) refs;
  const _Topic(this.id, this.title, this.subtitle, this.icon, this.articles, this.tools, this.refs);
}

bool _none(ReferenceLink r) => false;

final _topics = <_Topic>[
  _Topic('lf', 'Loi de finances', 'LF 2026 et mesures clés', Icons.gavel, const ['loi-finances-2026-emploi-diplomes'], const ['simulateur-paie'],
      (r) => r.title.toLowerCase().contains('loi de finances')),
  _Topic('agenda', 'Agenda fiscal', 'Échéances et acomptes', Icons.event_note, const ['acomptes-provisionnels-tunisie'], const [],
      (r) => r.title.toLowerCase().contains('agenda')),
  _Topic('notes', 'Notes communes', '17 notes communes 2026', Icons.description, const [], const [],
      (r) => r.title.toLowerCase().startsWith('note commune')),
  _Topic('tva', 'TVA', 'Taux, champ d’application, timbre', Icons.percent, const ['tva-tunisie', 'champ-application-tva'], const ['calculateur-tva'], _none),
  _Topic('impots', 'Impôts', 'IRPP, enregistrement, vignette', Icons.account_balance_wallet,
      const ['bareme-irpp-tunisie', 'frais-enregistrement-immobilier', 'vignette-2026', 'pension-retraite-tunisie'],
      const ['calculateur-irpp', 'vignette-2026', 'pension-retraite'], _none),
  _Topic('obligations', 'Obligations fiscales', 'Retenue à la source, TEJ, matricule', Icons.task_alt,
      const ['retenue-a-la-source-tunisie', 'matricule-fiscal-tunisie', 'acomptes-provisionnels-tunisie'],
      const ['retenue-a-la-source', 'matricule-fiscal'], (r) => r.title.toLowerCase().contains('services en ligne')),
];

class FiscaliteScreen extends StatelessWidget {
  const FiscaliteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final refs = s.content.references;
    final institutions = <String>[];
    for (final r in refs) {
      if (!institutions.contains(r.institution)) institutions.add(r.institution);
    }
    final width = MediaQuery.sizeOf(context).width;
    return Scaffold(
      appBar: ccAppBar(context, 'Fiscalité tunisienne'),
      body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Eyebrow('Fiscalité tunisienne', color: CC.orangeLight),
              const SizedBox(height: 8),
              const Text('L’essentiel pour gérer sereinement vos obligations.',
                  style: TextStyle(color: CC.white, fontSize: 19, fontWeight: FontWeight.w800, height: 1.25)),
              const SizedBox(height: 8),
              Text('Guides du cabinet, simulateurs à jour du barème 2026 et accès direct aux sources officielles.',
                  style: TextStyle(color: CC.white.withValues(alpha: 0.75), fontSize: 12.5, height: 1.45)),
            ]),
          ),
        ),
        const SectionTitle('Accès rapide'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: width >= 700 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.12,
            children: [
              for (final t in _topics)
                CCCard(
                  padding: const EdgeInsets.all(14),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => FiscalTopicScreen(topicId: t.id))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    IconBadge(t.icon, size: 38),
                    const Spacer(),
                    Text(t.title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: context.strongText)),
                    const SizedBox(height: 2),
                    Text(t.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, color: context.mutedText)),
                  ]),
                ),
            ],
          ),
        ),
        const SectionTitle('Ressources officielles', eyebrow: 'Liens externes'),
        for (final inst in institutions) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
            child: Text(inst, style: TextStyle(fontWeight: FontWeight.w800, color: context.accentText)),
          ),
          for (final r in refs.where((r) => r.institution == inst)) OfficialLinkTile(link: r),
        ],
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Disclaimer('Sélection de liens officiels publiée sur chiffreconseil.net/references-publiques. Chiffre Conseil n’est affilié à aucune de ces institutions.'),
        ),
      ]),
    );
  }
}

class OfficialLinkTile extends StatelessWidget {
  const OfficialLinkTile({super.key, required this.link});
  final ReferenceLink link;

  @override
  Widget build(BuildContext context) {
    final host = Uri.tryParse(link.url)?.host ?? '';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: CCCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        onTap: () => openLink(context, link.url),
        child: Row(children: [
          Icon(Icons.link, color: context.mutedText, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(link.title, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
              Text(host, style: TextStyle(fontSize: 11.5, color: context.mutedText)),
            ]),
          ),
          Icon(Icons.open_in_new, size: 18, color: context.accentText),
        ]),
      ),
    );
  }
}

class FiscalTopicScreen extends StatelessWidget {
  const FiscalTopicScreen({super.key, required this.topicId});
  final String topicId;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final t = _topics.firstWhere((x) => x.id == topicId);
    final articles = t.articles.map((slug) => s.content.article(slug)).whereType<Article>().toList();
    final tools = t.tools.map((slug) => findTool(s.content, slug)).whereType<ToolEntry>().toList();
    final refs = s.content.references.where(t.refs).toList();
    return Scaffold(
      appBar: ccAppBar(context, t.title),
      body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
          child: Row(children: [
            IconBadge(t.icon, size: 48),
            const SizedBox(width: 12),
            Expanded(child: Text(t.subtitle, style: TextStyle(color: context.mutedText, fontSize: 15))),
          ]),
        ),
        if (articles.isNotEmpty) ...[
          const SectionTitle('Guides et fiches du cabinet'),
          for (final a in articles) ArticleTile(article: a),
        ],
        if (tools.isNotEmpty) ...[
          const SectionTitle('Simulateurs'),
          for (final x in tools) ToolCard(tool: x),
        ],
        if (refs.isNotEmpty) ...[
          const SectionTitle('Sources officielles'),
          for (final r in refs) OfficialLinkTile(link: r),
        ],
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Disclaimer('Informations de vulgarisation. Seuls les textes officiels font foi ; le cabinet peut vous accompagner pour les appliquer à votre situation.'),
        ),
      ]),
    );
  }
}
