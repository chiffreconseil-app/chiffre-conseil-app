import 'package:flutter/material.dart';

import '../../../app_router.dart';
import '../../../core/config.dart';
import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/validators.dart';
import '../../../data/models/content.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/ui/tool_form.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';
import 'form_kit.dart';

/// CONTACTEZ CHIFFRE CONSEIL
class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final c = s.ready ? s.content.contact : const ContactInfo();
    final actions = <(IconData, String, VoidCallback)>[
      (Icons.call, 'Appeler', () => callPhone(context, c.phone)),
      (Icons.mail_outline, 'Email', () => sendMail(context, c.email, subject: 'Demande d’information — application CHIFFRE CONSEIL')),
      if (AppConfig.whatsapp.isNotEmpty) (Icons.chat, 'WhatsApp', () => openLink(context, 'https://wa.me/${AppConfig.whatsapp}')),
      (Icons.directions, 'Itinéraire', () => openLink(context, c.maps)),
      (Icons.language, 'Site web', () => openLink(context, c.site)),
      (Icons.business_center, 'LinkedIn', () => openLink(context, c.linkedinCabinet)),
    ];
    return Scaffold(
      appBar: ccAppBar(context, 'Contact'),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Eyebrow('Contactez CHIFFRE CONSEIL', color: CC.orangeLight),
            const SizedBox(height: 14),
            Text(c.name, style: const TextStyle(color: CC.white, fontWeight: FontWeight.w800, fontSize: 22)),
            const SizedBox(height: 10),
            for (final l in c.address) Text(l, style: TextStyle(color: CC.white.withValues(alpha: 0.85), fontSize: 15, height: 1.45)),
            const SizedBox(height: 14),
            _InfoLine(icon: Icons.call, text: c.phone),
            _InfoLine(icon: Icons.mail_outline, text: c.email),
            _InfoLine(icon: Icons.language, text: c.site.replaceFirst('https://', '')),
            const SizedBox(height: 6),
            Text(c.director, style: TextStyle(color: CC.white.withValues(alpha: 0.65), fontSize: 12.5)),
          ]),
        ),
        const SizedBox(height: 16),
        LayoutBuilder(builder: (context, box) {
          final cols = box.maxWidth >= 600 ? 6 : 3;
          return GridView.count(
            crossAxisCount: cols,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.9,
            children: [
              for (final a in actions)
                CCCard(
                  padding: const EdgeInsets.all(10),
                  onTap: a.$3,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconBadge(a.$1, size: 42),
                    const SizedBox(height: 8),
                    Text(a.$2, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, color: context.strongText)),
                  ]),
                ),
            ],
          );
        }),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: PrimaryButton('RENDEZ-VOUS', expand: true, onPressed: () => go(context, '/rendez-vous'))),
          const SizedBox(width: 10),
          Expanded(child: SecondaryButton('DEVIS', expand: true, onPressed: () => go(context, '/devis'))),
        ]),
        const SizedBox(height: 22),
        const _QuickMessage(),
      ]),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(children: [
          Icon(icon, size: 17, color: CC.orangeLight),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(color: CC.white, fontWeight: FontWeight.w600))),
        ]),
      );
}

class _QuickMessage extends StatefulWidget {
  const _QuickMessage();

  @override
  State<_QuickMessage> createState() => _QuickMessageState();
}

class _QuickMessageState extends State<_QuickMessage> {
  final _form = GlobalKey<FormState>();
  final _nom = TextEditingController();
  final _mail = TextEditingController();
  final _tel = TextEditingController();
  final _msg = TextEditingController();
  final _opened = DateTime.now();
  bool _consent = false;
  bool _sending = false;
  bool _init = false;
  List<String> _errors = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final p = AppScope.read(context).profile;
    _nom.text = p.fullName;
    _mail.text = p.email;
    _tel.text = p.phone;
  }

  @override
  void dispose() {
    for (final c in [_nom, _mail, _tel, _msg]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _send() async {
    FocusScope.of(context).unfocus();
    final valid = _form.currentState?.validate() ?? false;
    final errs = <String>[if (!_consent) 'Cochez la case d’autorisation pour que nous puissions vous répondre.'];
    setState(() => _errors = errs);
    if (!valid || errs.isNotEmpty) return;
    final s = AppScope.read(context);
    setState(() => _sending = true);
    final res = await submitRequest(
      state: s,
      kind: RequestKind.contact,
      title: 'Message au cabinet',
      summary: _msg.text.trim().length > 80 ? '${_msg.text.trim().substring(0, 80)}…' : _msg.text.trim(),
      openedAt: _opened,
      fields: {'nom': _nom.text, 'email': _mail.text, 'telephone': _tel.text, 'message': _msg.text},
    );
    if (!mounted) return;
    setState(() => _sending = false);
    if (res.outcome == SubmitOutcome.rejected) {
      setState(() => _errors = res.errors);
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => RequestDoneScreen(result: res, message: 'Votre message a bien été envoyé.'),
    ));
    _msg.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: FormCard(children: [
        const FormSectionLabel('Écrire au cabinet'),
        CCField(controller: _nom, label: 'Nom et prénom *', capitalization: TextCapitalization.words, validator: (v) => Validators.required(v, 'Le nom')),
        CCField(controller: _mail, label: 'Email *', keyboard: TextInputType.emailAddress, validator: (v) => Validators.email(v)),
        CCField(controller: _tel, label: 'Téléphone', keyboard: TextInputType.phone, validator: (v) => Validators.phone(v, required: false)),
        CCField(controller: _msg, label: 'Message *', maxLines: 5, validator: (v) => Validators.message(v, min: 1)),
        ConsentBox(value: _consent, onChanged: (v) => setState(() => _consent = v), text: 'J’accepte que mes informations soient utilisées pour traiter ma demande.'),
        ErrorList(_errors),
        PrimaryButton('ENVOYER LE MESSAGE', icon: Icons.send, loading: _sending, onPressed: _send),
        const SizedBox(height: 14),
      ]),
    );
  }
}
