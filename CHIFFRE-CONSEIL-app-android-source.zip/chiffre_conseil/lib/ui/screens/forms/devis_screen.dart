import 'package:flutter/material.dart';

import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/validators.dart';
import '../../../data/models/content.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/ui/tool_form.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';
import 'form_kit.dart';

/// DEMANDER UN DEVIS — connecté au point d'entrée des formulaires du site.
class DevisScreen extends StatefulWidget {
  const DevisScreen({super.key, this.initialPole, this.initialService});
  final String? initialPole;
  final String? initialService;

  @override
  State<DevisScreen> createState() => _DevisScreenState();
}

class _DevisScreenState extends State<DevisScreen> {
  // Listes reprises du formulaire de devis du site
  static const budgets = ['Moins de 1 000 TND', '1 000 à 3 000 TND', '3 000 à 10 000 TND', 'Plus de 10 000 TND', 'À définir ensemble'];
  static const delais = ['Urgent — moins de 15 jours', 'Sous 1 mois', 'Sous 3 mois', 'Pas de date arrêtée'];
  static const nonPrecise = 'Je ne sais pas encore / autre besoin';

  final _form = GlobalKey<FormState>();
  final _nom = TextEditingController();
  final _societe = TextEditingController();
  final _tel = TextEditingController();
  final _mail = TextEditingController();
  final _secteur = TextEditingController();
  final _desc = TextEditingController();
  final _opened = DateTime.now();

  String _pole = '';
  String _presta = nonPrecise;
  String _budget = budgets.last;
  String _delai = delais.last;
  bool _consent = false;
  bool _remember = true;
  bool _sending = false;
  bool _init = false;
  List<String> _errors = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final s = AppScope.read(context);
    final p = s.profile;
    _nom.text = p.fullName;
    _societe.text = p.company;
    _tel.text = p.phone;
    _mail.text = p.email;
    if (s.companies.isNotEmpty && s.companies.first.sector.isNotEmpty) _secteur.text = s.companies.first.sector;
    if (s.ready) {
      final e = widget.initialPole == null ? null : s.content.expertise(widget.initialPole!);
      _pole = e?.slug ?? (s.content.expertises.isNotEmpty ? s.content.expertises.first.slug : '');
      if (widget.initialService != null) _presta = widget.initialService!;
    }
  }

  @override
  void dispose() {
    for (final c in [_nom, _societe, _tel, _mail, _secteur, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  List<String> _prestations(Expertise? e) => [
        nonPrecise,
        if (e != null) for (final t in e.prices) '${t[0]} — ${t[1]}',
      ];

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    final errs = <String>[];
    final valid = _form.currentState?.validate() ?? false;
    if (!_consent) errs.add('Cochez la case d’autorisation pour que nous puissions traiter votre demande.');
    setState(() => _errors = errs);
    if (!valid || errs.isNotEmpty) return;

    final s = AppScope.read(context);
    final e = s.content.expertise(_pole);
    setState(() => _sending = true);
    if (_remember) {
      final parts = _nom.text.trim().split(RegExp(r'\s+'));
      await rememberProfile(s,
          first: parts.isNotEmpty ? parts.first : '',
          last: parts.length > 1 ? parts.sublist(1).join(' ') : '',
          email: _mail.text.trim(),
          phone: _tel.text.trim(),
          company: _societe.text.trim());
    }
    final res = await submitRequest(
      state: s,
      kind: RequestKind.devis,
      title: e?.name ?? 'Demande de devis',
      summary: _presta == nonPrecise ? 'Prestation à définir — budget : $_budget' : '$_presta — budget : $_budget',
      openedAt: _opened,
      fields: {
        'pole': e?.name ?? 'Non précisé',
        'prestation': _presta == nonPrecise ? 'À définir' : _presta,
        'nom': _nom.text,
        'societe': _societe.text,
        'telephone': _tel.text,
        'email': _mail.text,
        'secteur': _secteur.text,
        'budget': _budget,
        'delai': _delai,
        'description': _desc.text,
      },
    );
    if (!mounted) return;
    setState(() => _sending = false);
    if (res.outcome == SubmitOutcome.rejected) {
      setState(() => _errors = res.errors);
      return;
    }
    s.analytics.quoteRequested(e?.slug ?? 'autre');
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
      builder: (_) => RequestDoneScreen(result: res, message: 'Votre demande de devis a bien été transmise.'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final exps = s.content.expertises;
    if (_pole.isEmpty && exps.isNotEmpty) _pole = exps.first.slug;
    final e = s.content.expertise(_pole);
    final prestas = _prestations(e);
    if (!prestas.contains(_presta)) _presta = nonPrecise;
    return Scaffold(
      appBar: ccAppBar(context, 'Demander un devis'),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
            Text('Deux minutes pour décrire votre besoin : le cabinet revient vers vous sous 48 heures ouvrées avec une proposition chiffrée.',
                style: TextStyle(color: context.mutedText, height: 1.45)),
            const SizedBox(height: 16),
            FormCard(children: [
              const FormSectionLabel('Votre besoin'),
              ChoiceInput<String>(
                label: 'Service recherché',
                value: _pole,
                items: [for (final x in exps) (x.slug, x.name)],
                onChanged: (v) => setState(() {
                  _pole = v;
                  _presta = nonPrecise;
                }),
              ),
              ChoiceInput<String>(label: 'Prestation souhaitée', value: _presta, items: [for (final x in prestas) (x, x)], onChanged: (v) => setState(() => _presta = v)),
              FieldRow(children: [
                ChoiceInput<String>(label: 'Budget indicatif', value: _budget, items: [for (final x in budgets) (x, x)], onChanged: (v) => setState(() => _budget = v)),
                ChoiceInput<String>(label: 'Échéance souhaitée', value: _delai, items: [for (final x in delais) (x, x)], onChanged: (v) => setState(() => _delai = v)),
              ]),
              CCField(
                controller: _desc,
                label: 'Description du besoin *',
                maxLines: 6,
                hint: 'Exemple : nous devons présenter un prévisionnel à trois ans à notre banque avant la fin du trimestre.',
                validator: (v) => Validators.message(v, min: 10),
              ),
            ]),
            const SizedBox(height: 14),
            FormCard(children: [
              const FormSectionLabel('Vos coordonnées'),
              CCField(controller: _nom, label: 'Nom et prénom *', capitalization: TextCapitalization.words, autofill: const [AutofillHints.name], validator: (v) => Validators.required(v, 'Le nom')),
              CCField(controller: _societe, label: 'Entreprise', capitalization: TextCapitalization.words, icon: Icons.apartment),
              CCField(controller: _secteur, label: 'Secteur d’activité', hint: 'Industrie, services, commerce…', icon: Icons.category_outlined),
              CCField(controller: _tel, label: 'Téléphone *', keyboard: TextInputType.phone, hint: '+216 …', icon: Icons.call, autofill: const [AutofillHints.telephoneNumber], validator: (v) => Validators.phone(v)),
              CCField(controller: _mail, label: 'Email *', keyboard: TextInputType.emailAddress, icon: Icons.mail_outline, autofill: const [AutofillHints.email], validator: (v) => Validators.email(v)),
            ]),
            const SizedBox(height: 10),
            ConsentBox(
              value: _consent,
              onChanged: (v) => setState(() => _consent = v),
              text: 'J’accepte que mes informations soient utilisées pour traiter ma demande.',
            ),
            ToggleInput(label: 'Mémoriser mes coordonnées sur cet appareil', subtitle: 'Stockage chiffré, jamais partagé', value: _remember, onChanged: (v) => setState(() => _remember = v)),
            const SizedBox(height: 6),
            ErrorList(_errors),
            PrimaryButton('DEMANDER MON DEVIS', icon: Icons.send, loading: _sending, onPressed: _submit),
            const SizedBox(height: 12),
            Text('Tarifs indicatifs consultables dans chaque expertise. Les missions spécifiques font l’objet d’un devis sur mesure.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: context.mutedText, height: 1.45)),
          ]),
        ),
      ),
    );
  }
}
