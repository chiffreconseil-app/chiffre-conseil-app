import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';
import '../../../core/utils/validators.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/ui/tool_form.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';

/// Champ de formulaire stylé et validé.
class CCField extends StatelessWidget {
  const CCField({
    super.key,
    required this.controller,
    required this.label,
    this.validator,
    this.keyboard,
    this.maxLines = 1,
    this.hint,
    this.icon,
    this.capitalization = TextCapitalization.none,
    this.autofill,
    this.maxLength,
  });

  final TextEditingController controller;
  final String label;
  final String? Function(String?)? validator;
  final TextInputType? keyboard;
  final int maxLines;
  final String? hint;
  final IconData? icon;
  final TextCapitalization capitalization;
  final Iterable<String>? autofill;
  final int? maxLength;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboard,
        maxLines: maxLines,
        minLines: maxLines > 1 ? 3 : 1,
        maxLength: maxLength,
        textCapitalization: capitalization,
        autofillHints: autofill,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        inputFormatters: [LengthLimitingTextInputFormatter(maxLength ?? (maxLines > 1 ? 4000 : 200))],
        style: TextStyle(fontWeight: FontWeight.w600, color: context.strongText),
        decoration: toolDecoration(context, label, hint: hint).copyWith(
          prefixIcon: icon == null ? null : Icon(icon, size: 20),
          counterText: '',
          errorMaxLines: 2,
        ),
      ),
    );
  }
}

class ConsentBox extends StatelessWidget {
  const ConsentBox({super.key, required this.value, required this.onChanged, required this.text});
  final bool value;
  final ValueChanged<bool> onChanged;
  final String text;

  @override
  Widget build(BuildContext context) {
    return CheckboxListTile(
      value: value,
      onChanged: (v) => onChanged(v ?? false),
      controlAffinity: ListTileControlAffinity.leading,
      contentPadding: EdgeInsets.zero,
      activeColor: CC.orange,
      title: Text(text, style: TextStyle(fontSize: 12.5, height: 1.4, color: context.mutedText)),
    );
  }
}

class FormSectionLabel extends StatelessWidget {
  const FormSectionLabel(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 12),
        child: Text(text, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
      );
}

class ErrorList extends StatelessWidget {
  const ErrorList(this.errors, {super.key});
  final List<String> errors;

  @override
  Widget build(BuildContext context) {
    if (errors.isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: CC.danger.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final e in errors)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.error_outline, size: 16, color: CC.danger),
              const SizedBox(width: 8),
              Expanded(child: Text(e, style: const TextStyle(color: CC.danger, fontSize: 13))),
            ]),
          ),
      ]),
    );
  }
}

enum SubmitOutcome { sent, queued, rejected }

class SubmitResult {
  final SubmitOutcome outcome;
  final String reference;
  final List<String> errors;
  const SubmitResult(this.outcome, {this.reference = '', this.errors = const []});
}

/// Envoi d'une demande vers le cabinet + historique local + file d'attente
/// hors connexion (renvoi automatique au retour du réseau).
Future<SubmitResult> submitRequest({
  required AppState state,
  required RequestKind kind,
  required String title,
  required String summary,
  required Map<String, String> fields,
  required DateTime openedAt,
  DateTime? appointment,
}) async {
  final clean = <String, String>{
    for (final e in fields.entries)
      if (Validators.clean(e.value).isNotEmpty) e.key: Validators.clean(e.value),
  };
  final elapsed = DateTime.now().difference(openedAt).inMilliseconds;
  final res = await state.api.submitForm(type: AppState.formType(kind), fields: clean, elapsedMs: elapsed < 3000 ? 3000 : elapsed);
  final id = state.newId('req');
  if (res.ok) {
    state.connectivity.reportSuccess();
    await state.addRequest(RequestRecord(
      id: id,
      kind: kind,
      createdAt: DateTime.now(),
      title: title,
      summary: summary,
      status: RequestStatus.sent,
      serverRef: res.reference,
      fields: clean,
      appointment: appointment,
    ));
    return SubmitResult(SubmitOutcome.sent, reference: res.reference);
  }
  if (res.networkError) {
    state.connectivity.reportFailure();
    await state.addRequest(RequestRecord(
      id: id,
      kind: kind,
      createdAt: DateTime.now(),
      title: title,
      summary: summary,
      status: RequestStatus.pending,
      fields: clean,
      appointment: appointment,
    ));
    return const SubmitResult(SubmitOutcome.queued);
  }
  return SubmitResult(SubmitOutcome.rejected, errors: res.errors);
}

/// Mémorise les coordonnées saisies (stockage chiffré) si l'utilisateur le souhaite.
Future<void> rememberProfile(AppState s, {String? first, String? last, String? email, String? phone, String? company}) async {
  final p = s.profile;
  await s.updateProfile(p.copyWith(
    firstName: (first ?? '').isEmpty ? p.firstName : first,
    lastName: (last ?? '').isEmpty ? p.lastName : last,
    email: (email ?? '').isEmpty ? p.email : email,
    phone: (phone ?? '').isEmpty ? p.phone : phone,
    company: (company ?? '').isEmpty ? p.company : company,
  ));
}

/// Écran de confirmation.
class RequestDoneScreen extends StatelessWidget {
  const RequestDoneScreen({super.key, required this.result, required this.message});
  final SubmitResult result;
  final String message;

  @override
  Widget build(BuildContext context) {
    final queued = result.outcome == SubmitOutcome.queued;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.6, end: 1),
                duration: const Duration(milliseconds: 500),
                curve: Curves.elasticOut,
                builder: (context, v, child) => Transform.scale(scale: v, child: child),
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: (queued ? CC.warning : CC.success).withValues(alpha: 0.12)),
                  child: Icon(queued ? Icons.schedule_send : Icons.check_circle, size: 64, color: queued ? CC.warning : CC.success),
                ),
              ),
              const SizedBox(height: 26),
              Text(queued ? 'Demande enregistrée hors connexion' : message,
                  textAlign: TextAlign.center, style: context.tt.headlineSmall?.copyWith(color: context.strongText, fontSize: 22)),
              const SizedBox(height: 12),
              Text(
                queued
                    ? 'Vous êtes actuellement hors connexion. Votre demande sera envoyée automatiquement au cabinet dès le retour du réseau.'
                    : 'Le cabinet revient vers vous sous 48 heures ouvrées. Une confirmation vous est adressée par e-mail.',
                textAlign: TextAlign.center,
                style: TextStyle(color: context.mutedText, height: 1.5),
              ),
              if (result.reference.isNotEmpty) ...[
                const SizedBox(height: 14),
                Pill('Référence : ${result.reference}', icon: Icons.tag),
              ],
              const SizedBox(height: 30),
              PrimaryButton('RETOUR À L’ACCUEIL', icon: Icons.home, onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst)),
              const SizedBox(height: 10),
              SecondaryButton('VOIR MES DEMANDES', icon: Icons.history, onPressed: () {
                final nav = Navigator.of(context);
                nav.popUntil((r) => r.isFirst);
                nav.pushNamed('/profil/demandes');
              }),
            ]),
          ),
        ),
      ),
    );
  }
}

String shortDate(DateTime d) => Fmt.shortDate(d);
