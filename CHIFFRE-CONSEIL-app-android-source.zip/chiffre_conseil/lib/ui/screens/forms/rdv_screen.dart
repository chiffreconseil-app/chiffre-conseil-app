import 'package:flutter/material.dart';

import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';
import '../../../core/utils/validators.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/ui/tool_form.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';
import 'form_kit.dart';

/// PRENDRE RENDEZ-VOUS — même traitement que le formulaire du site.
class RdvScreen extends StatefulWidget {
  const RdvScreen({super.key, this.initialSubject, this.note});
  final String? initialSubject;
  final String? note;

  @override
  State<RdvScreen> createState() => _RdvScreenState();
}

class _RdvScreenState extends State<RdvScreen> {
  static const creneaux = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00'];
  static const durees = ['30 minutes — entretien de découverte (gratuit)', '60 minutes — consultation approfondie'];
  static const formats = ['Visioconférence', 'Téléphone', 'Au cabinet'];

  final _form = GlobalKey<FormState>();
  final _nom = TextEditingController();
  final _prenom = TextEditingController();
  final _tel = TextEditingController();
  final _mail = TextEditingController();
  final _societe = TextEditingController();
  final _message = TextEditingController();
  final _opened = DateTime.now();

  String _objet = '';
  String _duree = durees.first;
  String _format = formats.first;
  DateTime? _date;
  String? _heure;
  bool _consent = false;
  bool _remember = true;
  bool _sending = false;
  List<String> _errors = [];
  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final s = AppScope.read(context);
    final p = s.profile;
    _nom.text = p.lastName;
    _prenom.text = p.firstName;
    _tel.text = p.phone;
    _mail.text = p.email;
    _societe.text = p.company;
    _message.text = widget.note ?? '';
    final subjects = _subjects(s);
    _objet = (widget.initialSubject != null && subjects.contains(widget.initialSubject)) ? widget.initialSubject! : subjects.first;
  }

  List<String> _subjects(AppState s) => [
        ...(s.ready ? s.content.expertises.map((e) => e.name) : const <String>[]),
        'Diagnostic personnalisé (check-up)',
        'Autre sujet',
      ];

  @override
  void dispose() {
    for (final c in [_nom, _prenom, _tel, _mail, _societe, _message]) {
      c.dispose();
    }
    super.dispose();
  }

  DateTime _nextWorkingDay(DateTime d) {
    var x = d;
    while (x.weekday == DateTime.saturday || x.weekday == DateTime.sunday) {
      x = x.add(const Duration(days: 1));
    }
    return x;
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final first = _nextWorkingDay(DateTime(now.year, now.month, now.day).add(const Duration(days: 1)));
    final picked = await showDatePicker(
      context: context,
      initialDate: _date ?? first,
      firstDate: first,
      lastDate: first.add(const Duration(days: 90)),
      selectableDayPredicate: (d) => d.weekday != DateTime.saturday && d.weekday != DateTime.sunday,
      helpText: 'Date souhaitée',
      cancelText: 'Annuler',
      confirmText: 'Valider',
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    final errs = <String>[];
    final valid = _form.currentState?.validate() ?? false;
    if (_date == null) errs.add('Choisissez une date souhaitée.');
    if (_heure == null) errs.add('Choisissez une heure souhaitée.');
    if (!_consent) errs.add('Cochez la case d’autorisation pour que nous puissions organiser ce rendez-vous.');
    setState(() => _errors = errs);
    if (!valid || errs.isNotEmpty) return;

    final s = AppScope.read(context);
    setState(() => _sending = true);
    if (_remember) {
      await rememberProfile(s, first: _prenom.text.trim(), last: _nom.text.trim(), email: _mail.text.trim(), phone: _tel.text.trim(), company: _societe.text.trim());
    }
    final quand = Fmt.dateLong(_date!);
    final res = await submitRequest(
      state: s,
      kind: RequestKind.rendezVous,
      title: _objet,
      summary: '$quand à $_heure — $_format',
      appointment: DateTime(_date!.year, _date!.month, _date!.day, int.parse(_heure!.substring(0, 2))),
      openedAt: _opened,
      fields: {
        'dateSouhaitee': quand,
        'creneau': _heure!,
        'format': _format,
        'duree': _duree,
        'objet': _objet,
        'nom': _nom.text,
        'prenom': _prenom.text,
        'societe': _societe.text,
        'email': _mail.text,
        'telephone': _tel.text,
        'message': _message.text,
      },
    );
    if (!mounted) return;
    setState(() => _sending = false);
    if (res.outcome == SubmitOutcome.rejected) {
      setState(() => _errors = res.errors);
      return;
    }
    s.analytics.appointmentRequested(_objet);
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
      builder: (_) => RequestDoneScreen(result: res, message: 'Votre demande de rendez-vous a bien été enregistrée.'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final subjects = _subjects(s);
    if (!subjects.contains(_objet)) _objet = subjects.first;
    return Scaffold(
      appBar: ccAppBar(context, 'Prendre rendez-vous'),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
            Text('Premier entretien de découverte de 30 minutes, sans engagement, ou consultation approfondie d’une heure.',
                style: TextStyle(color: context.mutedText, height: 1.45)),
            const SizedBox(height: 16),
            FormCard(children: [
              const FormSectionLabel('Votre rendez-vous'),
              ChoiceInput<String>(label: 'Objet', value: _objet, items: [for (final x in subjects) (x, x)], onChanged: (v) => setState(() => _objet = v)),
              ChoiceInput<String>(label: 'Type de consultation', value: _duree, items: [for (final x in durees) (x, x)], onChanged: (v) => setState(() => _duree = v)),
              ChoiceInput<String>(label: 'Format', value: _format, items: [for (final x in formats) (x, x)], onChanged: (v) => setState(() => _format = v)),
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: _pickDate,
                  child: InputDecorator(
                    decoration: toolDecoration(context, 'Date souhaitée').copyWith(prefixIcon: const Icon(Icons.event, size: 20)),
                    child: Text(_date == null ? 'Choisir une date (jours ouvrés)' : Fmt.dateLong(_date!),
                        style: TextStyle(fontWeight: FontWeight.w700, color: _date == null ? context.mutedText : context.strongText)),
                  ),
                ),
              ),
              Text('Heure souhaitée', style: TextStyle(fontWeight: FontWeight.w600, color: context.mutedText)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final h in creneaux)
                  ChoiceChip(
                    label: Text(h),
                    selected: _heure == h,
                    selectedColor: CC.orange.withValues(alpha: 0.18),
                    onSelected: (_) => setState(() => _heure = h),
                  ),
              ]),
              const SizedBox(height: 16),
            ]),
            const SizedBox(height: 14),
            FormCard(children: [
              const FormSectionLabel('Vos coordonnées'),
              FieldRow(children: [
                CCField(controller: _nom, label: 'Nom *', capitalization: TextCapitalization.words, autofill: const [AutofillHints.familyName], validator: (v) => Validators.required(v, 'Le nom')),
                CCField(controller: _prenom, label: 'Prénom *', capitalization: TextCapitalization.words, autofill: const [AutofillHints.givenName], validator: (v) => Validators.required(v, 'Le prénom')),
              ]),
              CCField(controller: _tel, label: 'Téléphone *', keyboard: TextInputType.phone, hint: '+216 …', icon: Icons.call, autofill: const [AutofillHints.telephoneNumber], validator: (v) => Validators.phone(v)),
              CCField(controller: _mail, label: 'Email *', keyboard: TextInputType.emailAddress, icon: Icons.mail_outline, autofill: const [AutofillHints.email], validator: (v) => Validators.email(v)),
              CCField(controller: _societe, label: 'Entreprise', capitalization: TextCapitalization.words, icon: Icons.apartment),
              CCField(controller: _message, label: 'Message', maxLines: 5, hint: 'Quelques mots sur votre besoin', validator: (v) => Validators.message(v)),
            ]),
            const SizedBox(height: 10),
            ConsentBox(
              value: _consent,
              onChanged: (v) => setState(() => _consent = v),
              text: 'J’accepte que mes informations soient utilisées pour organiser ce rendez-vous.',
            ),
            ToggleInput(label: 'Mémoriser mes coordonnées sur cet appareil', subtitle: 'Stockage chiffré, jamais partagé', value: _remember, onChanged: (v) => setState(() => _remember = v)),
            const SizedBox(height: 6),
            ErrorList(_errors),
            PrimaryButton('CONFIRMER MA DEMANDE', icon: Icons.check, loading: _sending, onPressed: _submit),
            const SizedBox(height: 12),
            Text('Vous recevrez une confirmation par e-mail. Hors connexion, la demande est conservée et envoyée automatiquement dès le retour du réseau.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: context.mutedText, height: 1.45)),
          ]),
        ),
      ),
    );
  }
}
