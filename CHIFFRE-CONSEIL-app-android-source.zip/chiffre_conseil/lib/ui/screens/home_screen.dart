import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/config.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../data/models/content.dart';
import '../../data/models/user_data.dart';
import '../../features/tools/tool_catalog.dart';
import '../../state/app_state.dart';
import '../cc_icons.dart';
import '../widgets/article_tile.dart';
import '../widgets/cc_widgets.dart';
import 'shell.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final c = s.content;
    final width = MediaQuery.sizeOf(context).width;
    final cols = width >= 900 ? 3 : 2;
    return Scaffold(
      body: RefreshIndicator(
        color: CC.orange,
        onRefresh: s.refreshContent,
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: _Hero()),
            const SliverToBoxAdapter(
              child: SectionTitle('Nos expertises', eyebrow: 'Cabinet de conseil multidisciplinaire'),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: cols,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  mainAxisExtent: 172,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) => _ExpertiseCard(e: c.expertises[i]),
                  childCount: c.expertises.length,
                ),
              ),
            ),
            SliverToBoxAdapter(child: _CompanyCard(company: s.companies.isEmpty ? null : s.companies.first)),
            const SliverToBoxAdapter(child: _CheckupCard()),
            SliverToBoxAdapter(
              child: SectionTitle('Outils CHIFFRE CONSEIL',
                  eyebrow: 'Simulateurs gratuits',
                  actionLabel: 'Tout voir',
                  onAction: () => ShellScope.maybeOf(context)?.goTab(1)),
            ),
            SliverToBoxAdapter(child: _ToolsStrip(tools: allTools(c))),
            const SliverToBoxAdapter(child: _FiscalBanner()),
            SliverToBoxAdapter(
              child: SectionTitle('Actualités & conseils',
                  eyebrow: 'Derniers articles', actionLabel: 'Tout voir', onAction: () => ShellScope.maybeOf(context)?.goTab(3)),
            ),
            if (s.refreshing && c.articles.isEmpty)
              SliverList(delegate: SliverChildListDelegate(List.generate(3, (_) => const ArticleSkeleton())))
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, i) => ArticleTile(article: c.articles[i]),
                  childCount: c.articles.length < 4 ? c.articles.length : 4,
                ),
              ),
            SliverToBoxAdapter(child: _AboutCard(about: c.about)),
            const SliverToBoxAdapter(child: _Footer()),
          ],
        ),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  const _Hero();

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [CC.navySoft, CC.navy, CC.navyDeep]),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Stack(children: [
        Positioned(
          right: -70,
          top: 40,
          child: Opacity(opacity: 0.07, child: Image.asset('assets/images/brand/symbol_inverse.png', width: 260, color: CC.white)),
        ),
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 12, 26),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Image.asset('assets/images/brand/logo_inverse.png', height: 32, semanticLabel: 'CHIFFRE CONSEIL'),
                const Spacer(),
                IconButton(
                  tooltip: 'Notifications',
                  onPressed: () => go(context, '/notifications'),
                  icon: Badge(
                    isLabelVisible: s.unreadNotices > 0,
                    label: Text('${s.unreadNotices}'),
                    child: const Icon(Icons.notifications_none, color: CC.white),
                  ),
                ),
              ]),
              const SizedBox(height: 26),
              const Eyebrow(AppConfig.slogan, color: CC.orangeLight),
              const SizedBox(height: 10),
              const Text(AppConfig.tagline,
                  style: TextStyle(color: CC.white, fontSize: 27, fontWeight: FontWeight.w800, height: 1.18, letterSpacing: -0.4)),
              const SizedBox(height: 12),
              Text('Finance, fiscalité, gestion, GRH, management et marketing : un cabinet de conseil multidisciplinaire pour les entrepreneurs, dirigeants et entreprises en Tunisie.',
                  style: TextStyle(color: CC.white.withValues(alpha: 0.78), fontSize: 14, height: 1.5)),
              const SizedBox(height: 22),
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: LayoutBuilder(builder: (context, c) {
                  final wide = c.maxWidth > 520;
                  final b1 = PrimaryButton('PRENDRE RENDEZ-VOUS', icon: Icons.event_available, onPressed: () => go(context, '/rendez-vous'));
                  final b2 = SecondaryButton('DEMANDER UN DEVIS', icon: Icons.request_quote, onDark: true, onPressed: () => go(context, '/devis'));
                  return wide
                      ? Row(children: [Expanded(child: b1), const SizedBox(width: 12), Expanded(child: b2)])
                      : Column(children: [b1, const SizedBox(height: 10), b2]);
                }),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _ExpertiseCard extends StatelessWidget {
  const _ExpertiseCard({required this.e});
  final Expertise e;

  @override
  Widget build(BuildContext context) {
    return CCCard(
      onTap: () => go(context, '/expertises/${e.slug}'),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        IconBadge(CCIcons.expertise(e.slug), size: 40),
        const SizedBox(height: 10),
        Text(e.name, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, height: 1.25, color: context.strongText)),
        const SizedBox(height: 4),
        Expanded(
          child: Text(e.punch, maxLines: 3, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, height: 1.35, color: context.mutedText)),
        ),
        Row(children: [
          Text('Découvrir', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: context.accentText)),
          const SizedBox(width: 3),
          Icon(Icons.arrow_forward, size: 13, color: context.accentText),
        ]),
      ]),
    );
  }
}

class _CompanyCard extends StatelessWidget {
  const _CompanyCard({required this.company});
  final Company? company;

  @override
  Widget build(BuildContext context) {
    final ck = company?.checkup;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => go(context, '/mon-entreprise'),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
            ),
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Eyebrow('Mon entreprise', color: CC.orangeLight),
                  const SizedBox(height: 8),
                  Text(
                    ck != null
                        ? 'Votre entreprise possède un potentiel d’amélioration de ${(100 - ck.global).round()} %.'
                        : (company == null ? 'Créez gratuitement le profil de votre entreprise.' : 'Complétez le check-up de ${company!.name}.'),
                    style: const TextStyle(color: CC.white, fontWeight: FontWeight.w800, fontSize: 16, height: 1.3),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    ck != null ? 'Score de pilotage ${ck.global.round()} / 100 — ${company!.name}' : 'Score de pilotage par domaine et tableau de bord simplifié.',
                    style: TextStyle(color: CC.white.withValues(alpha: 0.75), fontSize: 12.5),
                  ),
                  const SizedBox(height: 12),
                  Text(ck != null ? 'VOIR MON DIAGNOSTIC  →' : 'COMMENCER  →',
                      style: const TextStyle(color: CC.orangeLight, fontWeight: FontWeight.w800, fontSize: 12.5, letterSpacing: 0.6)),
                ]),
              ),
              const SizedBox(width: 12),
              if (ck != null)
                ScoreRingOnDark(value: ck.global)
              else
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: CC.white.withValues(alpha: 0.08)),
                  child: const Icon(Icons.apartment, color: CC.orangeLight, size: 34),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Anneau de score lisible sur fond Bleu Nuit.
class ScoreRingOnDark extends StatelessWidget {
  const ScoreRingOnDark({super.key, required this.value});
  final double value;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(brightness: Brightness.dark),
      child: SizedBox(
        width: 82,
        height: 82,
        child: Stack(alignment: Alignment.center, children: [
          SizedBox(
            width: 82,
            height: 82,
            child: CircularProgressIndicator(
              value: (value / 100).clamp(0.0, 1.0),
              strokeWidth: 7,
              backgroundColor: CC.white.withValues(alpha: 0.12),
              valueColor: AlwaysStoppedAnimation<Color>(CC.score(value)),
            ),
          ),
          Text('${value.round()}', style: const TextStyle(color: CC.white, fontWeight: FontWeight.w800, fontSize: 22)),
        ]),
      ),
    );
  }
}

class _CheckupCard extends StatelessWidget {
  const _CheckupCard();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: CCCard(
        onTap: () => go(context, '/check-up'),
        child: Row(children: [
          const IconBadge(Icons.health_and_safety, size: 50, background: Color(0xFFFFE9DF), color: CC.orangeText),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Eyebrow('Check-up CHIFFRE CONSEIL'),
              const SizedBox(height: 4),
              Text('Votre entreprise est-elle bien pilotée ?',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: context.strongText)),
              const SizedBox(height: 3),
              Text('21 questions, 7 domaines, score global sur 100.', style: TextStyle(fontSize: 12.5, color: context.mutedText)),
            ]),
          ),
          Icon(Icons.chevron_right, color: context.mutedText),
        ]),
      ),
    );
  }
}

class _ToolsStrip extends StatelessWidget {
  const _ToolsStrip({required this.tools});
  final List<ToolEntry> tools;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 148,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: tools.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final t = tools[i];
          return SizedBox(
            width: 150,
            child: CCCard(
              onTap: () => go(context, '/outils/${t.slug}'),
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                IconBadge(CCIcons.tool(t.slug), size: 38),
                const Spacer(),
                Text(t.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, height: 1.25, color: context.strongText)),
                const SizedBox(height: 4),
                Text(t.short, style: TextStyle(fontSize: 11.5, color: context.mutedText)),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _FiscalBanner extends StatelessWidget {
  const _FiscalBanner();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: CCCard(
        onTap: () => go(context, '/fiscalite'),
        color: context.isDark ? CC.darkCard : const Color(0xFFFFF3EE),
        border: false,
        child: Row(children: [
          const IconBadge(Icons.account_balance, background: CC.orange, color: CC.white),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Fiscalité tunisienne', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: context.strongText)),
              const SizedBox(height: 3),
              Text('Loi de finances 2026, agenda fiscal, notes communes, TVA, impôts et sources officielles.',
                  style: TextStyle(fontSize: 12.5, height: 1.4, color: context.mutedText)),
            ]),
          ),
          Icon(Icons.chevron_right, color: context.mutedText),
        ]),
      ),
    );
  }
}

class _AboutCard extends StatelessWidget {
  const _AboutCard({required this.about});
  final AboutInfo about;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 0),
      child: CCCard(
        onTap: () => go(context, '/a-propos'),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(40),
            child: Image.asset('assets/images/brand/houssem.jpg', width: 64, height: 64, fit: BoxFit.cover),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Eyebrow('Le cabinet'),
              const SizedBox(height: 4),
              Text(about.founded, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText, height: 1.35)),
              const SizedBox(height: 3),
              Text('Vision, valeurs et parcours client', style: TextStyle(fontSize: 12.5, color: context.mutedText)),
            ]),
          ),
          Icon(Icons.chevron_right, color: context.mutedText),
        ]),
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 110),
      child: Column(children: [
        Image.asset(context.isDark ? 'assets/images/brand/logo_inverse.png' : 'assets/images/brand/logo_color.png', height: 30),
        const SizedBox(height: 10),
        Text('Avenue Hedi Nouira, Ennasr 2, Ariana, Tunisie', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: context.mutedText)),
        const SizedBox(height: 2),
        Text('chiffreconseil.net', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: context.strongText)),
      ]),
    );
  }
}
