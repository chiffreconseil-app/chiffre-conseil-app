import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../data/models/content.dart';
import '../../state/app_state.dart';
import '../cc_icons.dart';
import '../widgets/cc_widgets.dart';
import 'tools_screen.dart';

/// Bibliothèque : fiches et guides pratiques du site, consultables et
/// téléchargeables (lecture hors connexion).
class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, this.standalone = false});
  final bool standalone;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _q = '';
  String _cat = 'Tous';
  String _kind = 'all';

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final docs = s.content.articles.where((a) => a.hasBody).toList()..sort((a, b) => a.title.compareTo(b.title));
    final catList = {for (final a in docs) a.category}.toList()..sort();
    final cats = <String>['Tous', ...catList];
    final filtered = docs.where((a) {
      if (_cat != 'Tous' && a.category != _cat) return false;
      if (_kind != 'all' && a.kind != _kind) return false;
      if (_q.isNotEmpty && !a.searchText.contains(_q)) return false;
      return true;
    }).toList();
    final count = docs.length;
    return Scaffold(
      appBar: ccAppBar(context, 'Bibliothèque'),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(colors: [CC.navy, CC.navySoft], begin: Alignment.topLeft, end: Alignment.bottomRight),
              ),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Eyebrow('Bibliothèque CHIFFRE CONSEIL', color: CC.orangeLight),
                    const SizedBox(height: 8),
                    Text(count >= 50 ? '+50 documents explicatifs' : '$count documents explicatifs',
                        style: const TextStyle(color: CC.white, fontSize: 21, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('Fiches de Houssem Khammassi et guides pratiques du cabinet, à consulter ou télécharger pour une lecture hors connexion.',
                        style: TextStyle(color: CC.white.withValues(alpha: 0.75), fontSize: 12.5, height: 1.45)),
                  ]),
                ),
                const SizedBox(width: 10),
                Text('$count', style: const TextStyle(color: CC.orangeLight, fontSize: 38, fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(children: [
              Expanded(
                child: _QuickBox(
                  icon: Icons.account_balance,
                  title: 'Fiscalité tunisienne',
                  subtitle: 'Sources officielles',
                  onTap: () => go(context, '/fiscalite'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _QuickBox(
                  icon: Icons.download_done,
                  title: 'Mes documents',
                  subtitle: '${s.savedDocs.length} téléchargé(s)',
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SavedDocumentsScreen())),
                ),
              ),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
            child: SearchField(hint: 'Rechercher un document', onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 48,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), children: [
              for (final k in const [('all', 'Tous les formats'), ('publication', 'Fiches'), ('guide', 'Guides pratiques')])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(k.$2),
                    selected: _kind == k.$1,
                    onSelected: (_) => setState(() => _kind = k.$1),
                  ),
                ),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 48,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), children: [
              for (final c in cats)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    avatar: c == 'Tous' ? null : Icon(CCIcons.category(c), size: 16),
                    label: Text(c),
                    selected: _cat == c,
                    onSelected: (_) => setState(() => _cat = c),
                  ),
                ),
            ]),
          ),
        ),
        if (filtered.isEmpty)
          const SliverToBoxAdapter(child: EmptyState(icon: Icons.search_off, title: 'Aucun document trouvé', message: 'Modifiez la recherche ou les filtres.'))
        else
          SliverList(
            delegate: SliverChildBuilderDelegate((context, i) => DocumentTile(doc: filtered[i]), childCount: filtered.length),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 110)),
      ]),
    );
  }
}

class _QuickBox extends StatelessWidget {
  const _QuickBox({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return CCCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      child: Row(children: [
        IconBadge(icon, size: 36),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: context.strongText)),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, color: context.mutedText)),
          ]),
        ),
      ]),
    );
  }
}

class DocumentTile extends StatelessWidget {
  const DocumentTile({super.key, required this.doc});
  final Article doc;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final saved = s.isSaved(doc.slug);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: CCCard(
        onTap: () => go(context, '/blog/${doc.slug}'),
        padding: const EdgeInsets.fromLTRB(14, 14, 10, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconBadge(CCIcons.category(doc.category), size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${doc.kindLabel.toUpperCase()} · ${doc.category.toUpperCase()}',
                    style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: context.accentText)),
                const SizedBox(height: 4),
                Text(doc.title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5, height: 1.3, color: context.strongText)),
                if (doc.subtitle.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(doc.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, color: context.mutedText, height: 1.35)),
                ],
              ]),
            ),
          ]),
          const SizedBox(height: 6),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            TextButton.icon(
              onPressed: () => go(context, '/blog/${doc.slug}'),
              icon: const Icon(Icons.visibility_outlined, size: 18),
              label: const Text('CONSULTER', style: TextStyle(fontWeight: FontWeight.w800)),
              style: TextButton.styleFrom(foregroundColor: context.strongText),
            ),
            TextButton.icon(
              onPressed: () async {
                if (saved) {
                  await s.removeDocument(doc.slug);
                  if (context.mounted) showSnack(context, 'Document retiré de vos téléchargements');
                } else {
                  await s.saveDocument(doc);
                  if (context.mounted) showSnack(context, 'Document téléchargé : disponible hors connexion');
                }
              },
              icon: Icon(saved ? Icons.download_done : Icons.download, size: 18),
              label: Text(saved ? 'TÉLÉCHARGÉ' : 'TÉLÉCHARGER', style: const TextStyle(fontWeight: FontWeight.w800)),
              style: TextButton.styleFrom(foregroundColor: saved ? CC.success : context.accentText),
            ),
          ]),
        ]),
      ),
    );
  }
}

class SavedDocumentsScreen extends StatelessWidget {
  const SavedDocumentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final docs = s.savedDocs;
    return Scaffold(
      appBar: ccAppBar(context, 'Documents téléchargés'),
      body: docs.isEmpty
          ? const Center(
              child: EmptyState(
                icon: Icons.download,
                title: 'Aucun document téléchargé',
                message: 'Dans la bibliothèque, touchez « Télécharger » pour lire un document hors connexion.',
              ),
            )
          : ListView(padding: const EdgeInsets.only(top: 4, bottom: 40), children: [for (final d in docs) DocumentTile(doc: d)]),
    );
  }
}
