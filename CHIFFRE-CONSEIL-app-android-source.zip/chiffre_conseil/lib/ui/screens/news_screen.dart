import 'package:flutter/material.dart';

import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../state/app_state.dart';
import '../widgets/article_tile.dart';
import '../widgets/cc_widgets.dart';
import 'tools_screen.dart';

/// Actualités & conseils : articles publiés sur chiffreconseil.net.
class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key, this.standalone = false});
  final bool standalone;

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  String _q = '';
  String _section = 'Toutes';

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) {
      return Scaffold(
        appBar: ccAppBar(context, 'Actualités & conseils'),
        body: ListView(children: List.generate(6, (_) => const ArticleSkeleton())),
      );
    }
    final all = s.content.articles;
    final secList = {for (final a in all) a.category}.toList()..sort();
    final sections = <String>['Toutes', ...secList];
    final list = all.where((a) {
      if (_section != 'Toutes' && a.category != _section) return false;
      if (_q.isNotEmpty && !a.searchText.contains(_q)) return false;
      return true;
    }).toList();
    return Scaffold(
      appBar: ccAppBar(context, 'Actualités & conseils', actions: [
        IconButton(
          tooltip: 'Actualiser',
          onPressed: s.refreshing ? null : s.refreshContent,
          icon: s.refreshing
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.refresh),
        ),
      ]),
      body: RefreshIndicator(
        color: CC.orange,
        onRefresh: s.refreshContent,
        child: CustomScrollView(physics: const AlwaysScrollableScrollPhysics(), slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
              child: SearchField(hint: 'Rechercher un article', onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 50,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7), children: [
                for (final c in sections)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(label: Text(c), selected: _section == c, onSelected: (_) => setState(() => _section = c)),
                  ),
              ]),
            ),
          ),
          if (s.refreshing)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                child: Text('Actualisation depuis chiffreconseil.net…', style: TextStyle(fontSize: 12, color: context.mutedText)),
              ),
            ),
          if (list.isEmpty)
            const SliverToBoxAdapter(
              child: EmptyState(icon: Icons.search_off, title: 'Aucun article trouvé', message: 'Essayez un autre mot-clé ou une autre catégorie.'),
            )
          else
            SliverList(delegate: SliverChildBuilderDelegate((context, i) => ArticleTile(article: list[i]), childCount: list.length)),
          const SliverToBoxAdapter(child: SizedBox(height: 110)),
        ]),
      ),
    );
  }
}
