import 'package:flutter/material.dart';

import '../../../app_router.dart';
import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';
import 'settings_screen.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  IconData _icon(String topic) => switch (topic) {
        'fiscalite' => Icons.receipt_long,
        'ressources' => Icons.library_books,
        'outils' => Icons.calculate,
        'rendez_vous' => Icons.event_available,
        'infos' => Icons.campaign,
        _ => Icons.article_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final list = s.notices;
    return Scaffold(
      appBar: ccAppBar(context, 'Notifications', actions: [
        if (s.unreadNotices > 0)
          IconButton(tooltip: 'Tout marquer comme lu', icon: const Icon(Icons.done_all), onPressed: s.markAllNoticesRead),
        IconButton(
          tooltip: 'Préférences',
          icon: const Icon(Icons.tune),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
        ),
      ]),
      body: list.isEmpty
          ? Center(
              child: EmptyState(
                icon: Icons.notifications_none,
                title: 'Aucune notification',
                message: 'Nouveaux articles, ressources, actualités fiscales et suivi de vos demandes apparaîtront ici.',
                action: SecondaryButton('Choisir mes thèmes',
                    expand: false,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen()))),
              ),
            )
          : ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
              for (final n in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: CCCard(
                    color: n.read ? null : (context.isDark ? CC.darkCard : const Color(0xFFFFF6F2)),
                    onTap: () {
                      s.markNoticeRead(n.id);
                      if (n.route.isNotEmpty) go(context, n.route);
                    },
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      IconBadge(_icon(n.topic), size: 40),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('CHIFFRE CONSEIL · ${Fmt.shortDate(n.date)}', style: TextStyle(fontSize: 11, color: context.mutedText)),
                          const SizedBox(height: 3),
                          Text(n.title, style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
                          const SizedBox(height: 2),
                          Text(n.body, style: TextStyle(fontSize: 13, color: context.mutedText, height: 1.4)),
                        ]),
                      ),
                      if (!n.read) Container(width: 9, height: 9, margin: const EdgeInsets.only(top: 6), decoration: const BoxDecoration(color: CC.orange, shape: BoxShape.circle)),
                    ]),
                  ),
                ),
              TextButton(onPressed: s.clearNotices, child: const Text('Effacer les notifications')),
            ]),
    );
  }
}
