import 'package:flutter/material.dart';

import '../../../core/utils/validators.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/ui/tool_form.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';
import '../forms/form_kit.dart';

class ProfileEditScreen extends StatefulWidget {
  const ProfileEditScreen({super.key});

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final _form = GlobalKey<FormState>();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _mail = TextEditingController();
  final _tel = TextEditingController();
  final _co = TextEditingController();
  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_init) return;
    _init = true;
    final p = AppScope.read(context).profile;
    _first.text = p.firstName;
    _last.text = p.lastName;
    _mail.text = p.email;
    _tel.text = p.phone;
    _co.text = p.company;
  }

  @override
  void dispose() {
    for (final c in [_first, _last, _mail, _tel, _co]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!(_form.currentState?.validate() ?? false)) return;
    final s = AppScope.read(context);
    await s.updateProfile(UserProfile(
      firstName: Validators.clean(_first.text),
      lastName: Validators.clean(_last.text),
      email: Validators.clean(_mail.text),
      phone: Validators.clean(_tel.text),
      company: Validators.clean(_co.text),
    ));
    if (!mounted) return;
    showSnack(context, 'Profil enregistré (stockage chiffré sur cet appareil)');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ccAppBar(context, 'Mon profil'),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
          const Disclaimer(
            'Compte facultatif et local : vos informations restent chiffrées sur cet appareil et servent uniquement à pré-remplir vos demandes.',
            icon: Icons.lock_outline,
          ),
          const SizedBox(height: 16),
          FormCard(children: [
            FieldRow(children: [
              CCField(controller: _first, label: 'Prénom', capitalization: TextCapitalization.words),
              CCField(controller: _last, label: 'Nom', capitalization: TextCapitalization.words),
            ]),
            CCField(controller: _mail, label: 'Email', keyboard: TextInputType.emailAddress, validator: (v) => Validators.email(v, required: false)),
            CCField(controller: _tel, label: 'Téléphone', keyboard: TextInputType.phone, validator: (v) => Validators.phone(v, required: false)),
            CCField(controller: _co, label: 'Entreprise', capitalization: TextCapitalization.words),
          ]),
          const SizedBox(height: 18),
          PrimaryButton('ENREGISTRER', icon: Icons.check, onPressed: _save),
        ]),
      ),
    );
  }
}
