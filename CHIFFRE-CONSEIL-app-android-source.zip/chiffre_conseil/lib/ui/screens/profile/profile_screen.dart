import 'package:flutter/material.dart';

import '../../../app_router.dart';
import '../../../core/config.dart';
import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../data/models/user_data.dart';
import '../../../features/tools/tool_catalog.dart';
import '../../../state/app_state.dart';
import '../../widgets/article_tile.dart';
import '../../widgets/cc_widgets.dart';
import '../library_screen.dart';
import '../tools_screen.dart';
import 'profile_edit_screen.dart';
import 'settings_screen.dart';

/// Espace utilisateur facultatif (données locales chiffrées).
/// Architecture prête pour l'espace client « CHIFFRE CONSEIL CLIENT ».
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final p = s.profile;
    final upcoming = s.requests
        .where((r) => r.kind == RequestKind.rendezVous && r.appointment != null && r.appointment!.isAfter(DateTime.now()))
        .toList();
    return Scaffold(
      appBar: ccAppBar(context, 'Mon espace', actions: [
        IconButton(
          tooltip: 'Réglages',
          icon: const Icon(Icons.settings_outlined),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
        ),
      ]),
      body: ListView(padding: const EdgeInsets.only(bottom: 110), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: CCCard(
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ProfileEditScreen())),
            child: Row(children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: CC.navy,
                child: Text(
                  p.isEmpty ? '?' : '${p.firstName.isNotEmpty ? p.firstName[0] : ''}${p.lastName.isNotEmpty ? p.lastName[0] : ''}'.toUpperCase(),
                  style: const TextStyle(color: CC.white, fontWeight: FontWeight.w800, fontSize: 18),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.isEmpty ? 'Créer mon profil' : p.fullName,
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strongText)),
                  const SizedBox(height: 2),
                  Text(p.isEmpty ? 'Facultatif — pour pré-remplir vos demandes' : (p.email.isNotEmpty ? p.email : p.phone),
                      style: TextStyle(fontSize: 12.5, color: context.mutedText)),
                ]),
              ),
              Icon(Icons.edit_outlined, color: context.mutedText),
            ]),
          ),
        ),
        if (upcoming.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: CCCard(
              color: context.isDark ? CC.darkCard : const Color(0xFFFFF3EE),
              border: false,
              onTap: () => go(context, '/profil/demandes'),
              child: Row(children: [
                const IconBadge(Icons.event_available, background: CC.orange, color: CC.white),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('Rendez-vous demandé : ${upcoming.first.summary}',
                      style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText, height: 1.35)),
                ),
              ]),
            ),
          ),
        const SectionTitle('Mon activité'),
        _MenuTile(
          icon: Icons.apartment,
          title: 'Mes entreprises',
          subtitle: s.companies.isEmpty ? 'Créer le profil de votre entreprise' : '${s.companies.length} entreprise(s) · score de pilotage',
          onTap: () => go(context, '/mon-entreprise'),
        ),
        _MenuTile(
          icon: Icons.history,
          title: 'Historique des demandes',
          subtitle: s.requests.isEmpty ? 'Rendez-vous, devis et messages' : '${s.requests.length} demande(s)',
          badge: s.requests.where((r) => r.status == RequestStatus.pending).length,
          onTap: () => go(context, '/profil/demandes'),
        ),
        _MenuTile(
          icon: Icons.notifications_none,
          title: 'Notifications',
          subtitle: s.unreadNotices == 0 ? 'Aucune nouvelle notification' : '${s.unreadNotices} non lue(s)',
          badge: s.unreadNotices,
          onTap: () => go(context, '/notifications'),
        ),
        const SectionTitle('Mes contenus'),
        _MenuTile(
          icon: Icons.bookmark_border,
          title: 'Favoris',
          subtitle: '${s.favorites.length} élément(s)',
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const FavoritesScreen())),
        ),
        _MenuTile(
          icon: Icons.download_done,
          title: 'Documents sauvegardés',
          subtitle: '${s.savedDocs.length} document(s) hors connexion',
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SavedDocumentsScreen())),
        ),
        _MenuTile(
          icon: Icons.schedule,
          title: 'Derniers articles consultés',
          subtitle: '${s.recentArticles.length} article(s)',
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const RecentScreen())),
        ),
        const SectionTitle('CHIFFRE CONSEIL'),
        _MenuTile(icon: Icons.info_outline, title: 'Le cabinet', subtitle: 'Mission, vision, valeurs', onTap: () => go(context, '/a-propos')),
        _MenuTile(icon: Icons.support_agent, title: 'Contact', subtitle: 'Appeler, écrire, itinéraire', onTap: () => go(context, '/contact')),
        _MenuTile(
          icon: Icons.lock_outline,
          title: 'Espace client',
          subtitle: 'Bientôt : suivi des missions, documents, factures et tableaux de bord',
          onTap: () => showSnack(context, 'L’espace client CHIFFRE CONSEIL arrive prochainement.'),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 26, 16, 0),
          child: Column(children: [
            Image.asset(context.isDark ? 'assets/images/brand/logo_inverse.png' : 'assets/images/brand/logo_color.png', height: 28),
            const SizedBox(height: 6),
            Text('Version ${AppConfig.version}', style: TextStyle(fontSize: 11.5, color: context.mutedText)),
          ]),
        ),
      ]),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({required this.icon, required this.title, required this.subtitle, required this.onTap, this.badge = 0});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: CCCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(children: [
          IconBadge(icon, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
              const SizedBox(height: 2),
              Text(subtitle, style: TextStyle(fontSize: 12, color: context.mutedText)),
            ]),
          ),
          if (badge > 0) Badge(label: Text('$badge'), backgroundColor: CC.orange),
          const SizedBox(width: 6),
          Icon(Icons.chevron_right, color: context.mutedText),
        ]),
      ),
    );
  }
}

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final articles = s.favoriteArticles;
    final tools = s.ready
        ? allTools(s.content).where((t) => s.isFavorite('t:${t.slug}')).toList()
        : <ToolEntry>[];
    return Scaffold(
      appBar: ccAppBar(context, 'Favoris'),
      body: (articles.isEmpty && tools.isEmpty)
          ? const Center(
              child: EmptyState(
                icon: Icons.bookmark_border,
                title: 'Aucun favori',
                message: 'Touchez l’icône signet d’un article ou d’un outil pour le retrouver ici.',
              ),
            )
          : ListView(padding: const EdgeInsets.only(bottom: 40), children: [
              if (tools.isNotEmpty) ...[const SectionTitle('Outils'), for (final t in tools) ToolCard(tool: t)],
              if (articles.isNotEmpty) ...[const SectionTitle('Articles'), for (final a in articles) ArticleTile(article: a)],
            ]),
    );
  }
}

class RecentScreen extends StatelessWidget {
  const RecentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final list = AppScope.of(context).recentArticles;
    return Scaffold(
      appBar: ccAppBar(context, 'Derniers articles consultés'),
      body: list.isEmpty
          ? const Center(child: EmptyState(icon: Icons.schedule, title: 'Aucun article consulté'))
          : ListView(padding: const EdgeInsets.only(bottom: 40), children: [for (final a in list) ArticleTile(article: a)]),
    );
  }
}
