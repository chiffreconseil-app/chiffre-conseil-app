import 'package:flutter/material.dart';

import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../core/utils/format.dart';
import '../../../data/models/user_data.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';

class RequestsScreen extends StatelessWidget {
  const RequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final list = s.requests;
    final pending = list.where((r) => r.status == RequestStatus.pending).length;
    return Scaffold(
      appBar: ccAppBar(context, 'Historique des demandes'),
      body: list.isEmpty
          ? const Center(
              child: EmptyState(
                icon: Icons.history,
                title: 'Aucune demande',
                message: 'Vos demandes de rendez-vous, de devis et vos messages apparaîtront ici.',
              ),
            )
          : ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 40), children: [
              if (pending > 0)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: CCCard(
                    color: CC.warning.withValues(alpha: 0.12),
                    border: false,
                    child: Row(children: [
                      const Icon(Icons.schedule_send, color: CC.warning),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text('$pending demande(s) en attente d’envoi (hors connexion).',
                            style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
                      ),
                      TextButton(
                        onPressed: () async {
                          final n = await s.retryPending();
                          if (context.mounted) {
                            showSnack(context, n > 0 ? '$n demande(s) envoyée(s)' : 'Toujours hors connexion, nouvel essai automatique plus tard.');
                          }
                        },
                        child: const Text('Réessayer'),
                      ),
                    ]),
                  ),
                ),
              for (final r in list) _RequestCard(r: r),
            ]),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({required this.r});
  final RequestRecord r;

  @override
  Widget build(BuildContext context) {
    final sent = r.status == RequestStatus.sent;
    final icon = switch (r.kind) {
      RequestKind.rendezVous => Icons.event_available,
      RequestKind.devis => Icons.request_quote,
      RequestKind.contact => Icons.mail_outline,
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: CCCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            IconBadge(icon, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.typeLabel, style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
                Text('Envoyée le ${Fmt.shortDate(r.createdAt)}', style: TextStyle(fontSize: 12, color: context.mutedText)),
              ]),
            ),
            Pill(sent ? 'Transmise' : 'En attente',
                color: (sent ? CC.success : CC.warning).withValues(alpha: 0.14), textColor: sent ? CC.success : CC.warning),
          ]),
          const SizedBox(height: 10),
          Text(r.title, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
          const SizedBox(height: 2),
          Text(r.summary, style: TextStyle(fontSize: 13, color: context.mutedText, height: 1.4)),
          if (r.serverRef.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text('Référence : ${r.serverRef}', style: TextStyle(fontSize: 11.5, color: context.mutedText)),
          ],
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () => AppScope.read(context).deleteRequest(r.id),
              icon: const Icon(Icons.delete_outline, size: 18),
              label: const Text('Retirer de l’historique'),
              style: TextButton.styleFrom(foregroundColor: context.mutedText),
            ),
          ),
        ]),
      ),
    );
  }
}
