import 'package:flutter/material.dart';

import '../../../core/config.dart';
import '../../../core/services/push_service.dart';
import '../../../core/theme/cc_colors.dart';
import '../../../core/theme/cc_theme.dart';
import '../../../state/app_state.dart';
import '../../widgets/cc_widgets.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: ccAppBar(context, 'Réglages'),
      body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
        const SectionTitle('Apparence', padding: EdgeInsets.fromLTRB(20, 8, 12, 12)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.system, label: Text('Système'), icon: Icon(Icons.brightness_auto)),
              ButtonSegment(value: ThemeMode.light, label: Text('Clair'), icon: Icon(Icons.light_mode)),
              ButtonSegment(value: ThemeMode.dark, label: Text('Sombre'), icon: Icon(Icons.dark_mode)),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => s.setThemeMode(v.first),
          ),
        ),
        const SectionTitle('Notifications', eyebrow: 'Thèmes suivis'),
        for (final t in PushService.topics)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SwitchListTile.adaptive(
              value: s.notifPrefs[t.id] ?? true,
              onChanged: (v) => s.setNotifPref(t.id, v),
              title: Text(t.label, style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
              subtitle: Text(t.description, style: TextStyle(fontSize: 12, color: context.mutedText)),
              contentPadding: EdgeInsets.zero,
            ),
          ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Disclaimer('Les notifications push sont préparées (Firebase Cloud Messaging). Les nouveautés détectées à l’ouverture apparaissent déjà dans le centre de notifications.'),
        ),
        const SectionTitle('Confidentialité'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SwitchListTile.adaptive(
            value: s.analyticsConsent,
            onChanged: (v) => s.setAnalyticsConsent(v),
            contentPadding: EdgeInsets.zero,
            title: Text('Mesure d’audience anonyme', style: TextStyle(fontWeight: FontWeight.w700, color: context.strongText)),
            subtitle: Text('Pages consultées, outils utilisés, demandes envoyées — sans données personnelles. Désactivé par défaut.',
                style: TextStyle(fontSize: 12, color: context.mutedText)),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
          child: CCCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Vos données', style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
              const SizedBox(height: 8),
              Text(
                '• Profil, entreprises et historique des demandes : chiffrés sur l’appareil (Android Keystore).\n'
                '• Demandes de rendez-vous, devis et messages : transmises en HTTPS au cabinet, comme sur le site.\n'
                '• Aucune clé secrète ni donnée bancaire dans l’application.\n'
                '• Sauvegarde Android désactivée pour ces données.',
                style: TextStyle(fontSize: 12.5, height: 1.55, color: context.mutedText),
              ),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: CC.danger,
              side: const BorderSide(color: CC.danger),
              minimumSize: const Size(0, 50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Supprimer toutes mes données', style: TextStyle(fontWeight: FontWeight.w800)),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Supprimer mes données ?'),
                  content: const Text('Profil, entreprises, check-ups, favoris, documents téléchargés et historique seront effacés de cet appareil.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer', style: TextStyle(color: CC.danger))),
                  ],
                ),
              );
              if (ok == true) {
                await s.wipeAllData();
                if (context.mounted) showSnack(context, 'Toutes vos données ont été supprimées de cet appareil.');
              }
            },
          ),
        ),
        const SectionTitle('À propos'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: CCCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${AppConfig.appName} — version ${AppConfig.version}', style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
              const SizedBox(height: 4),
              Text('Contenus : ${AppConfig.siteUrl}${s.ready ? ' — mise à jour du ${s.content.version}' : ''}',
                  style: TextStyle(fontSize: 12.5, color: context.mutedText)),
              const SizedBox(height: 4),
              Text('Police Montserrat — SIL Open Font License.', style: TextStyle(fontSize: 12, color: context.mutedText)),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () => showLicensePage(context: context, applicationName: AppConfig.appName, applicationVersion: AppConfig.version),
                child: const Text('Licences des composants'),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
