import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/config.dart';
import '../../core/theme/cc_colors.dart';
import '../../state/app_state.dart';
import '../widgets/cc_widgets.dart';
import 'shell.dart';

/// Démarrage : écran de lancement (≤ 2 s) → présentation (1re fois) → application.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _minDelayDone = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 1700), () {
      if (mounted) setState(() => _minDelayDone = true);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    Widget child;
    if (!_minDelayDone || !s.ready) {
      child = const SplashView(key: ValueKey('splash'));
    } else if (!s.onboardingDone) {
      child = const OnboardingView(key: ValueKey('onboarding'));
    } else {
      child = const AppShell(key: ValueKey('shell'));
    }
    return AnimatedSwitcher(duration: const Duration(milliseconds: 450), child: child);
  }
}

class SplashView extends StatelessWidget {
  const SplashView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CC.navy,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [CC.navySoft, CC.navy, CC.navyDeep]),
        ),
        child: Stack(children: [
          Positioned(
            right: -120,
            bottom: -110,
            child: Opacity(opacity: 0.06, child: Image.asset('assets/images/brand/symbol_inverse.png', width: 420, color: CC.white)),
          ),
          Center(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              builder: (context, v, child) => Opacity(
                opacity: v,
                child: Transform.scale(scale: 0.92 + 0.08 * v, child: child),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Image.asset('assets/images/brand/symbol_inverse.png', width: 92, height: 92),
                const SizedBox(height: 22),
                const Text('CHIFFRE CONSEIL',
                    style: TextStyle(color: CC.white, fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                const SizedBox(height: 10),
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 700),
                  curve: const Interval(0.45, 1, curve: Curves.easeOut),
                  builder: (context, v, child) => Opacity(opacity: v, child: child),
                  child: const Text(AppConfig.slogan,
                      style: TextStyle(color: CC.orangeLight, fontSize: 12.5, fontWeight: FontWeight.w700, letterSpacing: 3.2)),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class OnboardingView extends StatefulWidget {
  const OnboardingView({super.key});

  @override
  State<OnboardingView> createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  final _pc = PageController();
  int _page = 0;
  bool _consent = false;

  static const _pages = [
    (Icons.insights, 'Pilotez mieux votre entreprise.', 'Check-up, score de pilotage et tableau de bord de votre entreprise, pour savoir où agir en priorité.'),
    (Icons.calculate, 'Accédez à nos outils et ressources.', 'Simulateurs fiscaux à jour de la loi de finances 2026, outils de gestion et plus de 50 fiches et guides pratiques.'),
    (Icons.handshake, 'Bénéficiez d’un accompagnement adapté.', 'Prenez rendez-vous ou demandez un devis en deux minutes : le cabinet revient vers vous sous 48 heures ouvrées.'),
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    final s = AppScope.read(context);
    await s.setAnalyticsConsent(_consent);
    s.completeOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    final last = _page == _pages.length - 1;
    return Scaffold(
      backgroundColor: CC.navy,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 8, 0),
            child: Row(children: [
              Image.asset('assets/images/brand/logo_inverse.png', height: 34),
              const Spacer(),
              if (!last)
                TextButton(
                  onPressed: () => _pc.animateToPage(_pages.length - 1, duration: const Duration(milliseconds: 400), curve: Curves.easeOutCubic),
                  child: const Text('Passer', style: TextStyle(color: CC.white, fontWeight: FontWeight.w600)),
                ),
            ]),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pc,
              itemCount: _pages.length,
              onPageChanged: (i) => setState(() => _page = i),
              itemBuilder: (context, i) {
                final p = _pages[i];
                return LayoutBuilder(builder: (context, c) {
                  final compact = c.maxHeight < 420;
                  return SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: c.maxHeight),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(
                          width: compact ? 110 : 168,
                          height: compact ? 110 : 168,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: CC.white.withValues(alpha: 0.06),
                            border: Border.all(color: CC.white.withValues(alpha: 0.12), width: 1.5),
                          ),
                          child: Icon(p.$1, size: compact ? 50 : 76, color: CC.orangeLight),
                        ),
                        SizedBox(height: compact ? 20 : 40),
                        Text('0${i + 1}', style: const TextStyle(color: CC.orange, fontWeight: FontWeight.w800, letterSpacing: 2)),
                        const SizedBox(height: 10),
                        Text(p.$2,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: CC.white, fontSize: 26, fontWeight: FontWeight.w800, height: 1.2)),
                        const SizedBox(height: 14),
                        Text(p.$3,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: CC.white.withValues(alpha: 0.75), fontSize: 15, height: 1.55)),
                      ]),
                    ),
                  );
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
            child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                for (var i = 0; i < _pages.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: i == _page ? 26 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: i == _page ? CC.orange : CC.white.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
              ]),
              const SizedBox(height: 18),
              if (last)
                Theme(
                  data: Theme.of(context).copyWith(unselectedWidgetColor: CC.white),
                  child: CheckboxListTile(
                    value: _consent,
                    onChanged: (v) => setState(() => _consent = v ?? false),
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    activeColor: CC.orange,
                    side: const BorderSide(color: CC.white, width: 1.5),
                    title: Text('J’accepte la mesure d’audience anonyme pour améliorer l’application (facultatif).',
                        style: TextStyle(color: CC.white.withValues(alpha: 0.85), fontSize: 12.5)),
                  ),
                ),
              const SizedBox(height: 8),
              PrimaryButton(
                last ? 'COMMENCER' : 'SUIVANT',
                icon: last ? Icons.arrow_forward : null,
                onPressed: last
                    ? _finish
                    : () => _pc.nextPage(duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
