import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';
import '../../state/app_state.dart';
import '../widgets/cc_widgets.dart';
import 'home_screen.dart';
import 'library_screen.dart';
import 'news_screen.dart';
import 'profile/profile_screen.dart';
import 'tools_screen.dart';

/// Permet aux onglets de changer d'onglet (ex. « Voir tous les outils »).
class ShellScope extends InheritedWidget {
  const ShellScope({super.key, required this.goTab, required super.child});
  final void Function(int index) goTab;

  static ShellScope? maybeOf(BuildContext context) => context.dependOnInheritedWidgetOfExactType<ShellScope>();

  @override
  bool updateShouldNotify(ShellScope oldWidget) => false;
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  final _visited = <int>{0};

  static const _tabs = ['accueil', 'outils', 'ressources', 'actualites', 'profil'];

  void _go(int i) {
    setState(() {
      _index = i;
      _visited.add(i);
    });
    AppScope.read(context).analytics.screen(_tabs[i]);
  }

  void _quickActions() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: context.cardColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Action rapide', style: ctx.tt.titleLarge?.copyWith(color: ctx.strongText)),
            const SizedBox(height: 14),
            _QuickTile(icon: Icons.event_available, title: 'Prendre rendez-vous', subtitle: 'Entretien de découverte de 30 min, sans engagement', onTap: () {
              Navigator.pop(ctx);
              go(context, '/rendez-vous');
            }),
            _QuickTile(icon: Icons.request_quote, title: 'Demander un devis', subtitle: 'Proposition chiffrée sous 48 heures ouvrées', onTap: () {
              Navigator.pop(ctx);
              go(context, '/devis');
            }),
            _QuickTile(icon: Icons.support_agent, title: 'Contacter CHIFFRE CONSEIL', subtitle: 'Téléphone, e-mail, itinéraire', onTap: () {
              Navigator.pop(ctx);
              go(context, '/contact');
            }),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final pages = <Widget>[
      const HomeScreen(),
      const ToolsScreen(),
      const LibraryScreen(),
      const NewsScreen(),
      const ProfileScreen(),
    ];
    return ShellScope(
      goTab: _go,
      child: Scaffold(
        body: Column(children: [
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            child: s.online ? const SizedBox(width: double.infinity) : const OfflineBanner(),
          ),
          Expanded(
            child: MediaQuery.removePadding(
              context: context,
              removeTop: !s.online,
              child: IndexedStack(
                index: _index,
                children: [
                  for (var i = 0; i < pages.length; i++) _visited.contains(i) ? pages[i] : const SizedBox.shrink(),
                ],
              ),
            ),
          ),
        ]),
        floatingActionButton: FloatingActionButton(
          onPressed: _quickActions,
          backgroundColor: CC.orange,
          foregroundColor: CC.white,
          tooltip: 'Action rapide',
          shape: const CircleBorder(),
          child: const Icon(Icons.add, size: 30),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: _go,
          backgroundColor: context.cardColor,
          indicatorColor: context.isDark ? CC.navySoft : const Color(0xFFFFE9DF),
          surfaceTintColor: Colors.transparent,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: [
            const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
            const NavigationDestination(icon: Icon(Icons.calculate_outlined), selectedIcon: Icon(Icons.calculate), label: 'Outils'),
            const NavigationDestination(icon: Icon(Icons.library_books_outlined), selectedIcon: Icon(Icons.library_books), label: 'Ressources'),
            const NavigationDestination(icon: Icon(Icons.newspaper_outlined), selectedIcon: Icon(Icons.newspaper), label: 'Actualités'),
            NavigationDestination(
              icon: Badge(isLabelVisible: s.unreadNotices > 0, child: const Icon(Icons.person_outline)),
              selectedIcon: Badge(isLabelVisible: s.unreadNotices > 0, child: const Icon(Icons.person)),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickTile extends StatelessWidget {
  const _QuickTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: CCCard(
        onTap: onTap,
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          IconBadge(icon),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: context.strongText)),
              const SizedBox(height: 2),
              Text(subtitle, style: TextStyle(fontSize: 12.5, color: context.mutedText)),
            ]),
          ),
          Icon(Icons.chevron_right, color: context.mutedText),
        ]),
      ),
    );
  }
}
