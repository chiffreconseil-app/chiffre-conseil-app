import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_theme.dart';
import '../../features/tools/tool_catalog.dart';
import '../../state/app_state.dart';
import '../cc_icons.dart';
import '../widgets/article_tile.dart';
import '../widgets/cc_widgets.dart';

class ToolsScreen extends StatefulWidget {
  const ToolsScreen({super.key, this.standalone = false});
  final bool standalone;

  @override
  State<ToolsScreen> createState() => _ToolsScreenState();
}

class _ToolsScreenState extends State<ToolsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final all = allTools(s.content);
    bool match(ToolEntry t) => _q.isEmpty || '${t.name} ${t.description} ${t.short}'.toLowerCase().contains(_q);
    final fiscal = all.where((t) => t.isFiscal && match(t)).toList();
    final gestion = all.where((t) => !t.isFiscal && match(t)).toList();
    return Scaffold(
      appBar: ccAppBar(context, 'Outils CHIFFRE CONSEIL'),
      body: ListView(padding: const EdgeInsets.only(bottom: 110), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
          child: Text('Simulateurs gratuits, utilisables hors connexion. Les résultats sont indicatifs et ne remplacent pas un conseil personnalisé.',
              style: TextStyle(color: context.mutedText, height: 1.45)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: SearchField(hint: 'Rechercher un outil', onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
        ),
        if (fiscal.isNotEmpty) ...[
          const SectionTitle('Fiscalité & paie', eyebrow: 'Barème loi de finances 2026'),
          for (final t in fiscal) ToolCard(tool: t),
        ],
        if (gestion.isNotEmpty) ...[
          const SectionTitle('Gestion & finance', eyebrow: 'Outils de pilotage'),
          for (final t in gestion) ToolCard(tool: t),
        ],
        if (fiscal.isEmpty && gestion.isEmpty)
          const EmptyState(icon: Icons.search_off, title: 'Aucun outil trouvé', message: 'Essayez un autre mot-clé.'),
      ]),
    );
  }
}

class ToolCard extends StatelessWidget {
  const ToolCard({super.key, required this.tool});
  final ToolEntry tool;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: CCCard(
        onTap: () => go(context, '/outils/${tool.slug}'),
        padding: const EdgeInsets.fromLTRB(14, 14, 6, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconBadge(CCIcons.tool(tool.slug)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tool.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: context.strongText)),
                const SizedBox(height: 4),
                Text(tool.description, style: TextStyle(fontSize: 12.5, height: 1.4, color: context.mutedText)),
              ]),
            ),
            FavoriteButton(keyId: 't:${tool.slug}'),
          ]),
          const SizedBox(height: 6),
          Row(children: [
            const SizedBox(width: 56),
            Pill(tool.isFiscal ? 'Simulateur du site' : 'Outil de gestion', icon: tool.isFiscal ? Icons.public : Icons.insights),
            const Spacer(),
            TextButton.icon(
              onPressed: () => go(context, '/outils/${tool.slug}'),
              icon: const Icon(Icons.play_arrow_rounded, size: 18),
              label: const Text('UTILISER', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5)),
              style: TextButton.styleFrom(foregroundColor: context.accentText),
            ),
          ]),
        ]),
      ),
    );
  }
}

class SearchField extends StatelessWidget {
  const SearchField({super.key, required this.hint, required this.onChanged, this.controller});
  final String hint;
  final ValueChanged<String> onChanged;
  final TextEditingController? controller;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: const Icon(Icons.search),
        filled: true,
        fillColor: context.cardColor,
        contentPadding: const EdgeInsets.symmetric(vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: context.lineColor)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: context.lineColor)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: context.accentText, width: 1.5)),
      ),
    );
  }
}
