import 'package:flutter/material.dart';

import '../../app_router.dart';
import '../../core/theme/cc_theme.dart';
import '../../core/utils/format.dart';
import '../../data/models/content.dart';
import '../../state/app_state.dart';
import 'cc_widgets.dart';

/// Ligne d'article : image, catégorie, titre, extrait, date, bouton « Lire ».
class ArticleTile extends StatelessWidget {
  const ArticleTile({super.key, required this.article, this.showExcerpt = true});
  final Article article;
  final bool showExcerpt;

  @override
  Widget build(BuildContext context) {
    final a = article;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: CCCard(
        padding: const EdgeInsets.all(12),
        onTap: () => go(context, '/blog/${a.slug}'),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ArticleImage(thumb: a.thumb, url: a.image, width: 104, height: 84),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Pill(a.section.isEmpty ? a.kindLabel : a.section)),
              ]),
              const SizedBox(height: 7),
              Text(a.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5, height: 1.3, color: context.strongText)),
              if (showExcerpt && a.description.isNotEmpty) ...[
                const SizedBox(height: 5),
                Text(a.description,
                    maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, height: 1.4, color: context.mutedText)),
              ],
              const SizedBox(height: 8),
              Row(children: [
                Icon(Icons.calendar_today_outlined, size: 13, color: context.mutedText),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(a.date.isEmpty ? a.kindLabel : Fmt.isoDate(a.date),
                      style: TextStyle(fontSize: 11.5, color: context.mutedText)),
                ),
                Text('Lire', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: context.accentText)),
                Icon(Icons.arrow_forward, size: 14, color: context.accentText),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}

/// Bouton favori réutilisable.
class FavoriteButton extends StatelessWidget {
  const FavoriteButton({super.key, required this.keyId, this.color});
  final String keyId;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final fav = s.isFavorite(keyId);
    return IconButton(
      tooltip: fav ? 'Retirer des favoris' : 'Ajouter aux favoris',
      icon: Icon(fav ? Icons.bookmark : Icons.bookmark_border, color: color),
      onPressed: () {
        s.toggleFavorite(keyId);
        showSnack(context, fav ? 'Retiré des favoris' : 'Ajouté aux favoris');
      },
    );
  }
}
