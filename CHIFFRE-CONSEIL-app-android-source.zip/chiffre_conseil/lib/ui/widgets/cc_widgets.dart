import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/cc_colors.dart';
import '../../core/theme/cc_theme.dart';

// ================================ navigation ==================================

AppBar ccAppBar(BuildContext context, String title, {List<Widget>? actions, PreferredSizeWidget? bottom}) {
  return AppBar(
    title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
    titleTextStyle: TextStyle(fontFamily: CCTheme.font, fontWeight: FontWeight.w800, fontSize: 18, color: context.strongText),
    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
    foregroundColor: context.strongText,
    surfaceTintColor: Colors.transparent,
    elevation: 0,
    scrolledUnderElevation: 0.5,
    centerTitle: false,
    actions: actions,
    bottom: bottom,
  );
}

// ================================ textes =====================================

class Eyebrow extends StatelessWidget {
  const Eyebrow(this.text, {super.key, this.color});
  final String text;
  final Color? color;

  @override
  Widget build(BuildContext context) => Text(
        text.toUpperCase(),
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.6, color: color ?? context.accentText),
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.eyebrow, this.actionLabel, this.onAction, this.padding});
  final String title;
  final String? eyebrow;
  final String? actionLabel;
  final VoidCallback? onAction;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(20, 28, 12, 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (eyebrow != null) ...[Eyebrow(eyebrow!), const SizedBox(height: 4)],
                Text(title, style: context.tt.titleLarge?.copyWith(color: context.strongText, fontSize: 20)),
              ],
            ),
          ),
          if (actionLabel != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(foregroundColor: context.accentText),
              child: Text(actionLabel!, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
        ],
      ),
    );
  }
}

/// Texte avec segments **gras** (format issu de l'extraction du site).
class RichMarkdownText extends StatelessWidget {
  const RichMarkdownText(this.text, {super.key, this.style});
  final String text;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    final base = style ?? context.tt.bodyLarge;
    final parts = text.split('**');
    return Text.rich(TextSpan(
      style: base,
      children: [
        for (var i = 0; i < parts.length; i++)
          TextSpan(
            text: parts[i],
            style: i.isOdd ? TextStyle(fontWeight: FontWeight.w700, color: context.strongText) : null,
          ),
      ],
    ));
  }
}

// ================================= cartes ====================================

class CCCard extends StatelessWidget {
  const CCCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(16), this.color, this.radius = 16, this.border = true});
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final Color? color;
  final double radius;
  final bool border;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    return Material(
      color: color ?? context.cardColor,
      borderRadius: r,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        borderRadius: r,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: r,
            border: border ? Border.all(color: context.lineColor) : null,
          ),
          child: child,
        ),
      ),
    );
  }
}

class IconBadge extends StatelessWidget {
  const IconBadge(this.icon, {super.key, this.size = 44, this.background, this.color});
  final IconData icon;
  final double size;
  final Color? background;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: background ?? (context.isDark ? CC.navySoft : const Color(0xFFEEF1F8)),
        borderRadius: BorderRadius.circular(size * 0.3),
      ),
      child: Icon(icon, size: size * 0.52, color: color ?? (context.isDark ? CC.orangeLight : CC.navy)),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.label, {super.key, this.color, this.textColor, this.icon});
  final String label;
  final Color? color;
  final Color? textColor;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final fg = textColor ?? context.accentText;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color ?? (context.isDark ? CC.navySoft : const Color(0xFFFFEFE8)),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 13, color: fg), const SizedBox(width: 4)],
        Flexible(
          child: Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: fg)),
        ),
      ]),
    );
  }
}

// ================================= boutons ===================================

class PrimaryButton extends StatelessWidget {
  const PrimaryButton(this.label, {super.key, required this.onPressed, this.icon, this.expand = true, this.loading = false});
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final btn = FilledButton(
      onPressed: loading ? null : onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: CC.orange,
        foregroundColor: CC.white,
        disabledBackgroundColor: CC.orange.withValues(alpha: 0.5),
        disabledForegroundColor: CC.white,
        minimumSize: const Size(0, 54),
        padding: const EdgeInsets.symmetric(horizontal: 22),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontFamily: CCTheme.font, fontWeight: FontWeight.w800, fontSize: 14.5, letterSpacing: 0.6),
      ),
      child: loading
          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: CC.white))
          : Row(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 10)],
              Flexible(child: Text(label, textAlign: TextAlign.center)),
            ]),
    );
    return expand ? SizedBox(width: double.infinity, child: btn) : btn;
  }
}

class SecondaryButton extends StatelessWidget {
  const SecondaryButton(this.label, {super.key, required this.onPressed, this.icon, this.expand = true, this.onDark = false});
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    final fg = onDark ? CC.white : context.strongText;
    final btn = OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: fg,
        side: BorderSide(color: onDark ? CC.white.withValues(alpha: 0.6) : (context.isDark ? CC.darkLine : CC.navy), width: 1.4),
        minimumSize: const Size(0, 54),
        padding: const EdgeInsets.symmetric(horizontal: 20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontFamily: CCTheme.font, fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: 0.5),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 10)],
        Flexible(child: Text(label, textAlign: TextAlign.center)),
      ]),
    );
    return expand ? SizedBox(width: double.infinity, child: btn) : btn;
  }
}

// ============================ chargement / états =============================

/// Bloc de chargement (skeleton) pulsé, sans dépendance.
class Skeleton extends StatefulWidget {
  const Skeleton({super.key, this.height = 16, this.width = double.infinity, this.radius = 10});
  final double height;
  final double width;
  final double radius;

  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = context.isDark ? CC.darkCard : const Color(0xFFE7EBF3);
    return FadeTransition(
      opacity: Tween<double>(begin: 0.45, end: 1).animate(_c),
      child: Container(
        height: widget.height,
        width: widget.width,
        decoration: BoxDecoration(color: base, borderRadius: BorderRadius.circular(widget.radius)),
      ),
    );
  }
}

class ArticleSkeleton extends StatelessWidget {
  const ArticleSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Row(children: [
        const Skeleton(width: 96, height: 72, radius: 12),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Skeleton(height: 12, width: 90),
            SizedBox(height: 10),
            Skeleton(height: 14),
            SizedBox(height: 8),
            Skeleton(height: 14, width: 180),
          ]),
        ),
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, this.message, this.action});
  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 40),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        IconBadge(icon, size: 64),
        const SizedBox(height: 18),
        Text(title, textAlign: TextAlign.center, style: context.tt.titleMedium?.copyWith(color: context.strongText)),
        if (message != null) ...[
          const SizedBox(height: 8),
          Text(message!, textAlign: TextAlign.center, style: TextStyle(color: context.mutedText, height: 1.5)),
        ],
        if (action != null) ...[const SizedBox(height: 20), action!],
      ]),
    );
  }
}

class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: CC.navy,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          child: Row(children: const [
            Icon(Icons.wifi_off, size: 18, color: CC.orangeLight),
            SizedBox(width: 10),
            Expanded(
              child: Text('Vous êtes actuellement hors connexion.',
                  style: TextStyle(color: CC.white, fontWeight: FontWeight.w600, fontSize: 13)),
            ),
          ]),
        ),
      ),
    );
  }
}

class Disclaimer extends StatelessWidget {
  const Disclaimer(this.text, {super.key, this.icon = Icons.info_outline});
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: context.isDark ? CC.darkSurface : const Color(0xFFEFF3FF),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 18, color: CC.blue),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: TextStyle(fontSize: 12.5, height: 1.5, color: context.mutedText))),
      ]),
    );
  }
}

// ================================ scores =====================================

class ScoreBar extends StatelessWidget {
  const ScoreBar({super.key, required this.label, required this.value});
  final String label;
  final double value; // 0..100

  @override
  Widget build(BuildContext context) {
    final c = CC.score(value);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: context.strongText))),
          Text('${value.round()} %', style: TextStyle(fontWeight: FontWeight.w800, color: c)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: (value / 100).clamp(0.0, 1.0),
            minHeight: 8,
            backgroundColor: context.isDark ? CC.darkLine : const Color(0xFFE7EBF3),
            valueColor: AlwaysStoppedAnimation<Color>(c),
          ),
        ),
      ]),
    );
  }
}

class ScoreRing extends StatelessWidget {
  const ScoreRing({super.key, required this.value, this.size = 150, this.caption = 'sur 100'});
  final double value;
  final double size;
  final String caption;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (context, v, _) => CustomPaint(
          painter: _RingPainter(v / 100, CC.score(value), context.isDark ? CC.darkLine : const Color(0xFFE7EBF3)),
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('${v.round()}', style: TextStyle(fontSize: size * 0.28, fontWeight: FontWeight.w800, color: context.strongText, height: 1)),
              Text(caption, style: TextStyle(fontSize: 12, color: context.mutedText)),
            ]),
          ),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.ratio, this.color, this.track);
  final double ratio;
  final Color color;
  final Color track;

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = size.width * 0.085;
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke, size.height - stroke);
    final bg = Paint()
      ..color = track
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    final fg = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = stroke;
    canvas.drawArc(rect, 0, math.pi * 2, false, bg);
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * ratio.clamp(0.0, 1.0), false, fg);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.ratio != ratio || old.color != color;
}

// ============================ actions externes ===============================

Future<void> openLink(BuildContext context, String url, {bool inApp = false}) async {
  final uri = Uri.tryParse(url);
  var ok = false;
  if (uri != null) {
    try {
      ok = await launchUrl(uri, mode: inApp ? LaunchMode.inAppBrowserView : LaunchMode.externalApplication);
    } catch (_) {
      ok = false;
    }
  }
  if (!ok && context.mounted) {
    showSnack(context, 'Impossible d’ouvrir ce lien sur cet appareil.');
  }
}

Future<void> callPhone(BuildContext context, String phone) =>
    openLink(context, 'tel:${phone.replaceAll(' ', '')}');

Future<void> sendMail(BuildContext context, String email, {String subject = '', String body = ''}) {
  final q = <String>[];
  if (subject.isNotEmpty) q.add('subject=${Uri.encodeComponent(subject)}');
  if (body.isNotEmpty) q.add('body=${Uri.encodeComponent(body)}');
  return openLink(context, 'mailto:$email${q.isEmpty ? '' : '?${q.join('&')}'}');
}

void showSnack(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      behavior: SnackBarBehavior.floating,
      backgroundColor: error ? CC.danger : CC.navy,
    ));
}

/// Image d'article : version embarquée si disponible, sinon réseau, sinon motif.
class ArticleImage extends StatelessWidget {
  const ArticleImage({super.key, required this.thumb, required this.url, this.height, this.width, this.radius = 12});
  final String thumb;
  final String url;
  final double? height;
  final double? width;
  final double radius;

  @override
  Widget build(BuildContext context) {
    Widget fallback() => Container(
          color: CC.navy,
          alignment: Alignment.center,
          child: Image.asset('assets/images/brand/symbol_inverse.png', width: 34, height: 34),
        );
    Widget img;
    if (thumb.isNotEmpty) {
      img = Image.asset(thumb, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback());
    } else if (url.startsWith('https://')) {
      img = Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback());
    } else {
      img = fallback();
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: SizedBox(height: height, width: width, child: img),
    );
  }
}

/// Encadré avec filet orange à gauche (coins arrondis).
class AccentBox extends StatelessWidget {
  const AccentBox({super.key, required this.child, this.background, this.accent = CC.orange});
  final Widget child;
  final Color? background;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Container(
        color: background ?? context.softFill,
        child: IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Container(width: 4, color: accent),
            Expanded(child: Padding(padding: const EdgeInsets.all(14), child: child)),
          ]),
        ),
      ),
    );
  }
}
