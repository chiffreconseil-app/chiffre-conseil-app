# Intégration au site chiffreconseil.net

## 1. Contenu de l'application — `www/app/content.json`
Déposez `www/app/content.json` sur l'hébergement, dans `www/app/content.json`, pour obtenir l'adresse https://chiffreconseil.net/app/content.json.
L'application télécharge ce fichier à l'ouverture pour se tenir à jour : expertises, outils, fiches et références officielles.
Ce fichier a déjà été ajouté au package du site (`chiffre-conseil-site-espace-gestion.zip`).

Après chaque nouvelle publication sur le site, régénérez-le :
```bash
python3 tool/extract_site_content.py <dossier www du site> site-integration/www/app/content.json
```
Les articles publiés depuis l'espace de gestion (`/api/articles.php`) apparaissent dans l'application sans régénérer ce fichier.

## 2. Liens profonds vérifiés — `www/.well-known/assetlinks.json`
1. Récupérez l'empreinte SHA-256 de la clé de signature. Elle se trouve dans le fichier `empreinte-signature-*.txt` des artefacts GitHub Actions ; vous pouvez aussi l'obtenir avec `tool/create_keystore.sh`.
2. Copiez `assetlinks.json.modele` en `assetlinks.json` et remplacez la valeur indiquée par l'empreinte, au format `AB:CD:…`.
3. Déposez le fichier dans `www/.well-known/assetlinks.json`, accessible en HTTPS.

Les liens https://chiffreconseil.net/outils, /rendez-vous, /devis et /blog/… ouvriront alors l'application directement sur les téléphones où elle est installée.

## 3. Formulaires
L'application envoie les demandes à `/api/contact.php`, comme le site. Rien à modifier.
Le champ `source` vaut `application-android` et apparaît dans le courriel reçu.
