// Vérifie que les moteurs Dart donnent EXACTEMENT les mêmes résultats que les
// calculateurs publiés sur chiffreconseil.net (valeurs de référence calculées
// avec assets/js/03-calculateurs.js du site).
import 'package:chiffre_conseil/core/utils/format.dart';
import 'package:chiffre_conseil/features/company/checkup_data.dart';
import 'package:chiffre_conseil/features/tools/engines/finance_engines.dart';
import 'package:chiffre_conseil/features/tools/engines/fiscal_engines.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Barèmes du site (LF 2026)', () {
    test('IRPP — salaire 36 000 DT, chef de famille, 2 enfants', () {
      final r = calculIrpp(nature: 'salaire', revenu: 36000, enfants: 2, chef: true);
      expect(r.dTotal, closeTo(2500, 1e-6));
      expect(r.assiette, closeTo(33500, 1e-6));
      expect(r.r.total, closeTo(7405, 1e-6));
      expect(r.css, closeTo(335, 1e-6));
    });

    test('Paie — brut 2 200 DT, privé', () {
      final r = simulateurPaie(secteurPublic: false, depuisNet: false, montant: 2200);
      expect(r.cot, closeTo(212.96, 1e-6));
      expect(r.ir, closeTo(316.945333, 1e-5));
      expect(r.css, closeTo(18.203733, 1e-5));
      expect(r.net, closeTo(1651.890933, 1e-5));
      expect(r.patronal, closeTo(364.54, 1e-6));
    });

    test('Paie — du net (1 500 DT) vers le brut', () {
      final r = simulateurPaie(secteurPublic: false, depuisNet: true, montant: 1500);
      expect(r.brut, closeTo(1961.2449, 1e-3));
      expect(r.net, closeTo(1500, 1e-3));
    });

    test('Crédit — 100 000 DT, 84 mois, 10,5 %, assurance 0,4 %, frais 500', () {
      final r = simulateurCredit(montant: 100000, dureeMois: 84, tauxAnnuelPct: 10.5, mensualiteConstante: true, assurancePct: 0.4, frais: 500);
      expect(r.m1, closeTo(1719.4006, 1e-3));
      expect(r.totInterets, closeTo(41629.6544, 1e-3));
      expect(coutAnnuelMoyen(r, 84), closeTo(6.4185, 1e-3));
      expect(r.rows.length, 13);
    });

    test('Pension — privé, 2 000 DT, 30 ans', () {
      final r = calculPension(secteurPublic: false, salaire: 2000, annees: 30);
      expect(r.taux, closeTo(0.8, 1e-9));
      expect(r.brut, closeTo(1600, 1e-9));
      expect(r.net, closeTo(1375.873333, 1e-5));
    });

    test('TVA — 1 000 DT HT à 19 % avec timbre', () {
      final r = calculTva(depuisTtc: false, taux: 0.19, montant: 1000);
      expect(r.tva, closeTo(190, 1e-9));
      expect(r.net, closeTo(1191, 1e-9));
      final back = calculTva(depuisTtc: true, taux: 0.19, montant: 1190, timbre: false);
      expect(back.ht, closeTo(1000, 1e-9));
    });

    test('Vignette — personne physique, 5 à 7 CV, diesel', () {
      final r = calculVignette(personneMorale: false, puissance: '5-7', energie: '1', dernierChiffre: 3, location: false);
      expect(r.du, 280);
      expect(r.limite, contains('5 avril 2026'));
      final e = calculVignette(personneMorale: false, puissance: '4', energie: 'e', dernierChiffre: 2, location: false);
      expect(e.du, 32.5);
    });

    test('Retenue à la source — honoraires 3 % sur TTC', () {
      final r = retenueSource(taux: 0.03, ht: 5000, tauxTva: 0.19, baseHt: false, timbre: true);
      expect(r.ttc, closeTo(5951, 1e-9));
      expect(r.retenue, closeTo(178.53, 1e-9));
    });

    test('Matricule fiscal — clé modulo 23', () {
      final r = verifierMatricule('1234567/W/A/M/000');
      expect(r.normalise, '1234567WAM000');
      expect(r.attendue, 'W');
      expect(r.cleOk, isTrue);
    });
  });

  group('Outils de gestion', () {
    test('VAN / TRI', () {
      final r = analyseInvestissement(1000, [500, 500, 500], 0.10);
      expect(r.van, closeTo(243.4260, 1e-3));
      expect(r.tri, closeTo(0.233752, 1e-4));
      expect(r.paybackAnnees, closeTo(2.0, 1e-9));
    });

    test('Seuil de rentabilité', () {
      final r = seuilRentabilite(ca: 100000, chargesVariables: 60000, chargesFixes: 30000);
      expect(r.seuil, closeTo(75000, 1e-6));
      expect(r.resultat, closeTo(10000, 1e-6));
    });

    test('BFR', () {
      final r = calculBfr(stocks: 50000, creances: 80000, dettesFournisseurs: 40000, chiffreAffairesAnnuel: 720000, fondsDeRoulement: 60000);
      expect(r.bfr, 90000);
      expect(r.joursCa, closeTo(45, 1e-9));
      expect(r.tresorerieNette, -30000);
    });
  });

  group('Check-up', () {
    test('21 questions, 7 domaines, score 0..100', () {
      expect(checkupQuestions.length, 21);
      final (top, g) = computeCheckup(List<int>.filled(21, 3));
      expect(g, closeTo(100, 1e-9));
      expect(top.length, 7);
      final (_, low) = computeCheckup(List<int>.filled(21, 0));
      expect(low, 0);
    });
  });

  group('Formats', () {
    test('Montants en français', () {
      expect(Fmt.num(1234567.891), '1 234 567,891');
      expect(Fmt.dt(0), '0,000 TND');
      expect(Fmt.num(-0.0001), '0,000');
      expect(Fmt.parse('1 234,5'), 1234.5);
      expect(Fmt.rate(0.015), '1,5 %');
    });
  });
}
