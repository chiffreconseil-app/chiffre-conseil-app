import 'package:chiffre_conseil/app_router.dart';
import 'package:chiffre_conseil/core/theme/cc_theme.dart';
import 'package:chiffre_conseil/features/tools/ui/site_calculators.dart';
import 'package:chiffre_conseil/ui/widgets/cc_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _wrap(Widget child, {bool dark = false}) => MaterialApp(
      theme: dark ? CCTheme.dark() : CCTheme.light(),
      home: Scaffold(body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: child)),
    );

void main() {
  testWidgets('Calculateur TVA : résultat affiché en direct', (tester) async {
    await tester.pumpWidget(_wrap(const TvaCalculator()));
    expect(find.text('Net à payer'), findsOneWidget);
    expect(find.textContaining('1 191,000 TND'), findsOneWidget);
  });

  testWidgets('Composants en mode sombre', (tester) async {
    await tester.pumpWidget(_wrap(Column(children: const [
      ScoreBar(label: 'Trésorerie', value: 64),
      PrimaryButton('PRENDRE RENDEZ-VOUS', onPressed: null),
    ]), dark: true));
    expect(find.text('64 %'), findsOneWidget);
    expect(find.text('PRENDRE RENDEZ-VOUS'), findsOneWidget);
  });

  test('Liens profonds : normalisation des chemins', () {
    expect(AppRouter.normalize('https://chiffreconseil.net/outils/'), '/outils');
    expect(AppRouter.normalize('/rendez-vous'), '/rendez-vous');
    expect(AppRouter.normalize('/blog/gestion-bfr/?utm=x'), '/blog/gestion-bfr');
    expect(AppRouter.normalize(null), '/');
  });
}
