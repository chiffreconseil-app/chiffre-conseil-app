#!/usr/bin/env bash
# Compilation locale complète : APK debug, APK release, AAB.
set -euo pipefail
cd "$(dirname "$0")/.."
flutter create --platforms=android --org net.chiffreconseil --project-name chiffre_conseil .
python3 tool/configure_android.py
flutter pub get
flutter test
flutter build apk --debug
flutter build apk --release
flutter build appbundle --release
mkdir -p dist
cp build/app/outputs/flutter-apk/app-debug.apk dist/CHIFFRE-CONSEIL-debug.apk
cp build/app/outputs/flutter-apk/app-release.apk dist/CHIFFRE-CONSEIL.apk
cp build/app/outputs/bundle/release/app-release.aab dist/CHIFFRE-CONSEIL.aab
echo "Livrables dans dist/"
