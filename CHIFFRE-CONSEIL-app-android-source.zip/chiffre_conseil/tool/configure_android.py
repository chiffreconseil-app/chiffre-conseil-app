#!/usr/bin/env python3
"""Configure le projet Android généré par `flutter create` :
- applicationId net.chiffreconseil.app
- minSdk >= 23 (stockage chiffré)
- signature release via android/key.properties (sinon clé de debug, pour les tests)

Idempotent : peut être lancé plusieurs fois. Gère build.gradle.kts (Flutter récent)
et build.gradle (Groovy, versions plus anciennes).
Usage : python3 tool/configure_android.py [chemin_du_projet]
"""
import re
import sys
from pathlib import Path

APP_ID = 'net.chiffreconseil.app'
MARK = '// CHIFFRE CONSEIL — signature release'


def patch_kts(src: str) -> str:
    if MARK in src:
        return src
    # applicationId
    src = re.sub(r'applicationId\s*=\s*"[^"]*"', f'applicationId = "{APP_ID}"', src, count=1)
    # minSdk
    src = re.sub(r'minSdk\s*=\s*[^\n]+', 'minSdk = maxOf(23, flutter.minSdkVersion)', src, count=1)
    # imports en tête
    imports = 'import java.io.FileInputStream\nimport java.util.Properties\n'
    if 'import java.util.Properties' not in src:
        src = imports + src
    # chargement de key.properties juste avant android {
    loader = (
        f'\n{MARK}\n'
        'val keystoreProperties = Properties()\n'
        'val keystorePropertiesFile = rootProject.file("key.properties")\n'
        'if (keystorePropertiesFile.exists()) {\n'
        '    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n'
        '}\n\n'
    )
    src = re.sub(r'\nandroid\s*\{', loader + 'android {', src, count=1)
    signing = (
        '    signingConfigs {\n'
        '        create("release") {\n'
        '            if (keystorePropertiesFile.exists()) {\n'
        '                keyAlias = keystoreProperties["keyAlias"] as String\n'
        '                keyPassword = keystoreProperties["keyPassword"] as String\n'
        '                storeFile = file(keystoreProperties["storeFile"] as String)\n'
        '                storePassword = keystoreProperties["storePassword"] as String\n'
        '            }\n'
        '        }\n'
        '    }\n\n'
        '    buildTypes {'
    )
    src = re.sub(r'    buildTypes\s*\{', signing, src, count=1)
    src = re.sub(
        r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
        'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")',
        src,
        count=1,
    )
    return src


def patch_groovy(src: str) -> str:
    if MARK in src:
        return src
    src = re.sub(r'applicationId\s*=?\s*"[^"]*"', f'applicationId = "{APP_ID}"', src, count=1)
    src = re.sub(r'minSdk(Version)?\s*=?\s*[^\n]+', 'minSdkVersion Math.max(23, flutter.minSdkVersion)', src, count=1)
    loader = (
        f'\n{MARK}\n'
        'def keystoreProperties = new Properties()\n'
        "def keystorePropertiesFile = rootProject.file('key.properties')\n"
        'if (keystorePropertiesFile.exists()) {\n'
        '    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))\n'
        '}\n\n'
    )
    src = re.sub(r'\nandroid\s*\{', loader + 'android {', src, count=1)
    signing = (
        '    signingConfigs {\n'
        '        release {\n'
        '            if (keystorePropertiesFile.exists()) {\n'
        "                keyAlias keystoreProperties['keyAlias']\n"
        "                keyPassword keystoreProperties['keyPassword']\n"
        "                storeFile file(keystoreProperties['storeFile'])\n"
        "                storePassword keystoreProperties['storePassword']\n"
        '            }\n'
        '        }\n'
        '    }\n\n'
        '    buildTypes {'
    )
    src = re.sub(r'    buildTypes\s*\{', signing, src, count=1)
    src = re.sub(
        r'signingConfig\s*=?\s*signingConfigs\.debug',
        'signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug',
        src,
        count=1,
    )
    return src


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    kts = root / 'android' / 'app' / 'build.gradle.kts'
    groovy = root / 'android' / 'app' / 'build.gradle'
    if kts.exists():
        kts.write_text(patch_kts(kts.read_text(encoding='utf-8')), encoding='utf-8')
        target = kts
    elif groovy.exists():
        groovy.write_text(patch_groovy(groovy.read_text(encoding='utf-8')), encoding='utf-8')
        target = groovy
    else:
        print('build.gradle introuvable : lancez d\'abord `flutter create --platforms=android .`', file=sys.stderr)
        return 1
    text = target.read_text(encoding='utf-8')
    ok = APP_ID in text and MARK in text and ('signingConfigs' in text)
    print(f'{target.name} configuré : applicationId={APP_ID}, signature release {"(key.properties)" if (root / "android" / "key.properties").exists() else "(clé de debug — tests uniquement)"}')
    # La propriété Gradle Android X / Jetifier reste celle du gabarit Flutter.
    return 0 if ok else 2


if __name__ == '__main__':
    sys.exit(main())
