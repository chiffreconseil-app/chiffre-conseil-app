#!/usr/bin/env bash
# Crée la clé de signature (upload key) pour Google Play — à conserver précieusement.
set -euo pipefail
OUT="${1:-upload-keystore.jks}"
keytool -genkeypair -v -keystore "$OUT" -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload -dname "CN=CHIFFRE CONSEIL, O=CHIFFRE CONSEIL, L=Ariana, C=TN"
echo
echo "Clé créée : $OUT"
echo "1) Copiez-la dans android/app/ et renseignez android/key.properties (voir key.properties.example)"
echo "2) Pour GitHub Actions : base64 -w0 $OUT  -> secret ANDROID_KEYSTORE_BASE64"
echo "3) Empreinte SHA-256 pour assetlinks.json :"
keytool -list -v -keystore "$OUT" -alias upload | grep SHA256 || true
