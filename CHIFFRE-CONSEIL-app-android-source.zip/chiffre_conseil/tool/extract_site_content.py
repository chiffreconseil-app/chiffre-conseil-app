"""Extract the real content of chiffreconseil.net (local source of the site) into
content.json used by the app (bundled snapshot + remote file /app/content.json)."""
import json, os, re, subprocess, sys, datetime
from bs4 import BeautifulSoup, NavigableString, Tag
WWW = sys.argv[1]
OUT = sys.argv[2]
SKIP_CLASSES = {'crumbs', 'meta', 'site-head', 'site-foot', 'cta', 'tag', 'sous-titre', 'tagline', 'drop', 'drop-menu', 'nav', 'mobile', 'shead', 'li-link', 'share', 'related', 'auteur-box'}

def txt(el):
    return re.sub(r'\s+', ' ', el.get_text(' ', strip=True)).replace(' ,', ',').replace(' .', '.').replace('( ', '(').replace(' )', ')').strip()

def inline(el):
    """text with **bold** markers kept (simple)."""
    out = []
    for c in el.children:
        if isinstance(c, NavigableString): out.append(str(c))
        elif c.name in ('b', 'strong'): out.append('**' + c.get_text(' ', strip=False).strip() + '**')
        elif c.name == 'br': out.append('\n')
        else: out.append(inline(c))
    s = re.sub(r'[ \t\r\f\v]+', ' ', ''.join(out))
    s = re.sub(r' *\n *', '\n', s)
    return s.strip()

def blocks_of(root):
    res = []
    def walk(el):
        for c in el.children:
            if not isinstance(c, Tag): continue
            cls = set(c.get('class') or [])
            if cls & SKIP_CLASSES or c.name in ('script', 'style', 'nav', 'header', 'footer', 'img', 'figure', 'form', 'button', 'h1', 'noscript'): continue
            if c.name == 'section' and 'navy' in cls: continue
            if c.name in ('h2', 'h3', 'h4'):
                t = txt(c)
                if t: res.append({'t': c.name, 'x': t})
            elif c.name == 'p':
                t = inline(c)
                if t: res.append({'t': 'p', 'x': t})
            elif c.name in ('ul', 'ol'):
                items = [inline(li) for li in c.find_all('li', recursive=False)]
                items = [i for i in items if i]
                if items: res.append({'t': c.name, 'i': items})
            elif c.name == 'dl':
                items = []
                for dt in c.find_all('dt'):
                    dd = dt.find_next_sibling('dd')
                    items.append([txt(dt), inline(dd) if dd else ''])
                if items: res.append({'t': 'dl', 'i': items})
            elif c.name == 'table' or (c.name == 'div' and c.find('table', recursive=False) and len(c.find_all(True, recursive=False)) == 1):
                tb = c if c.name == 'table' else c.find('table')
                rows = []
                for tr in tb.find_all('tr'):
                    rows.append([txt(td) for td in tr.find_all(['th', 'td'])])
                if rows: res.append({'t': 'table', 'r': rows})
            elif c.name == 'blockquote':
                res.append({'t': 'quote', 'x': inline(c)})
            elif c.name == 'div' and cls & {'callout', 'formule', 'reponse', 'note'}:
                kind = 'formula' if 'formule' in cls else 'callout'
                title = c.find(['b', 'strong', 'h3', 'h4'])
                body = inline(c)
                res.append({'t': kind, 'x': body})
            elif c.name == 'pre' or c.name == 'code':
                res.append({'t': 'formula', 'x': txt(c)})
            else:
                walk(c)
    walk(root)
    # drop trailing "author/cta" noise
    return [b for b in res if not (b['t'] == 'p' and len(b.get('x', '')) < 2)]

def meta(s, prop):
    m = s.find('meta', attrs={'property': prop}) or s.find('meta', attrs={'name': prop})
    return m['content'] if m and m.has_attr('content') else ''

def page(path):
    return BeautifulSoup(open(path, encoding='utf-8'), 'lxml')

# ---------------- site data (TOOLS, POLES, AUTHORS) via node ----------------
js = open(f'{WWW}/assets/js/01-donnees.js', encoding='utf-8').read()
node = subprocess.run(['node', '-e', js + '\nprocess.stdout.write(JSON.stringify({TOOLS, POLES, LI_CABINET, LI_HOUSSEM}))'], capture_output=True, text=True, check=True)
D = json.loads(node.stdout)
import html as H
for t in D['TOOLS']: t['ico'] = H.unescape(t['ico'])
for p in D['POLES']: p['ico'] = H.unescape(p['ico'])

# ---------------- articles ----------------
llms = open(f'{WWW}/llms.txt', encoding='utf-8').read()
guides_sec = llms.split('## Guides pratiques')[1].split('##')[0]
guide_slugs = set(re.findall(r'/blog/([a-z0-9-]+)/', guides_sec))
articles = []
for slug in sorted(os.listdir(f'{WWW}/blog')):
    p = f'{WWW}/blog/{slug}/index.html'
    if slug in ('categorie', 'theme', 'auteur') or not os.path.isfile(p): continue
    s = page(p)
    h1 = s.find('h1')
    main = s.find('article') or s.find('main') or s.body
    sub = main.find(class_='sous-titre') or main.find(class_='tagline')
    tag = main.find(class_='tag')
    rep = main.find(class_='reponse')
    author = 'Houssem Khammassi' if 'Houssem' in (meta(s, 'author') or '') else (meta(s, 'author') or 'Rédaction Chiffre Conseil')
    body = blocks_of(main)
    # the short answer is shown separately
    short = ''
    if rep:
        pp = rep.find('p'); short = inline(pp) if pp else ''
        body = [b for b in body if not (b['t'] == 'callout' and short and short[:40] in b.get('x', ''))]
    a = {
        'slug': slug, 'title': txt(h1) if h1 else meta(s, 'og:title'),
        'subtitle': txt(sub) if sub else '', 'tag': txt(tag) if tag else '',
        'section': meta(s, 'article:section') or (txt(tag) if tag else ''),
        'date': meta(s, 'article:published_time')[:10], 'author': author,
        'description': meta(s, 'description'), 'image': meta(s, 'og:image'),
        'url': f'https://chiffreconseil.net/blog/{slug}/', 'kind': 'guide' if slug in guide_slugs else 'publication',
        'short': short, 'blocks': body,
    }
    if not a['subtitle'] and a['blocks'] and a['blocks'][0]['t'] == 'p' and len(a['blocks'][0]['x']) < 220:
        a['subtitle'] = a['blocks'].pop(0)['x']
    og = os.path.basename(a['image']) if a['image'] else ''
    a['thumb'] = f'assets/images/articles/{og}' if og and os.path.exists(f'{WWW}/assets/og/{og}') else ''
    if not a['date']:
        t = s.find('time'); a['date'] = t['datetime'][:10] if t and t.has_attr('datetime') else ''
    articles.append(a)
articles.sort(key=lambda a: a['date'], reverse=True)

# ---------------- references (official links) ----------------
refs = json.load(open(f'{WWW}/api/references-liens.json', encoding='utf-8'))

# ---------------- about ----------------
about = {
    'mission': "Chiffre Conseil accompagne les entreprises dans leurs décisions stratégiques, leur transformation et leur recherche de performance durable.",
    'founded': "Fondé en novembre 2025 par Houssem Khammassi.",
    'vision': [["Performance", "Optimiser les ressources et les résultats de l'entreprise."], ["Sécurisation", "Maîtriser les risques financiers, fiscaux et organisationnels."], ["Croissance", "Structurer un développement solide et durable."]],
    'values': [["Intégrité", "Une relation fondée sur la confiance et la transparence."], ["Expertise", "Des compétences spécialisées au service de décisions pertinentes."], ["Confidentialité", "La protection des informations et données de nos clients."], ["Performance", "Une orientation permanente vers des résultats mesurables."], ["Innovation", "Des méthodes et outils adaptés aux nouveaux enjeux."], ["Proximité", "Une relation durable et personnalisée avec chaque client."]],
    'journey': [["Écoute", "Recueil de vos besoins et objectifs."], ["Diagnostic", "État des lieux complet de la situation."], ["Analyse", "Étude approfondie des données recueillies."], ["Recommandations", "Solutions concrètes et priorisées."], ["Mise en œuvre", "Déploiement opérationnel accompagné."], ["Suivi", "Pilotage continu de la performance."]],
}
# verify about texts exist on the site
ap = page(f'{WWW}/a-propos/index.html').get_text(' ', strip=True)
for k in ['Fondé en novembre 2025', 'Une relation fondée sur la confiance', 'Pilotage continu de la performance']:
    assert k in ap, k

content = {
    'version': datetime.date.today().isoformat(),
    'source': 'https://chiffreconseil.net',
    'contact': {'name': 'CHIFFRE CONSEIL', 'slogan': 'LE CONSEIL QUI COMPTE', 'address': ['Avenue Hedi Nouira', 'Ennasr 2, Ariana', 'Tunisie'],
                'phone': '+216 99 753 706', 'email': 'chiffreconseil@gmail.com', 'site': 'https://chiffreconseil.net',
                'linkedinCabinet': D['LI_CABINET'], 'linkedinDirector': D['LI_HOUSSEM'], 'director': 'M. Houssem Khammassi, Directeur Général',
                'maps': 'https://www.google.com/maps/search/?api=1&query=Avenue+Hedi+Nouira+Ennasr+2+Ariana+Tunisie'},
    'about': about,
    'expertises': D['POLES'],
    'tools': D['TOOLS'],
    'references': refs,
    'articles': articles,
}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(content, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('articles', len(articles), 'guides', sum(a['kind'] == 'guide' for a in articles), 'refs', len(refs), 'size', os.path.getsize(OUT))
for a in articles[:3]: print(a['slug'], a['date'], a['section'], len(a['blocks']), [b['t'] for b in a['blocks']][:12])
print(set(a['section'] for a in articles))
